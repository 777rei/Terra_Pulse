/* ============================================================
   TERRA PULSE — Service Worker
   ============================================================ */
const SW_VERSION = 'terra-pulse-v1.0.0';
const CORE_CACHE = `${SW_VERSION}-core`;
const RUNTIME_CACHE = `${SW_VERSION}-runtime`;

const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/css/styles.css',
  './assets/icons/logo.svg',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './data/world-110m.json',
  './assets/js/utils.js',
  './assets/js/store.js',
  './assets/js/api.js',
  './assets/js/icons.js',
  './assets/js/icons-extra.js',
  './assets/js/world-data.js',
  './assets/js/data-cities.js',
  './assets/js/data-elements.js',
  './assets/js/starfield.js',
  './assets/js/worldmap.js',
  './assets/js/app.js'
];

const VIEW_NAMES = ['overview','worldmap','clocks','weather','airquality','earthquakes','climate','marine',
  'crypto','stocks','forex','commodities','calculators','news','trends','wikipedia','space','astronomy',
  'planets','launches','network','github','hackernews','population','holidays','health','countries',
  'alerts','shortcuts','settings','about'];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CORE_CACHE);
    await Promise.all(
      CORE_ASSETS.map((url) =>
        cache.add(url).catch((err) => console.warn('[SW] skip', url, err))
      )
    );
    const viewUrls = VIEW_NAMES.map((v) => `./assets/js/views/${v}.js`);
    await Promise.all(viewUrls.map((u) => cache.add(u).catch(() => {})));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys.filter((k) => !k.startsWith(SW_VERSION)).map((k) => caches.delete(k))
    );
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (!url.protocol.startsWith('http')) return;

  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(req);
        const cache = await caches.open(CORE_CACHE);
        cache.put('./index.html', fresh.clone());
        return fresh;
      } catch (e) {
        const cache = await caches.open(CORE_CACHE);
        return (await cache.match('./index.html')) || (await cache.match('./')) || Response.error();
      }
    })());
    return;
  }

  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      const cached = await caches.match(req);
      if (cached) {
        fetch(req).then((fresh) => {
          caches.open(CORE_CACHE).then((c) => c.put(req, fresh.clone()));
        }).catch(() => {});
        return cached;
      }
      try {
        const fresh = await fetch(req);
        const cache = await caches.open(CORE_CACHE);
        cache.put(req, fresh.clone());
        return fresh;
      } catch (e) {
        return Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const timeout = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('timeout')), 9000)
    );
    try {
      const fresh = await Promise.race([fetch(req), timeout]);
      if (fresh && fresh.ok) {
        const cache = await caches.open(RUNTIME_CACHE);
        cache.put(req, fresh.clone());
      }
      return fresh;
    } catch (e) {
      const cache = await caches.open(RUNTIME_CACHE);
      const cached = await cache.match(req);
      return cached || Response.error();
    }
  })());
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
  if (event.data === 'CLEAR_CACHE') {
    caches.keys().then((keys) => Promise.all(keys.map((k) => caches.delete(k)))).then(() => {
      event.source && event.source.postMessage({ type: 'CACHE_CLEARED' });
    });
  }
});
