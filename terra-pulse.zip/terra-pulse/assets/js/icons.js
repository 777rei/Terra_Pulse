/* ============================================================
   TERRA PULSE — Icon Library
   Professional SVG outline icons (replaces all emoji).
   Usage: <i data-icon="globe"></i>  → replaced at runtime.
   ============================================================ */
(function (global) {
  'use strict';

  // Each icon is a 24x24 viewBox SVG path set, stroke-based, currentColor.
  const ICONS = {
    // Navigation / general
    overview: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3" fill="currentColor" stroke="none"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    map: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>',
    layers: '<path d="m12 2 9 5-9 5-9-5 9-5zM3 12l9 5 9-5M3 17l9 5 9-5"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="m15 9-2 6-4 0 2-6 4 0z" fill="currentColor" stroke="none"/>',
    pulse: '<path d="M3 12h4l2-7 4 14 2-7h6"/>',
    activity: '<path d="M3 12h4l3-9 4 18 3-9h4"/>',
    home: '<path d="m3 11 9-8 9 8M5 9v11h5v-6h4v6h5V9"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    close: '<path d="M6 6l12 12M6 18 18 6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-5-5"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7M21 4v4h-4"/>',
    bell: '<path d="M6 9a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 21a2 2 0 0 0 4 0"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.4-2.4 1a7 7 0 0 0-1.7-1l-.4-2.6h-4l-.4 2.6a7 7 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.5a7 7 0 0 0 0 2l-2 1.5 2 3.4 2.4-1a7 7 0 0 0 1.7 1l.4 2.6h4l.4-2.6a7 7 0 0 0 1.7-1l2.4 1 2-3.4-2-1.5a7 7 0 0 0 .1-1z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    fullscreen: '<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    chevronLeft: '<path d="m15 6-6 6 6 6"/>',
    chevronRight: '<path d="m9 6 6 6-6 6"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
    warning: '<path d="M12 3 2 21h20L12 3zM12 9v4M12 17h.01"/>',
    alert: '<path d="M12 3 2 21h20L12 3zM12 9v4M12 17h.01"/>',
    error: '<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>',
    success: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',

    // Weather & environment
    cloud: '<path d="M17 18a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10z"/>',
    cloudRain: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10zM8 18l-1 3M12 18l-1 3M16 18l-1 3"/>',
    cloudSnow: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10zM8 19v.01M12 19v.01M16 19v.01"/>',
    cloudFog: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10zM4 18h6M14 18h6M4 21h12M18 21h2"/>',
    sunCloud: '<circle cx="7" cy="7" r="3"/><path d="M7 1v1M7 12v1M1 7h1M12 7h1M3 3l1 1M11 3l-1 1M3 11l1-1M11 11l-1-1M17 18a4 4 0 0 0 0-8 5 5 0 0 0-9 1 4 4 0 0 0 1 7h8z"/>',
    lightning: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z" fill="currentColor" stroke="none"/>',
    thermometer: '<path d="M14 14V4a2 2 0 1 0-4 0v10a4 4 0 1 0 4 0z"/>',
    droplet: '<path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z"/>',
    wind: '<path d="M3 8h12a3 3 0 1 0-3-3M3 14h16a3 3 0 1 1-3 3M3 11h10"/>',
    air: '<path d="M3 8h12a3 3 0 1 0-3-3M3 14h16a3 3 0 1 1-3 3M3 11h10"/>',
    eye: '<circle cx="12" cy="12" r="3"/><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/>',
    leaf: '<path d="M5 19c0-9 7-16 16-16 0 9-7 16-16 16zM5 19c4-4 8-8 12-12"/>',
    flame: '<path d="M12 2s4 4 4 8a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 1 3 2 4 0-3 0-5 0-8z"/>',
    mountain: '<path d="m3 20 6-10 4 6 2-3 6 7H3z"/>',
    wave: '<path d="M2 12c2-3 4-3 6 0s4 3 6 0 4-3 6 0M2 18c2-3 4-3 6 0s4 3 6 0 4-3 6 0"/>',

    // Finance
    bitcoin: '<circle cx="12" cy="12" r="9"/><path d="M9 8h5a2 2 0 0 1 0 4H9zM9 12h5.5a2 2 0 0 1 0 4H9zM11 6v2M11 16v2M13 6v2M13 16v2"/>',
    currency: '<circle cx="12" cy="12" r="9"/><path d="M14 9l-4 6M9 9l4 6M12 7v1M12 16v1"/>',
    chart: '<path d="M3 3v18h18M7 14l3-3 3 2 5-6"/>',
    chartUp: '<path d="M3 17l6-6 4 4 8-9M14 6h7v7"/>',
    chartDown: '<path d="M3 7l6 6 4-4 8 9M14 18h7v-7"/>',
    trending: '<path d="M3 17l6-6 4 4 8-9M21 6v6h-6"/>',
    coins: '<circle cx="9" cy="9" r="6"/><path d="M14.5 4.5a6 6 0 1 1-9 9 5 5 0 0 0 9-9zM7 9h4M9 7v4"/>',
    savings: '<path d="M19 9c0-3-3-5-7-5s-7 2-7 5c0 1 .5 2 1 3l-1 3h2l1-2h4l1 2h2v-3a6 6 0 0 0 4-3zM16 7l3-2M14 11h.01"/>',
    calculator: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01M8 18h4"/>',
    wallet: '<path d="M3 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7zM3 10h18M16 14h.01"/>',
    bank: '<path d="M3 10 12 4l9 6M4 10v8M8 10v8M12 10v8M16 10v8M20 10v8M3 21h18"/>',
    exchange: '<path d="M16 3l4 4-4 4M20 7H4M8 21l-4-4 4-4M4 17h16"/>',
    percent: '<path d="M19 5 5 19M7 8a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0zM20 16a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0z"/>',
    dollar: '<circle cx="12" cy="12" r="9"/><path d="M12 6v12M15 9.5a3 3 0 0 0-3-1.5c-1.7 0-3 1-3 2.5s1.3 2 3 2.5 3 1 3 2.5-1.3 2.5-3 2.5a3 3 0 0 1-3-1.5"/>',
    euro: '<circle cx="12" cy="12" r="9"/><path d="M14 8a4 4 0 1 0 0 8M7 10h5M7 14h5"/>',
    yen: '<circle cx="12" cy="12" r="9"/><path d="M9 8l3 4 3-4M9 13h6M9 16h6"/>',
    pound: '<circle cx="12" cy="12" r="9"/><path d="M14 8a3 3 0 0 0-3 1.5v5.5a2 2 0 0 1-2 2h7M8 13h4"/>',
    oil: '<path d="M5 21h14l-2-9h-10l-2 9zM7 12V8a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v4M11 6V3h2v3"/>',
    gold: '<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9 10l3-3 3 3M9 14l3 3 3-3"/>',
    silver: '<circle cx="12" cy="12" r="9"/><path d="M12 7l3 5-3 5-3-5 3-5z"/>',
    gem: '<path d="M3 8l4-4h10l4 4-9 12L3 8zM7 8h10M9 4l3 16M15 4l-3 16"/>',

    // Space
    rocket: '<path d="M12 2c3 4 5 8 5 12a5 5 0 0 1-10 0c0-4 2-8 5-12zM12 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM7 16l-3 3 4-1M17 16l3 3-4-1M9 19l-1 3M15 19l1 3"/>',
    satellite: '<path d="m5 11 4-4M11 5l4 4M15 9l-4 4M9 15l-4-4M14 14l4 4M5 19a8 8 0 0 1 8-8M19 5a8 8 0 0 0-8 8"/>',
    star: '<path d="M12 2l3 7h7l-6 4 2 8-6-5-6 5 2-8-6-4h7l3-7z"/>',
    galaxy: '<circle cx="12" cy="12" r="2"/><path d="M12 4a8 8 0 0 1 8 8M4 12a8 8 0 0 1 8-8M12 20a8 8 0 0 1-8-8M20 12a8 8 0 0 1-8 8M2 12C2 6 6 2 12 2M22 12c0 6-4 10-10 10"/>',
    planet: '<circle cx="12" cy="12" r="6"/><ellipse cx="12" cy="12" rx="11" ry="3" transform="rotate(-20 12 12)"/>',
    moonRock: '<path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM9 9h.01M15 9h.01M9 15h.01M15 15h.01M12 12h.01"/>',
    meteor: '<path d="m3 21 12-12M15 9a3 3 0 1 0-6 0 3 3 0 0 0 6 0zM19 5l-2 2M21 8l-2 2M18 3l-1 1"/>',
    astronaut: '<circle cx="12" cy="9" r="5"/><path d="M5 14a7 7 0 0 1 14 0M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5M9 9h6"/>',
    orbit: '<circle cx="12" cy="12" r="3"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(45 12 12)"/>',
    telescope: '<path d="M3 21l9-9M12 12l5-5 4 4-5 5M14 10l4 4M9 21h6"/>',

    // Tech / network
    network: '<circle cx="12" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M12 7v4M12 11l-5 6M12 11l5 6"/>',
    server: '<rect x="3" y="4" width="18" height="6" rx="1"/><rect x="3" y="14" width="18" height="6" rx="1"/><path d="M7 7h.01M7 17h.01"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    wifi: '<path d="M5 12a10 10 0 0 1 14 0M8 15a6 6 0 0 1 8 0M11 18a2 2 0 0 1 2 0M2 9a16 16 0 0 1 20 0"/>',
    signal: '<path d="M4 18v-3M8 18v-6M12 18v-9M16 18v-12M20 18v-15"/>',
    cpu: '<rect x="6" y="6" width="12" height="12" rx="1"/><path d="M9 9h6v6H9zM9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"/>',
    code: '<path d="m8 6-6 6 6 6M16 6l6 6-6 6M14 4l-4 16"/>',
    github: '<path d="M9 19c-4 1-4-2-6-2m12 4v-3c0-1 0-2-2-2 4-1 6-3 6-7 0-2-1-4-2-5 0-1 1-3 0-4 0 0-2 0-4 2-3-1-6-1-9 0C4 1 2 1 2 1c-1 1 0 3 0 4-1 1-2 3-2 5 0 4 2 6 6 7-1 1-1 2-1 2"/>',
    rss: '<path d="M4 11a9 9 0 0 1 9 9M4 4a16 16 0 0 1 16 16M5 19a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>',
    news: '<path d="M4 4h13a2 2 0 0 1 2 2v14H6a2 2 0 0 1-2-2V4zM4 18h15M8 8h7M8 12h7M8 16h4"/>',
    newspaper: '<path d="M3 5h14v14H3zM3 9h14M7 13h6M7 16h4M21 5v14h-4M17 9h4"/>',
    bookmark: '<path d="M6 3h12v18l-6-4-6 4V3z"/>',
    fire: '<path d="M12 2s4 4 4 8a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 1 3 2 4 0-3 0-5 0-8z"/>',
    flame2: '<path d="M12 2s4 4 4 8a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 1 3 2 4 0-3 0-5 0-8z"/>',
    book: '<path d="M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4V4zM20 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8V4z"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M7 14h2M11 14h2M15 14h2M7 18h2M11 18h2"/>',
    heart: '<path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 11c0 5.5-7 10-7 10z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/>',
    users: '<circle cx="8" cy="9" r="3"/><path d="M2 21c0-3 3-6 6-6s6 3 6 6M16 4a3 3 0 0 1 0 6M22 21c0-3-2-5-5-6"/>',
    people: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/>',
    shield: '<path d="M12 2 4 5v7c0 5 3 8 8 10 5-2 8-5 8-10V5l-8-3z"/>',
    cross: '<path d="M9 2h6v5h5v6h-5v9H9v-9H4V7h5V2z"/>',
    medical: '<path d="M9 2h6v5h5v6h-5v9H9v-9H4V7h5V2z"/>',
    pill: '<rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(45 12 12)"/><path d="M9 9l6 6"/>',
    flag: '<path d="M4 21V4l8 2 8-2v11l-8 2-8-2"/>',
    location: '<path d="M12 22s8-7 8-13a8 8 0 1 0-16 0c0 6 8 13 8 13z"/><circle cx="12" cy="9" r="3"/>',
    pin: '<path d="M12 22s8-7 8-13a8 8 0 1 0-16 0c0 6 8 13 8 13z"/><circle cx="12" cy="9" r="3"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
    zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/>',
    power: '<path d="M12 2v10M5 7a10 10 0 1 0 14 0"/>',
    battery: '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4M6 10v4M10 10v4M14 10v4"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 2a7 7 0 0 0-4 12c1 1 1 2 1 3h6c0-1 0-2 1-3a7 7 0 0 0-4-12z"/>',
    sparkles: '<path d="M12 3l1.5 5L19 9.5l-5 1.5L12 16l-1.5-5L5 9.5l5.5-1.5L12 3zM18 14l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3zM5 14l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3z"/>',
    award: '<circle cx="12" cy="9" r="6"/><path d="M9 14l-2 7 5-3 5 3-2-7"/>',
    trophy: '<path d="M5 4h14v3a4 4 0 0 1-4 4h-6a4 4 0 0 1-4-4V4zM5 6H3a2 2 0 0 0 2 2M19 6h2a2 2 0 0 1-2 2M9 11v3a3 3 0 0 0 6 0v-3M8 21h8M10 21v-3M14 21v-3"/>',
    gauge: '<path d="M3 12a9 9 0 0 1 18 0M12 12l4-3M3 12h2M19 12h2M12 3v2M5 5l1 1M19 5l-1 1"/>',
    speedometer: '<path d="M3 12a9 9 0 0 1 18 0M12 12l4-3M3 12h2M19 12h2M12 3v2"/>',
    thermometer2: '<path d="M14 14V4a2 2 0 1 0-4 0v10a4 4 0 1 0 4 0z"/>',
    rain: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10zM8 18l-1 3M12 18l-1 3M16 18l-1 3"/>',
    earthquake: '<path d="M2 12l3-3 3 6 3-9 3 6 3-3 3 3M2 12v8M22 12v8"/>',
    vibration: '<path d="M2 12l3-3 3 6 3-9 3 6 3-3 3 3"/>',
    broadcast: '<circle cx="12" cy="12" r="2"/><path d="M5 5a10 10 0 0 1 0 14M19 5a10 10 0 0 0 0 14M8 8a6 6 0 0 1 0 8M16 8a6 6 0 0 0 0 8"/>',
    antenna: '<path d="M4 21l8-18 8 18M4 21h16M8 14h8"/>',
    link: '<path d="M10 13a4 4 0 0 0 6 0l3-3a4 4 0 1 0-6-6l-1 1M14 11a4 4 0 0 0-6 0l-3 3a4 4 0 1 0 6 6l1-1"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9M19 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h6"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M3 21h18"/>',
    upload: '<path d="M12 21V9M7 14l5-5 5 5M3 3h18"/>',
    play: '<path d="M5 3l14 9-14 9V3z" fill="currentColor" stroke="none"/>',
    pause: '<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>',
    filter: '<path d="M3 4h18l-7 8v6l-4 2v-8L3 4z"/>',
    sort: '<path d="M3 6h18M6 12h12M10 18h4"/>',
    sortUp: '<path d="M3 6h18M6 12h12M10 18h4"/>',
    arrowUp: '<path d="M12 5v14M5 12l7-7 7 7"/>',
    arrowDown: '<path d="M12 5v14M5 12l7 7 7-7"/>',
    arrowRight: '<path d="M5 12h14M12 5l7 7-7 7"/>',
    arrowLeft: '<path d="M19 12H5M12 5l-7 7 7 7"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
    trash: '<path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
    eye2: '<circle cx="12" cy="12" r="3"/><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/>',
    edit: '<path d="M11 4H4v16h16v-7M18.5 2.5l3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2zM7 3v5h8V3M7 21v-7h10v7"/>',
    terminal: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M13 15h4"/>',
    key: '<circle cx="8" cy="8" r="4"/><path d="M11 11l9 9M16 16l2-2M19 19l2-2"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 1 1 8 0v4"/>',
    unlock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 1 1 8 0"/>',
    qr: '<rect x="3" y="3" width="6" height="6"/><rect x="15" y="3" width="6" height="6"/><rect x="3" y="15" width="6" height="6"/><path d="M15 15h2v2h-2zM19 15h2v2h-2zM15 19h2v2h-2zM19 19h2v2h-2z"/>',
    star2: '<path d="M12 2l3 7h7l-6 4 2 8-6-5-6 5 2-8-6-4h7l3-7z"/>',
    heartFilled: '<path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 11c0 5.5-7 10-7 10z" fill="currentColor" stroke="none"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 5 0c0 1.5-2.5 2-2.5 4M12 17h.01"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.5-1.1a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2z"/>',
    message: '<path d="M21 11.5a8.4 8.4 0 0 1-9 8.4L3 21l1.1-9A8.4 8.4 0 1 1 21 11.5z"/>',
    chat: '<path d="M21 11.5a8.4 8.4 0 0 1-9 8.4L3 21l1.1-9A8.4 8.4 0 1 1 21 11.5z"/>',
    compass2: '<circle cx="12" cy="12" r="9"/><path d="m15 9-2 6-4 0 2-6 4 0z" fill="currentColor" stroke="none"/>',
    ruler: '<path d="M3 16l5 5L21 8l-5-5L3 16zM7 16l2 2M10 13l2 2M13 10l2 2"/>',
    palette: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="9" r="1" fill="currentColor"/><circle cx="16" cy="9" r="1" fill="currentColor"/><circle cx="9" cy="15" r="1" fill="currentColor"/><circle cx="15" cy="15" r="1" fill="currentColor"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
    camera: '<path d="M3 7h4l2-2h6l2 2h4v12H3z"/><circle cx="12" cy="13" r="4"/>',
    video: '<rect x="2" y="6" width="14" height="12" rx="2"/><path d="m22 8-6 4 6 4V8z"/>',
    music: '<circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/><path d="M9 18V5l12-2v13"/>',
    headphones: '<path d="M3 18v-6a9 9 0 0 1 18 0v6M3 18a2 2 0 0 0 2 2h1v-6H5a2 2 0 0 0-2 2zM21 18a2 2 0 0 1-2 2h-1v-6h1a2 2 0 0 1 2 2z"/>',
    microphone: '<rect x="9" y="2" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    layers2: '<path d="m12 2 9 5-9 5-9-5 9-5zM3 12l9 5 9-5M3 17l9 5 9-5"/>',
    grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    cards: '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="M7 5V3a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-2"/>',
    table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 4v16M15 4v16"/>',
    fileText: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM14 2v6h6M8 13h8M8 17h8M8 9h2"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/>',
    briefcase: '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M2 13h20"/>',
    plane: '<path d="M10 16v5l2 1 2-1v-5M22 12L2 9l8-7 12 10zM2 9l8 7"/>',
    car: '<path d="M3 13l2-6a2 2 0 0 1 2-1h10a2 2 0 0 1 2 1l2 6v5h-3v-2H6v2H3v-5zM6 16h.01M18 16h.01"/>',
    train: '<rect x="5" y="3" width="14" height="14" rx="2"/><path d="M5 11h14M8 15h.01M16 15h.01M7 21l2-3M17 21l-2-3"/>',
    fuel: '<path d="M3 22V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v18M3 10h10M14 8l3 3v8a2 2 0 0 0 4 0V9l-3-3M16 5h2v2h-2z"/>',
    factory: '<path d="M3 21V10l5 3V10l5 3V7l5 3v11H3zM7 17h2M12 17h2M17 17h2"/>',
    plant: '<path d="M12 22V8M12 8c0-3 2-5 5-5 0 3-2 5-5 5zM12 12c0-3-2-5-5-5 0 3 2 5 5 5z"/>',
    trash2: '<path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
    recycle: '<path d="M12 4l2 4-3 2-2-4M5 18l3-2 3 2-2 3M19 18l-3-2-3 2 2 3M7 6l5-2 5 2-2 4h-6L7 6z"/>',
    snowflake: '<path d="M12 2v20M2 12h20M5 5l14 14M19 5L5 19"/>',
    sun2: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon2: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    sunrise: '<path d="M17 18a5 5 0 0 0-10 0M12 2v6M4.2 10.2l1.4 1.4M2 18h2M20 18h2M18.4 11.6l1.4-1.4M22 22H2M8 6l4-4 4 4"/>',
    sunset: '<path d="M17 18a5 5 0 0 0-10 0M12 8V2M4.2 10.2l1.4 1.4M2 18h2M20 18h2M18.4 11.6l1.4-1.4M22 22H2M16 6l-4-4-4 4"/>',
    cloudSun: '<circle cx="7" cy="7" r="3"/><path d="M7 1v1M7 12v1M1 7h1M12 7h1M3 3l1 1M11 3l-1 1M3 11l1-1M11 11l-1-1M17 18a4 4 0 0 0 0-8 5 5 0 0 0-9 1 4 4 0 0 0 1 7h8z"/>',
    cloudLightning: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10zM13 13l-3 5h4l-3 5"/>',
    cloudDrizzle: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10zM8 19v.01M12 19v.01M16 19v.01"/>',
    humidity: '<path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11zM9 14a3 3 0 0 0 3 3"/>',
    uv: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4M9 12h6"/>',
    pressure: '<circle cx="12" cy="12" r="9"/><path d="M12 12l4-3M12 7v1M12 16v1M7 12h1M16 12h1"/>',
    visibility: '<circle cx="12" cy="12" r="3"/><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/>',
    pollen: '<circle cx="12" cy="12" r="2"/><circle cx="12" cy="5" r="2"/><circle cx="12" cy="19" r="2"/><circle cx="5" cy="12" r="2"/><circle cx="19" cy="12" r="2"/><circle cx="7" cy="7" r="2"/><circle cx="17" cy="17" r="2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="7" r="2"/>',
    sunrise2: '<path d="M17 18a5 5 0 0 0-10 0M12 2v6M4.2 10.2l1.4 1.4M2 18h2M20 18h2M18.4 11.6l1.4-1.4M22 22H2M8 6l4-4 4 4"/>',
    clock2: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    pin2: '<path d="M12 22s8-7 8-13a8 8 0 1 0-16 0c0 6 8 13 8 13z"/><circle cx="12" cy="9" r="3"/>',
    quakes: '<path d="M2 12l3-3 3 6 3-9 3 6 3-3 3 3M2 12v8M22 12v8"/>',
    market: '<path d="M3 3v18h18M7 14l3-3 3 2 5-6"/>',
    money: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/>',
    chartBar: '<path d="M3 3v18h18M7 14v4M11 10v8M15 6v12M19 12v6"/>',
    chartPie: '<path d="M21 12A9 9 0 1 1 12 3v9h9z"/><path d="M12 3v9h9"/>',
    chartArea: '<path d="M3 3v18h18M3 17l5-5 4 3 4-6 5 4M3 17v4h18"/>',
    chartCandle: '<path d="M3 3v18h18M7 5v3M7 14v5M7 8v6M17 4v3M17 14v5M17 7v7M12 7v2M12 15v4M12 9v6"/>',
    exchange2: '<path d="M16 3l4 4-4 4M20 7H4M8 21l-4-4 4-4M4 17h16"/>',
    trending2: '<path d="M3 17l6-6 4 4 8-9M21 6v6h-6"/>',
    trendingDown: '<path d="M3 7l6 6 4-4 8 9M21 18v-6h-6"/>',
    scale: '<path d="M12 3v18M5 7l-3 7h6l-3-7zM19 7l-3 7h6l-3-7zM3 21h18"/>',
    balance: '<path d="M12 3v18M5 7l-3 7h6l-3-7zM19 7l-3 7h6l-3-7zM3 21h18"/>',
    pieChart: '<path d="M21 12A9 9 0 1 1 12 3v9h9z"/><path d="M12 3v9h9"/>',
    donut: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',
    activity2: '<path d="M3 12h4l3-9 4 18 3-9h4"/>',
    waveform: '<path d="M3 12h2l2-6 3 14 3-12 2 4h6"/>',
    battery2: '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4"/>',
    plug: '<path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0V8zM12 17v5"/>',
    power2: '<path d="M12 2v10M5 7a10 10 0 1 0 14 0"/>',
    cpu2: '<rect x="6" y="6" width="12" height="12" rx="1"/><path d="M9 9h6v6H9zM9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"/>',
    hardDrive: '<path d="M3 12h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-8zM3 12l3-7h12l3 7M7 16h.01M11 16h.01"/>',
    wifi2: '<path d="M5 12a10 10 0 0 1 14 0M8 15a6 6 0 0 1 8 0M11 18a2 2 0 0 1 2 0M2 9a16 16 0 0 1 20 0"/>',
    cloud2: '<path d="M17 18a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10z"/>',
    server2: '<rect x="3" y="4" width="18" height="6" rx="1"/><rect x="3" y="14" width="18" height="6" rx="1"/><path d="M7 7h.01M7 17h.01"/>',
    shield2: '<path d="M12 2 4 5v7c0 5 3 8 8 10 5-2 8-5 8-10V5l-8-3z"/>',
    fingerprint: '<path d="M12 4a8 8 0 0 0-8 8M20 12a8 8 0 0 0-8-8M5 16a14 14 0 0 0 2 4M19 16a14 14 0 0 1-2 4M12 8a4 4 0 0 0-4 4v4a16 16 0 0 0 1 4M16 12v4a16 16 0 0 1-1 4M12 12v8"/>',
    biohazard: '<circle cx="12" cy="12" r="3"/><path d="M12 3a4 4 0 0 1 4 4M12 3a4 4 0 0 0-4 4M5 17a4 4 0 0 1-1-5M5 17a4 4 0 0 0 5 1M19 17a4 4 0 0 0-5 1M19 17a4 4 0 0 1 1-5"/>',
    mask: '<path d="M3 12a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4 4 4 0 0 1-4 4h-1l-3-2-3 2H7a4 4 0 0 1-4-4zM7 12h.01M17 12h.01"/>',
    syringe: '<path d="M3 21l3-3M5 19l8-8M13 11l4 4M17 7l-4 4M18 6l4 4M14 2l8 8M5 19l1 1"/>',
    virus: '<circle cx="12" cy="12" r="4"/><path d="M12 4v3M12 17v3M4 12h3M17 12h3M6 6l2 2M16 16l2 2M6 18l2-2M16 8l2-2"/>',
    dna: '<path d="M4 2c8 0 16 8 16 20M20 2c-8 0-16 8-16 20M4 2v20M20 2v20M4 8h16M4 16h16"/>',
    atom: '<circle cx="12" cy="12" r="2"/><ellipse cx="12" cy="12" rx="10" ry="4"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(120 12 12)"/>',
    molecules: '<circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="12" cy="12" r="2"/><path d="M6 6l6 6 6-6M6 18l6-6 6 6M6 6v12M18 6v12"/>',
    orbit2: '<circle cx="12" cy="12" r="3"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(45 12 12)"/>',
    mars: '<circle cx="10" cy="14" r="6"/><path d="M14 10l6-6M20 4h-4M20 4v4"/>',
    rocket2: '<path d="M12 2c3 4 5 8 5 12a5 5 0 0 1-10 0c0-4 2-8 5-12zM12 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM7 16l-3 3 4-1M17 16l3 3-4-1"/>',
    iss: '<circle cx="12" cy="12" r="3"/><path d="M2 12h7M15 12h7M12 2v7M12 15v7M5 5l4 4M15 15l4 4M5 19l4-4M15 9l4-4"/>',
    ufo: '<path d="M3 14a9 9 0 0 1 18 0H3zM12 14v4M9 18l-2 3M15 18l2 3M12 14a3 3 0 0 0-3-3M12 14a3 3 0 0 1 3-3"/>',
    alien: '<path d="M12 3a8 8 0 0 0-8 8c0 4 4 10 8 10s8-6 8-10a8 8 0 0 0-8-8zM8 11h.01M16 11h.01M9 14h6"/>',
    planet2: '<circle cx="12" cy="12" r="6"/><ellipse cx="12" cy="12" rx="11" ry="3" transform="rotate(-20 12 12)"/>',
    satellite2: '<path d="m5 11 4-4M11 5l4 4M15 9l-4 4M9 15l-4-4M14 14l4 4M5 19a8 8 0 0 1 8-8M19 5a8 8 0 0 0-8 8"/>',
    telescope2: '<path d="M3 21l9-9M12 12l5-5 4 4-5 5M14 10l4 4M9 21h6"/>',
    astrology: '<circle cx="12" cy="12" r="3"/><path d="M12 3a9 9 0 0 1 0 18M3 12h18M5 5l14 14"/>',
    galaxy2: '<circle cx="12" cy="12" r="2"/><path d="M12 4a8 8 0 0 1 8 8M4 12a8 8 0 0 1 8-8M12 20a8 8 0 0 1-8-8M20 12a8 8 0 0 1-8 8M2 12C2 6 6 2 12 2M22 12c0 6-4 10-10 10"/>',
    einstein: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7M9 4c0-2 1-3 3-3s3 1 3 3"/>',
    lab: '<path d="M9 3h6v5l4 9a3 3 0 0 1-3 4H8a3 3 0 0 1-3-4l4-9V3zM9 3v6h6V3"/>',
    flask: '<path d="M9 3h6v5l4 9a3 3 0 0 1-3 4H8a3 3 0 0 1-3-4l4-9V3zM9 3v6h6V3"/>',
    testTube: '<path d="M9 3h6v5l4 9a3 3 0 0 1-3 4H8a3 3 0 0 1-3-4l4-9V3zM9 3v6h6V3"/>',
    microscope: '<path d="M6 18h8M3 22h18M9 18l-3-3 5-5 3 3-5 5zM14 8l3 3M9 3l4 4"/>',
    gravity: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18"/>',
    blackHole: '<circle cx="12" cy="12" r="3" fill="currentColor"/><ellipse cx="12" cy="12" rx="10" ry="3"/><ellipse cx="12" cy="12" rx="10" ry="3" transform="rotate(45 12 12)"/>',
    constellation: '<circle cx="4" cy="6" r="1.5" fill="currentColor"/><circle cx="9" cy="4" r="1.5" fill="currentColor"/><circle cx="14" cy="8" r="1.5" fill="currentColor"/><circle cx="19" cy="6" r="1.5" fill="currentColor"/><circle cx="6" cy="14" r="1.5" fill="currentColor"/><circle cx="11" cy="17" r="1.5" fill="currentColor"/><circle cx="18" cy="19" r="1.5" fill="currentColor"/><path d="M4 6l5-2 5 4 5-2M6 14l5 3 7 2M14 8l-3 6M9 4l-3 10"/>',
    saturn: '<circle cx="12" cy="12" r="6"/><ellipse cx="12" cy="12" rx="14" ry="3" transform="rotate(-15 12 12)"/>',
    jupiter: '<circle cx="12" cy="12" r="9"/><path d="M4 9h16M3 14h18M8 5a3 3 0 0 0 0 4M16 5a3 3 0 0 1 0 4"/>',
    nav: '<path d="M3 12l9-9 9 9M5 10v10h5v-6h4v6h5V10"/>',
    ship: '<path d="M3 17l1-5h16l1 5M4 17h16v3H4zM8 12V6h8v6M10 6V3h4v3"/>',
    anchor: '<circle cx="12" cy="5" r="2"/><path d="M12 7v14M5 12a7 7 0 0 0 14 0M3 12h2M19 12h2"/>',
    sailboat: '<path d="M3 17h18M5 17l3-12 8 12M12 17V9M3 17l2 4h14l2-4"/>',
    lighthouse: '<path d="M9 22h6M10 22V8l4-2v16M8 8l8 0M6 4h12M3 12h4M17 12h4"/>',
    compass3: '<circle cx="12" cy="12" r="9"/><path d="m15 9-2 6-4 0 2-6 4 0z" fill="currentColor" stroke="none"/>',
    gps: '<circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 2M12 2v2M12 20v2M2 12h2M20 12h2"/>',
    antenna2: '<path d="M4 21l8-18 8 18M4 21h16M8 14h8"/>',
    router: '<rect x="3" y="9" width="18" height="11" rx="2"/><path d="M7 14h.01M11 14h.01M15 14h.01M7 18h10M3 5l4 4M21 5l-4 4M12 2v4"/>',
    cellular: '<path d="M4 18v-3M8 18v-6M12 18v-9M16 18v-12M20 18v-15"/>',
    wifi3: '<path d="M5 12a10 10 0 0 1 14 0M8 15a6 6 0 0 1 8 0M11 18a2 2 0 0 1 2 0M2 9a16 16 0 0 1 20 0"/>',
    radio: '<circle cx="12" cy="12" r="2"/><path d="M7.8 7.8a6 6 0 0 1 8.4 0M16.2 16.2a6 6 0 0 1-8.4 0M4.9 4.9a10 10 0 0 1 14.1 0M19.1 19.1a10 10 0 0 1-14.1 0"/>',
    tv: '<rect x="2" y="4" width="20" height="14" rx="2"/><path d="M8 21h8M12 18v3"/>',
    cast: '<path d="M2 8v11a2 2 0 0 0 2 2h16M2 8a16 16 0 0 1 16 16M2 8a10 10 0 0 1 10 10M2 13a5 5 0 0 1 5 5"/>',
    podcast: '<circle cx="12" cy="9" r="3"/><path d="M5 9a7 7 0 0 1 14 0M9 14l-1 7M15 14l1 7M12 12v8"/>',
    stream: '<path d="M2 12s4-4 10-4 10 4 10 4M2 18s4-2 10-2 10 2 10 2M2 6s4 2 10 2 10-2 10-2"/>',
    trending3: '<path d="M3 17l6-6 4 4 8-9M21 6v6h-6"/>',
    chart3: '<path d="M3 3v18h18M7 14l3-3 3 2 5-6"/>'
  };

  // Brand logo (used in sidebar)
  const LOGO_SVG = `<svg viewBox="0 0 64 64" width="100%" height="100%">
    <defs>
      <radialGradient id="logoG" cx="35%" cy="28%" r="80%">
        <stop offset="0%" stop-color="#7af0ff"/>
        <stop offset="50%" stop-color="#2b6cff"/>
        <stop offset="100%" stop-color="#0a1840"/>
      </radialGradient>
      <linearGradient id="logoR" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#7af0ff"/>
        <stop offset="100%" stop-color="#b07bff"/>
      </linearGradient>
    </defs>
    <circle cx="32" cy="32" r="28" fill="url(#logoG)" stroke="url(#logoR)" stroke-width="1.2"/>
    <ellipse cx="32" cy="32" rx="28" ry="11" fill="none" stroke="#7af0ff" stroke-opacity="0.55" stroke-width="0.7"/>
    <ellipse cx="32" cy="32" rx="11" ry="28" fill="none" stroke="#7af0ff" stroke-opacity="0.55" stroke-width="0.7"/>
    <line x1="4" y1="32" x2="60" y2="32" stroke="#7af0ff" stroke-opacity="0.7" stroke-width="0.7"/>
    <line x1="32" y1="4" x2="32" y2="60" stroke="#7af0ff" stroke-opacity="0.7" stroke-width="0.7"/>
    <path d="M 8 32 L 24 32 L 28 22 L 33 42 L 38 28 L 42 32 L 56 32" fill="none" stroke="url(#logoR)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="32" cy="32" r="2.4" fill="#7af0ff"/>
  </svg>`;

  function makeIcon(name, size = 20, stroke = 1.6) {
    const path = ICONS[name] || ICONS.help;
    return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" class="icon icon-${name}">${path}</svg>`;
  }

  // Replace all <i data-icon="name"> elements with SVG
  function hydrate(root = document) {
    root.querySelectorAll('[data-icon]').forEach((el) => {
      const name = el.getAttribute('data-icon');
      const size = parseInt(el.getAttribute('data-size') || '20', 10);
      const stroke = parseFloat(el.getAttribute('data-stroke') || '1.6');
      el.innerHTML = makeIcon(name, size, stroke);
      el.classList.add('icon-host');
    });
  }

  // Coin icons (crypto symbols) - mini circle badges
  function coinIcon(sym) {
    const s = (sym || '').toUpperCase();
    const map = {
      BTC: { c: '#f7931a', t: '₿' }, ETH: { c: '#627eea', t: 'Ξ' },
      USDT: { c: '#26a17b', t: '₮' }, BNB: { c: '#f3ba2f', t: 'B' },
      XRP: { c: '#23292f', t: 'X' }, ADA: { c: '#0033ad', t: 'A' },
      DOGE: { c: '#c2a633', t: 'Ð' }, SOL: { c: '#9945ff', t: '◎' },
      TRX: { c: '#ff060a', t: 'T' }, DOT: { c: '#e6007a', t: '●' },
      MATIC: { c: '#8247e5', t: 'M' }, AVAX: { c: '#e84142', t: 'A' },
      LTC: { c: '#345d9d', t: 'Ł' }, LINK: { c: '#2a5ada', t: 'L' },
      UNI: { c: '#ff007a', t: 'U' }, SHIB: { c: '#ffa409', t: 'S' },
      ATOM: { c: '#2e3148', t: '⚛' }, XLM: { c: '#14b6e7', t: '✦' },
      NEAR: { c: '#00ec97', t: 'N' }, APT: { c: '#06b6d4', t: 'A' },
      FIL: { c: '#0090ff', t: 'F' }, ARB: { c: '#28a0f0', t: '◆' },
      OP: { c: '#ff0420', t: 'O' }, INJ: { c: '#00d2ff', t: 'I' },
      SUI: { c: '#4da2ff', t: 'S' }, TIA: { c: '#7b2bf9', t: 'T' }
    };
    const info = map[s] || { c: '#5ee7ff', t: s.slice(0, 1) };
    return `<span class="coin-badge" style="background:${info.c}22; color:${info.c}; border:1px solid ${info.c}44">${info.t}</span>`;
  }

  // Flag icons (country code → emoji flag, used sparingly only for forex/health)
  function flagIcon(code) {
    if (!code || code.length !== 2) return '';
    const A = 0x1F1E6;
    const chars = code.toUpperCase().split('').map((c) => A + c.charCodeAt(0) - 65);
    return chars.map((c) => String.fromCodePoint(c)).join('');
  }

  // Weather icon mapping (WMO codes → icon name)
  function weatherIcon(code) {
    if (code == null) return 'cloud';
    if (code === 0) return 'sun';
    if (code === 1) return 'sunCloud';
    if (code === 2) return 'cloudSun';
    if (code === 3) return 'cloud2';
    if (code >= 45 && code <= 48) return 'cloudFog';
    if (code >= 51 && code <= 57) return 'cloudDrizzle';
    if (code >= 61 && code <= 67) return 'cloudRain';
    if (code >= 71 && code <= 77) return 'cloudSnow';
    if (code >= 80 && code <= 82) return 'cloudRain';
    if (code >= 85 && code <= 86) return 'cloudSnow';
    if (code >= 95 && code <= 99) return 'cloudLightning';
    return 'cloud2';
  }

  const icons = { ICONS, LOGO_SVG, makeIcon, hydrate, coinIcon, flagIcon, weatherIcon };

  global.TP = global.TP || {};
  global.TP.icons = icons;
})(window);
