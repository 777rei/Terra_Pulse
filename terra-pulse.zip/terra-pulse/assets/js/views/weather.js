/* TERRA PULSE — Weather view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const CITIES = [
    { name: 'London', lat: 51.5074, lng: -0.1278, country: 'UK' },
    { name: 'New York', lat: 40.7128, lng: -74.0060, country: 'USA' },
    { name: 'Tokyo', lat: 35.6762, lng: 139.6503, country: 'Japan' },
    { name: 'Sydney', lat: -33.8688, lng: 151.2093, country: 'Australia' },
    { name: 'Dubai', lat: 25.2048, lng: 55.2708, country: 'UAE' },
    { name: 'São Paulo', lat: -23.5505, lng: -46.6333, country: 'Brazil' },
    { name: 'Cape Town', lat: -33.9249, lng: 18.4241, country: 'South Africa' },
    { name: 'Mumbai', lat: 19.0760, lng: 72.8777, country: 'India' },
    { name: 'Moscow', lat: 55.7558, lng: 37.6173, country: 'Russia' },
    { name: 'Reykjavik', lat: 64.1466, lng: -21.9426, country: 'Iceland' },
    { name: 'Singapore', lat: 1.3521, lng: 103.8198, country: 'Singapore' },
    { name: 'Cairo', lat: 30.0444, lng: 31.2357, country: 'Egypt' }
  ];

  const view = {
    id: 'weather',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 5 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-weather');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Global Weather</h1>
            <p class="view-sub">Live conditions across major cities. Search any location worldwide.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Open-Meteo</span>
            <span class="chip" id="weatherUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('search', 18)} Search Location</h2></div>
          <div class="flex gap-12" style="flex-wrap:wrap">
            <input type="search" id="weatherSearch" class="input" style="flex:1; min-width:240px" placeholder="Search any city e.g. Paris, Tokyo, Denver…" />
            <button class="btn btn-primary" id="weatherSearchBtn">Search</button>
            <button class="btn btn-ghost" id="weatherGeoBtn">${icons.makeIcon('location', 16)} My location</button>
          </div>
          <div id="weatherSearchResults" style="margin-top:10px"></div>
        </div>

        <div class="tile mb-12" id="weatherDetailTile" hidden>
          <div class="tile-head"><h2 id="weatherDetailTitle">Selected location</h2><button class="btn btn-ghost" id="weatherCloseDetail">${icons.makeIcon('close', 16)} Close</button></div>
          <div id="weatherDetailBody"></div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('sunCloud', 18)} Major Cities Weather</h2></div>
          <div class="weather-strip" id="weatherCities"></div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('thermometer', 18)} Temperature Heatmap</h2></div>
          <div id="weatherHeatmap" class="table-wrap"></div>
        </div>
      `;

      utils.id('weatherSearchBtn').addEventListener('click', () => this.search());
      utils.id('weatherSearch').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.search(); });
      utils.id('weatherGeoBtn').addEventListener('click', () => this.useGeo());
      utils.id('weatherCloseDetail').addEventListener('click', () => {
        utils.id('weatherDetailTile').hidden = true;
      });
    },

    async refresh() {
      await this.refreshCities();
      const updEl = utils.id('weatherUpdated');
      if (updEl) updEl.textContent = 'Updated ' + utils.fmt.time(new Date());
    },

    async refreshCities() {
      const el = utils.id('weatherCities');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(6);
      try {
        const results = await api.weather.currentBatch(CITIES);
        this.citiesData = results;
        el.innerHTML = results.map((r, i) => {
          if (!r.data) {
            return `<div class="weather-card"><div class="weather-city">${utils.escapeHtml(r.name)}</div><div class="icon-host">${icons.makeIcon('cloud', 28)}</div><div class="weather-temp">—</div><div class="weather-desc">N/A</div></div>`;
          }
          const c = r.data.current;
          const code = c.weather_code;
          return `
            <div class="weather-card" data-i="${i}">
              <div class="weather-city">${utils.escapeHtml(r.name)}</div>
              <div class="icon-host" style="margin:6px 0; color:${utils.color.temp(c.temperature_2m)}">${icons.makeIcon(icons.weatherIcon(code), 32)}</div>
              <div class="weather-temp" style="color:${utils.color.temp(c.temperature_2m)}">${Math.round(c.temperature_2m)}°C</div>
              <div class="weather-desc">${utils.escapeHtml(utils.weatherDesc(code))}</div>
              <div class="weather-extra">${icons.makeIcon('droplet', 12)} ${c.relative_humidity_2m}% · ${icons.makeIcon('wind', 12)} ${Math.round(c.wind_speed_10m)} km/h</div>
            </div>
          `;
        }).join('');
        el.querySelectorAll('.weather-card[data-i]').forEach((card) => {
          card.addEventListener('click', () => this.showDetail(parseInt(card.dataset.i, 10)));
        });

        const heatEl = utils.id('weatherHeatmap');
        if (heatEl) {
          const sorted = [...results].filter((r) => r.data).sort((a, b) => b.data.current.temperature_2m - a.data.current.temperature_2m);
          heatEl.innerHTML = `
            <table class="data">
              <thead><tr><th>City</th><th>Temp</th><th>Feels like</th><th>Humidity</th><th>Wind</th><th>Conditions</th></tr></thead>
              <tbody>
                ${sorted.map((r) => `
                  <tr>
                    <td>${utils.escapeHtml(r.name)}</td>
                    <td class="num" style="color:${utils.color.temp(r.data.current.temperature_2m)}; font-weight:700">${r.data.current.temperature_2m.toFixed(1)}°C</td>
                    <td class="num">${r.data.current.apparent_temperature?.toFixed(1) || '—'}°C</td>
                    <td class="num">${r.data.current.relative_humidity_2m}%</td>
                    <td class="num">${Math.round(r.data.current.wind_speed_10m)} km/h</td>
                    <td>${icons.makeIcon(icons.weatherIcon(r.data.current.weather_code), 14)} ${utils.escapeHtml(utils.weatherDesc(r.data.current.weather_code))}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          `;
        }
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Weather data unavailable</div>';
      }
    },

    async search() {
      const q = utils.id('weatherSearch').value.trim();
      if (!q) return;
      const resEl = utils.id('weatherSearchResults');
      resEl.innerHTML = '<span class="spinner"></span> Searching…';
      try {
        const data = await api.geocode.search(q);
        if (!data?.results?.length) {
          resEl.innerHTML = '<div class="text-dim text-sm">No results</div>';
          return;
        }
        resEl.innerHTML = '<div class="card-grid">' + data.results.map((r, i) => `
          <div class="card" data-i="${i}" style="cursor:pointer">
            <div class="card-title">${utils.escapeHtml(r.name)}</div>
            <div class="text-xs text-dim">${utils.escapeHtml([r.admin1, r.country].filter(Boolean).join(', '))}</div>
            <div class="text-xs text-dim" style="margin-top:4px">${r.latitude.toFixed(2)}°, ${r.longitude.toFixed(2)}°</div>
          </div>
        `).join('') + '</div>';
        resEl.querySelectorAll('.card[data-i]').forEach((c) => {
          c.addEventListener('click', () => this.showLocationDetail(data.results[parseInt(c.dataset.i, 10)]));
        });
      } catch (e) {
        resEl.innerHTML = '<div class="text-dim text-sm">Search failed</div>';
      }
    },

    async useGeo() {
      if (!navigator.geolocation) {
        global.TP.app.toast('Geolocation not supported', 'error');
        return;
      }
      global.TP.app.toast('Getting your location…', 'info');
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const { latitude, longitude } = pos.coords;
        const rev = await api.geocode.reverse(latitude, longitude);
        this.showLocationDetail({
          name: rev?.city || rev?.locality || 'Your location',
          country: rev?.countryName || '',
          latitude, longitude
        });
      }, (err) => {
        global.TP.app.toast('Location access denied', 'error');
      }, { timeout: 10000 });
    },

    async showDetail(i) {
      const r = this.citiesData[i];
      if (!r) return;
      this.showLocationDetail({ name: r.name, country: r.country, latitude: r.lat, longitude: r.lng });
    },

    async showLocationDetail(loc) {
      const tile = utils.id('weatherDetailTile');
      const title = utils.id('weatherDetailTitle');
      const body = utils.id('weatherDetailBody');
      tile.hidden = false;
      title.textContent = `${loc.name}${loc.country ? ', ' + loc.country : ''}`;
      body.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(3);

      try {
        const [w, aq] = await Promise.allSettled([
          api.weather.current(loc.latitude, loc.longitude),
          api.weather.airQuality(loc.latitude, loc.longitude)
        ]);
        const data = w.status === 'fulfilled' ? w.value : null;
        const aqData = aq.status === 'fulfilled' ? aq.value : null;
        if (!data) {
          body.innerHTML = '<div class="text-dim">Weather data unavailable</div>';
          return;
        }
        const c = data.current;
        const code = c.weather_code;
        const hourly = data.hourly;
        const aqi = aqData?.current?.us_aqi;
        const [aqColor, aqLabel] = utils.color.aqi(aqi);

        const temps = (hourly?.temperature_2m || []).slice(0, 24);
        const precip = (hourly?.precipitation_probability || []).slice(0, 24);
        const maxT = Math.max(...temps);
        const minT = Math.min(...temps);
        const chartW = 600, chartH = 120, pad = 20;
        const stepX = (chartW - pad * 2) / (temps.length - 1);
        const points = temps.map((t, i) => {
          const x = pad + i * stepX;
          const y = chartH - pad - ((t - minT) / (maxT - minT || 1)) * (chartH - pad * 2);
          return `${x},${y}`;
        }).join(' ');

        body.innerHTML = `
          <div class="flex gap-12" style="flex-wrap:wrap; margin-bottom:14px">
            <div class="flex center gap-12">
              <div class="icon-host" style="color:${utils.color.temp(c.temperature_2m)}">${icons.makeIcon(icons.weatherIcon(code), 56)}</div>
              <div>
                <div style="font-size:36px; font-weight:700; color:${utils.color.temp(c.temperature_2m)}">${Math.round(c.temperature_2m)}°C</div>
                <div class="text-sm text-dim">Feels like ${Math.round(c.apparent_temperature)}°C · ${utils.escapeHtml(utils.weatherDesc(code))}</div>
              </div>
            </div>
            <div class="card-grid" style="flex:1; min-width:280px">
              <div class="card-row"><span class="label">${icons.makeIcon('droplet', 14)} Humidity</span><span class="value">${c.relative_humidity_2m}%</span></div>
              <div class="card-row"><span class="label">${icons.makeIcon('wind', 14)} Wind</span><span class="value">${Math.round(c.wind_speed_10m)} km/h ${this.windDir(c.wind_direction_10m)}</span></div>
              <div class="card-row"><span class="label">${icons.makeIcon('cloud', 14)} Cloud cover</span><span class="value">${c.cloud_cover}%</span></div>
              <div class="card-row"><span class="label">${icons.makeIcon('gauge', 14)} Pressure</span><span class="value">${Math.round(c.pressure_msl)} hPa</span></div>
              <div class="card-row"><span class="label">${icons.makeIcon('sun', 14)} UV index</span><span class="value">${c.uv_index?.toFixed(1) || '—'}</span></div>
              <div class="card-row"><span class="label">${icons.makeIcon('rain', 14)} Precipitation</span><span class="value">${c.precipitation?.toFixed(1) || 0} mm</span></div>
              ${aqi ? `<div class="card-row"><span class="label">${icons.makeIcon('air', 14)} Air quality</span><span class="value"><span class="pill" style="background:${aqColor}22; color:${aqColor}">${aqLabel} · AQI ${aqi}</span></span></div>` : ''}
            </div>
          </div>

          <h3 style="font-size:13px; margin:16px 0 8px">Next 24 hours</h3>
          <svg viewBox="0 0 ${chartW} ${chartH}" style="width:100%; height:auto; max-height:200px">
            <polyline points="${pad},${chartH-pad/2} ${points} ${chartW-pad},${chartH-pad/2}" fill="rgba(94,231,255,.08)" stroke="none"/>
            <polyline points="${points}" fill="none" stroke="#5ee7ff" stroke-width="2"/>
            ${temps.map((t, i) => {
              if (i % 3 !== 0) return '';
              const x = pad + i * stepX;
              const y = chartH - pad - ((t - minT) / (maxT - minT || 1)) * (chartH - pad * 2);
              return `<text x="${x}" y="${y - 6}" font-size="9" fill="#aeb8d8" text-anchor="middle">${Math.round(t)}°</text>`;
            }).join('')}
            <line x1="${pad}" y1="${chartH-pad}" x2="${chartW-pad}" y2="${chartH-pad}" stroke="rgba(120,180,255,.2)" stroke-width="0.5"/>
          </svg>
          <div class="text-xs text-dim" style="margin-top:6px">Min ${minT.toFixed(1)}°C · Max ${maxT.toFixed(1)}°C</div>

          ${precip.some((p) => p > 30) ? `
            <h3 style="font-size:13px; margin:16px 0 8px">Precipitation probability (%)</h3>
            <svg viewBox="0 0 ${chartW} 60" style="width:100%; height:auto">
              ${precip.map((p, i) => {
                const x = pad + i * stepX;
                const h = (p / 100) * 50;
                return `<rect x="${x - 4}" y="${55 - h}" width="8" height="${h}" fill="#5ec3ff" rx="1"/>`;
              }).join('')}
            </svg>
          ` : ''}
        `;
      } catch (e) {
        body.innerHTML = '<div class="text-dim">Failed to load detail</div>';
      }
    },

    windDir(deg) {
      const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
      return dirs[Math.round(deg / 45) % 8];
    }
  };

  // Weather description helper
  utils.weatherDesc = utils.weatherDesc || function (code) {
    const m = {
      0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
      45: 'Fog', 48: 'Rime fog', 51: 'Light drizzle', 53: 'Moderate drizzle',
      55: 'Dense drizzle', 56: 'Freezing drizzle', 57: 'Freezing dense drizzle',
      61: 'Slight rain', 63: 'Moderate rain', 65: 'Heavy rain', 66: 'Freezing rain',
      67: 'Heavy freezing rain', 71: 'Slight snow', 73: 'Moderate snow', 75: 'Heavy snow',
      77: 'Snow grains', 80: 'Slight rain showers', 81: 'Moderate rain showers',
      82: 'Violent rain showers', 85: 'Slight snow showers', 86: 'Heavy snow showers',
      95: 'Thunderstorm', 96: 'Thunderstorm w/ hail', 99: 'Severe thunderstorm'
    };
    return m[code] || 'Unknown';
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.weather = view;
})(window);
