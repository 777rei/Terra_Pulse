/* TERRA PULSE — World Map view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'worldmap',
    initialized: false,
    map: null,
    timer: null,

    async init() {
      if (this.initialized) return;
      this.initialized = true;
      await this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 30_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    async render() {
      const root = utils.id('view-worldmap');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Live World Map</h1>
            <p class="view-sub">Earthquakes, ISS track, and live global events. Hover markers for details.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Live</span>
            <span class="chip" id="wmCount">0 events</span>
            <span class="chip" id="wmUpdated">—</span>
          </div>
        </div>

        <div class="flex gap-12 mb-12" style="flex-wrap:wrap">
          <label class="switch"><input type="checkbox" id="wmEq" checked><span class="track"></span><span>Earthquakes</span></label>
          <label class="switch"><input type="checkbox" id="wmIss" checked><span class="track"></span><span>ISS position</span></label>
          <label class="switch"><input type="checkbox" id="wmCities" checked><span class="track"></span><span>City labels</span></label>
          <button class="btn btn-ghost" id="wmRefresh">${icons.makeIcon('refresh', 16)} Refresh</button>
        </div>

        <div class="tile" style="padding:8px">
          <div id="wmMap" style="min-height:520px"></div>
        </div>

        <div class="tile-grid mt-16">
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('earthquake', 18)} Earthquake Magnitude Legend</h2></div>
            <div style="padding:8px 0">
              <div class="flex between" style="padding:6px 0"><span>M &lt; 3</span><span class="pill pill-info">Minor</span></div>
              <div class="flex between" style="padding:6px 0"><span>M 3–4</span><span class="pill pill-good">Light</span></div>
              <div class="flex between" style="padding:6px 0"><span>M 4–5</span><span class="pill pill-warn">Moderate</span></div>
              <div class="flex between" style="padding:6px 0"><span>M 5+</span><span class="pill pill-bad">Strong</span></div>
            </div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('rocket', 18)} Live ISS Telemetry</h2></div>
            <div id="wmIssInfo" class="iss-card"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Recent Events</h2></div>
            <div id="wmEventsList"></div>
          </div>
        </div>
      `;

      const mapEl = utils.id('wmMap');
      this.map = new global.TP.WorldMap(mapEl, { showCityLabels: true });

      ['wmEq', 'wmIss', 'wmCities'].forEach((id) => {
        utils.id(id).addEventListener('change', (e) => {
          if (id === 'wmEq') this.filters = { ...this.filters, earthquakes: e.target.checked };
          if (id === 'wmIss') this.filters = { ...this.filters, iss: e.target.checked };
          if (id === 'wmCities') this.map.opts.showCityLabels = e.target.checked;
          this.refresh();
        });
      });
      this.filters = { earthquakes: true, iss: true };
      utils.id('wmRefresh').addEventListener('click', () => this.refresh());
    },

    async refresh() {
      if (!this.map) return;
      const events = [];
      const eventList = [];

      if (this.filters?.earthquakes !== false) {
        try {
          const q = await api.earthquakes.summary('day');
          for (const f of (q?.features || []).slice(0, 100)) {
            const mag = f.properties?.mag || 0;
            const [lng, lat] = f.geometry?.coordinates || [];
            if (lat == null || lng == null) continue;
            let color = '#5ec3ff';
            if (mag >= 5) color = '#ff5e7a';
            else if (mag >= 4) color = '#ffcf5e';
            else if (mag >= 3) color = '#3ee68a';
            const ev = {
              lat, lng,
              color, size: Math.max(2, mag * 0.8),
              magnitude: mag.toFixed(1),
              title: f.properties?.place || 'Earthquake',
              text: 'Magnitude ' + mag.toFixed(1),
              time: f.properties?.time ? new Date(f.properties.time) : null
            };
            events.push(ev);
            eventList.push({ type: 'quake', ...ev });
          }
        } catch {}
      }

      if (this.filters?.iss !== false) {
        try {
          const iss = await api.space.iss();
          if (iss?.iss_position) {
            const lat = parseFloat(iss.iss_position.latitude);
            const lng = parseFloat(iss.iss_position.longitude);
            events.push({
              lat, lng,
              color: '#b07bff', size: 6,
              title: 'ISS',
              text: 'International Space Station',
              time: new Date(iss.timestamp * 1000)
            });
            const issEl = utils.id('wmIssInfo');
            if (issEl) {
              issEl.innerHTML = `
                <div class="iss-row"><span class="iss-label">Latitude</span><span class="iss-value">${lat.toFixed(4)}°</span></div>
                <div class="iss-row"><span class="iss-label">Longitude</span><span class="iss-value">${lng.toFixed(4)}°</span></div>
                <div class="iss-row"><span class="iss-label">Altitude</span><span class="iss-value">~408 km</span></div>
                <div class="iss-row"><span class="iss-label">Speed</span><span class="iss-value">~27,600 km/h</span></div>
                <div class="iss-row"><span class="iss-label">Orbit period</span><span class="iss-value">~92 min</span></div>
                <div class="iss-row"><span class="iss-label">Last update</span><span class="iss-value">${utils.fmt.time(new Date(iss.timestamp * 1000))}</span></div>
              `;
            }
          }
        } catch {}
      }

      this.map.setEvents(events);
      const cntEl = utils.id('wmCount');
      if (cntEl) cntEl.textContent = events.length + ' events';
      const updEl = utils.id('wmUpdated');
      if (updEl) updEl.textContent = 'Updated ' + utils.fmt.time(new Date());

      const listEl = utils.id('wmEventsList');
      if (listEl) {
        eventList.sort((a, b) => (b.magnitude || 0) - (a.magnitude || 0));
        listEl.innerHTML = eventList.slice(0, 15).map((e) => `
          <div class="flex gap-8 center" style="padding:8px 0; border-bottom:1px solid var(--glass-border-2)">
            <span class="quake-mag ${utils.color.mag(parseFloat(e.magnitude) || 0)}">M${e.magnitude || '—'}</span>
            <div style="flex:1; min-width:0">
              <div class="text-sm">${utils.escapeHtml(e.title)}</div>
              <div class="text-xs text-dim">${e.lat.toFixed(2)}°, ${e.lng.toFixed(2)}° · ${e.time ? utils.fmt.relative(e.time) : ''}</div>
            </div>
          </div>
        `).join('') || '<div class="text-dim text-sm">No events</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.worldmap = view;
})(window);
