/* TERRA PULSE — Astronomy view */
(function (global) {
  'use strict';
  const { utils, icons } = global.TP;

  const view = {
    id: 'astronomy',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.tick();
      this.timer = setInterval(() => this.tick(), 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-astronomy');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Astronomy</h1>
            <p class="view-sub">Moon phase, sunrise/sunset times, and planetary positions — updated live.</p>
          </div>
          <div class="view-meta">
            <span class="chip" id="astroUpdated">—</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('moon', 18)} Moon Phase</h2></div>
            <div id="moonPhase"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('sunrise', 18)} Sun (Your Location)</h2></div>
            <div id="sunTimes"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('planet', 18)} Planets Today</h2></div>
            <div id="planets"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('calendar', 18)} Lunar Calendar (Next 30 Days)</h2></div>
            <div id="moonCal"></div>
          </div>
        </div>
      `;
    },

    tick() {
      this.refreshMoon();
      this.refreshSun();
      this.refreshPlanets();
      this.refreshCalendar();
      const el = utils.id('astroUpdated');
      if (el) el.textContent = 'Updated ' + utils.fmt.time(new Date());
    },

    refreshMoon() {
      const now = new Date();
      const phase = this.moonPhase(now);
      const phases = ['New Moon', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous', 'Full Moon', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent'];
      const phaseIdx = Math.floor(phase * 8) % 8;
      const iconNames = ['moon', 'moon', 'moon', 'moon', 'moon2', 'moon', 'moon', 'moon'];
      const colors = ['#7c87a8', '#aeb8d8', '#e9eefc', '#e9eefc', '#ffcf5e', '#e9eefc', '#aeb8d8', '#7c87a8'];

      utils.id('moonPhase').innerHTML = `
        <div style="text-align:center; padding:12px">
          <div class="icon-host" style="color:${colors[phaseIdx]}; margin-bottom:8px">${icons.makeIcon(iconNames[phaseIdx], 72)}</div>
          <div style="font-size:18px; font-weight:700; margin-top:8px">${phases[phaseIdx]}</div>
          <div class="text-sm text-dim" style="margin-top:4px">${(phase * 100).toFixed(1)}% illuminated</div>
        </div>
        <div class="card-row"><span class="label">Moon age</span><span class="value">${(phase * 29.53).toFixed(1)} days</span></div>
        <div class="card-row"><span class="label">Next full moon</span><span class="value">${this.nextFullMoon(now).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span></div>
        <div class="card-row"><span class="label">Next new moon</span><span class="value">${this.nextNewMoon(now).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span></div>
      `;
    },

    moonPhase(date) {
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      const day = date.getDate();
      let r = year % 100;
      r %= 19;
      if (r > 9) r -= 19;
      r = ((r * 11) % 30) + month + day;
      if (month < 3) r += 2;
      r -= (year < 2000) ? 4 : 8.3;
      r = Math.floor(r + 0.5) % 30;
      return r < 0 ? (r + 30) / 30 : r / 30;
    },

    nextFullMoon(date) {
      let d = new Date(date);
      for (let i = 0; i < 30; i++) {
        d.setDate(d.getDate() + 1);
        const p = this.moonPhase(d);
        if (p > 0.49 && p < 0.52) return d;
      }
      return d;
    },

    nextNewMoon(date) {
      let d = new Date(date);
      for (let i = 0; i < 30; i++) {
        d.setDate(d.getDate() + 1);
        const p = this.moonPhase(d);
        if (p < 0.02 || p > 0.98) return d;
      }
      return d;
    },

    refreshSun() {
      const now = new Date();
      const lat = 40;
      const dayOfYear = Math.floor((now - new Date(now.getFullYear(), 0, 0)) / 86400000);
      const decl = 23.45 * Math.sin((360 / 365) * (dayOfYear - 81) * Math.PI / 180);
      const cosH = -Math.tan(lat * Math.PI / 180) * Math.tan(decl * Math.PI / 180);
      const H = Math.acos(Math.max(-1, Math.min(1, cosH))) * 180 / Math.PI;
      const dayLength = (2 * H) / 15;
      const sunriseH = 12 - dayLength / 2;
      const sunsetH = 12 + dayLength / 2;
      const fmtH = (h) => {
        const hh = Math.floor(h);
        const mm = Math.floor((h - hh) * 60);
        return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
      };

      utils.id('sunTimes').innerHTML = `
        <div class="card-row"><span class="label">${icons.makeIcon('sunrise', 14)} Sunrise</span><span class="value">${fmtH(sunriseH)}</span></div>
        <div class="card-row"><span class="label">${icons.makeIcon('sun', 14)} Solar noon</span><span class="value">${fmtH(12)}</span></div>
        <div class="card-row"><span class="label">${icons.makeIcon('sunset', 14)} Sunset</span><span class="value">${fmtH(sunsetH)}</span></div>
        <div class="card-row"><span class="label">Day length</span><span class="value">${Math.floor(dayLength)}h ${Math.floor((dayLength % 1) * 60)}m</span></div>
        <div class="card-row"><span class="label">Sun declination</span><span class="value">${decl.toFixed(2)}°</span></div>
        <div class="card-row"><span class="label">Solar altitude at noon</span><span class="value">${(90 - lat + decl).toFixed(1)}°</span></div>
      `;
    },

    refreshPlanets() {
      const now = new Date();
      const planets = [
        { name: 'Mercury', icon: 'planet', period: 88, color: '#a8a8a8' },
        { name: 'Venus', icon: 'planet', period: 225, color: '#ffcf5e' },
        { name: 'Mars', icon: 'mars', period: 687, color: '#ff5e7a' },
        { name: 'Jupiter', icon: 'planet', period: 4333, color: '#ff9c5e' },
        { name: 'Saturn', icon: 'saturn', period: 10759, color: '#ffcf5e' },
        { name: 'Uranus', icon: 'planet', period: 30687, color: '#5ec3ff' },
        { name: 'Neptune', icon: 'planet', period: 60190, color: '#5ee7ff' }
      ];
      utils.id('planets').innerHTML = planets.map((p) => {
        const dayOfYear = Math.floor((now - new Date(now.getFullYear(), 0, 0)) / 86400000);
        const angle = ((dayOfYear / p.period) * 360) % 360;
        return `
          <div class="card-row">
            <span class="label">${icons.makeIcon(p.icon, 14)} ${p.name}</span>
            <span class="value" style="color:${p.color}">${angle.toFixed(1)}° orbit</span>
          </div>
        `;
      }).join('');
    },

    refreshCalendar() {
      const calEl = utils.id('moonCal');
      if (!calEl) return;
      const today = new Date();
      const days = [];
      for (let i = 0; i < 30; i++) {
        const d = new Date(today);
        d.setDate(d.getDate() + i);
        const p = this.moonPhase(d);
        const phaseIdx = Math.floor(p * 8) % 8;
        const colors = ['#7c87a8', '#aeb8d8', '#e9eefc', '#e9eefc', '#ffcf5e', '#e9eefc', '#aeb8d8', '#7c87a8'];
        days.push({ d, p, color: colors[phaseIdx] });
      }
      calEl.innerHTML = `
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(80px, 1fr)); gap:8px">
          ${days.map((day) => `
            <div class="card" style="text-align:center; padding:8px">
              <div class="icon-host" style="color:${day.color}; margin-bottom:2px">${icons.makeIcon('moon', 24)}</div>
              <div class="text-xs text-dim" style="margin-top:2px">${day.d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</div>
            </div>
          `).join('')}
        </div>
      `;
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.astronomy = view;
})(window);
