/* TERRA PULSE — Population view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'population',
    initialized: false,
    timer: null,
    countries: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 1_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-population');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">World Population</h1>
            <p class="view-sub">Live world population counter with country breakdown.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Live estimate</span>
            <span class="chip" id="popUpdated">—</span>
          </div>
        </div>

        <div class="kpi-grid">
          <div class="kpi kpi-1">
            <div class="kpi-label">World Population</div>
            <div class="kpi-value" id="popTotal">—</div>
            <div class="kpi-meta">people on Earth right now</div>
          </div>
          <div class="kpi kpi-3">
            <div class="kpi-label">Births Today</div>
            <div class="kpi-value" id="popBirths">—</div>
            <div class="kpi-meta">since midnight UTC</div>
          </div>
          <div class="kpi kpi-4">
            <div class="kpi-label">Deaths Today</div>
            <div class="kpi-value" id="popDeaths">—</div>
            <div class="kpi-meta">since midnight UTC</div>
          </div>
          <div class="kpi kpi-2">
            <div class="kpi-label">Net Growth Today</div>
            <div class="kpi-value" id="popGrowth">—</div>
            <div class="kpi-meta">+people since midnight</div>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('trophy', 18)} Top 30 Countries by Population</h2></div>
            <div id="popTable" class="table-wrap"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('gauge', 18)} Quick Stats</h2></div>
            <div id="popStats"></div>
          </div>
        </div>
      `;
    },

    async refresh() {
      const p = api.population.snapshot();
      const totalEl = utils.id('popTotal');
      const birthsEl = utils.id('popBirths');
      const deathsEl = utils.id('popDeaths');
      const growthEl = utils.id('popGrowth');

      if (totalEl) {
        const prev = parseInt(totalEl.dataset.value || '0', 10);
        utils.animateNumber(totalEl, prev, p.total, 800, (n) => utils.fmt.int(Math.floor(n)));
        totalEl.dataset.value = p.total;
      }
      if (birthsEl) birthsEl.textContent = utils.fmt.int(p.birthsToday);
      if (deathsEl) deathsEl.textContent = utils.fmt.int(p.deathsToday);
      if (growthEl) growthEl.textContent = '+' + utils.fmt.int(p.growthToday);

      const updEl = utils.id('popUpdated');
      if (updEl) updEl.textContent = 'Updated ' + utils.fmt.time(new Date());

      if (!this.countries) {
        try {
          this.countries = await api.population.byCountry();
          if (this.countries) this.renderCountries();
        } catch {}
      }
    },

    renderCountries() {
      const tableEl = utils.id('popTable');
      const statsEl = utils.id('popStats');
      if (!tableEl) return;
      const sorted = [...this.countries].sort((a, b) => (b.population || 0) - (a.population || 0));
      tableEl.innerHTML = `
        <table class="data">
          <thead><tr><th>#</th><th>Country</th><th>Population</th><th>Region</th><th>Capital</th><th>Flag</th></tr></thead>
          <tbody>
            ${sorted.slice(0, 30).map((c, i) => `
              <tr>
                <td class="num">${i + 1}</td>
                <td style="font-weight:600">${utils.escapeHtml(c.name?.common || c.name?.official)}</td>
                <td class="num">${utils.fmt.int(c.population)}</td>
                <td>${utils.escapeHtml(c.region || '—')}</td>
                <td>${utils.escapeHtml(c.capital?.[0] || '—')}</td>
                <td>${c.flags?.emoji || ''}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;

      const total = sorted.reduce((s, c) => s + (c.population || 0), 0);
      const top10 = sorted.slice(0, 10).reduce((s, c) => s + (c.population || 0), 0);
      const regions = {};
      for (const c of sorted) {
        const r = c.region || 'Other';
        regions[r] = (regions[r] || 0) + (c.population || 0);
      }
      statsEl.innerHTML = `
        <div class="card-row"><span class="label">Total countries</span><span class="value">${sorted.length}</span></div>
        <div class="card-row"><span class="label">Total population</span><span class="value">${utils.fmt.compact(total)}</span></div>
        <div class="card-row"><span class="label">Top 10 share</span><span class="value">${((top10 / total) * 100).toFixed(1)}%</span></div>
        <div class="card-row"><span class="label">Largest country</span><span class="value">${utils.escapeHtml(sorted[0]?.name?.common || '—')}</span></div>
        <div class="card-row"><span class="label">Smallest</span><span class="value">${utils.escapeHtml(sorted[sorted.length - 1]?.name?.common || '—')}</span></div>
        <div class="card-row"><span class="label">Avg per country</span><span class="value">${utils.fmt.compact(total / sorted.length)}</span></div>
        ${Object.entries(regions).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([r, p]) => `
          <div class="card-row"><span class="label">${utils.escapeHtml(r)}</span><span class="value">${utils.fmt.compact(p)}</span></div>
        `).join('')}
      `;
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.population = view;
})(window);
