/* TERRA PULSE — Marine view (wave heights, sea temps) */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const COASTAL = [
    { name: 'Miami', lat: 25.7617, lng: -80.1918 },
    { name: 'Sydney', lat: -33.8688, lng: 151.2093 },
    { name: 'Tokyo', lat: 35.6762, lng: 139.6503 },
    { name: 'Rio de Janeiro', lat: -22.9068, lng: -43.1729 },
    { name: 'Cape Town', lat: -33.9249, lng: 18.4241 },
    { name: 'Barcelona', lat: 41.3851, lng: 2.1734 },
    { name: 'Honolulu', lat: 21.3099, lng: -157.8581 },
    { name: 'Mumbai', lat: 19.0760, lng: 72.8777 },
    { name: 'Singapore', lat: 1.3521, lng: 103.8198 },
    { name: 'Dubai', lat: 25.2048, lng: 55.2708 }
  ];

  const view = {
    id: 'marine',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 30 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-marine');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Marine Conditions</h1>
            <p class="view-sub">Wave heights, sea temperatures, and ocean conditions across coastal cities.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Open-Meteo Marine</span>
            <span class="chip" id="marineUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('wave', 18)} Wave Height Heatmap</h2></div>
          <div id="marineHeatmap" class="heatmap-grid"></div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Coastal Details</h2></div>
          <div id="marineTable" class="table-wrap"></div>
        </div>
      `;
    },

    async refresh() {
      const heatEl = utils.id('marineHeatmap');
      const tableEl = utils.id('marineTable');
      if (!heatEl) return;
      heatEl.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(6);
      try {
        const results = await Promise.allSettled(
          COASTAL.map((c) => api.weather.marine(c.lat, c.lng).then((d) => ({ ...c, data: d })))
        );
        const data = results.filter((r) => r.status === 'fulfilled' && r.value.data).map((r) => r.value);

        // Heatmap: wave height as color
        heatEl.innerHTML = data.map((d) => {
          const wave = d.data.current?.wave_height ?? 0;
          const sst = d.data.current?.sea_surface_temperature ?? 0;
          // Color scale: green (calm) → yellow → red (rough)
          let color = '#3ee68a';
          if (wave >= 3) color = '#ff5e7a';
          else if (wave >= 1.5) color = '#ffcf5e';
          else if (wave >= 0.5) color = '#5ec3ff';
          const opacity = Math.min(0.9, 0.4 + wave / 5);
          return `
            <div class="heatmap-cell" style="background:${color}; opacity:${opacity}">
              <div class="hm-symbol">${icons.makeIcon('wave', 14)} ${utils.escapeHtml(d.name.split(' ')[0])}</div>
              <div class="hm-price">${wave.toFixed(1)} m</div>
              <div class="hm-change">${sst.toFixed(1)}°C sea</div>
            </div>
          `;
        }).join('');

        // Table
        tableEl.innerHTML = `
          <table class="data">
            <thead><tr><th>Coast</th><th>Wave Height</th><th>Wave Direction</th><th>Wave Period</th><th>Sea Temp</th></tr></thead>
            <tbody>
              ${data.map((d) => {
                const c = d.data.current;
                const dir = this.directionLabel(c.wave_direction);
                return `<tr>
                  <td style="font-weight:600">${utils.escapeHtml(d.name)}</td>
                  <td class="num">${(c.wave_height ?? 0).toFixed(2)} m</td>
                  <td class="num">${c.wave_direction ?? '—'}° (${dir})</td>
                  <td class="num">${(c.wave_period ?? 0).toFixed(1)} s</td>
                  <td class="num" style="color:${utils.color.temp(c.sea_surface_temperature)}">${(c.sea_surface_temperature ?? 0).toFixed(1)}°C</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        `;

        utils.id('marineUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        heatEl.innerHTML = '<div class="text-dim">Marine data unavailable</div>';
      }
    },

    directionLabel(deg) {
      if (deg == null) return '—';
      const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
      return dirs[Math.round(deg / 45) % 8];
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.marine = view;
})(window);
