/* TERRA PULSE — Hacker News view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'hackernews',
    initialized: false,
    timer: null,
    filter: 'front_page',

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 5 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-hackernews');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Hacker News</h1>
            <p class="view-sub">Top stories from Hacker News, refreshed every 5 minutes.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Algolia HN API</span>
            <span class="chip" id="hnUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="flex gap-8" style="flex-wrap:wrap">
            <button class="btn btn-primary" data-f="front_page">Front Page</button>
            <button class="btn" data-f="story">All Stories</button>
            <button class="btn" data-f="ask_hn">Ask HN</button>
            <button class="btn" data-f="show_hn">Show HN</button>
            <button class="btn" data-f="job">Jobs</button>
            <input type="search" id="hnSearch" class="input" style="flex:1; min-width:200px" placeholder="Search HN…" />
          </div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Stories</h2></div>
          <div id="hnList"></div>
        </div>
      `;

      this.root = root;
      root.querySelectorAll('[data-f]').forEach((b) => {
        b.addEventListener('click', () => {
          this.filter = b.dataset.f;
          root.querySelectorAll('[data-f]').forEach((x) => x.className = 'btn');
          b.className = 'btn btn-primary';
          this.refresh();
        });
      });
      utils.id('hnSearch').addEventListener('input', (e) => this.search(e.target.value));
    },

    async refresh() {
      const el = utils.id('hnList');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(5);
      try {
        const d = await api.news.hackernews('', this.filter);
        this.hits = d?.hits || [];
        this.renderHits(this.hits);
        utils.id('hnUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        el.innerHTML = '<div class="text-dim">Hacker News unavailable</div>';
      }
    },

    search(q) {
      if (!q) { this.renderHits(this.hits); return; }
      const filtered = this.hits.filter((h) =>
        (h.title || h.story_title || '').toLowerCase().includes(q.toLowerCase()) ||
        (h.author || '').toLowerCase().includes(q.toLowerCase())
      );
      this.renderHits(filtered);
    },

    renderHits(hits) {
      const el = utils.id('hnList');
      if (!el) return;
      if (!hits?.length) {
        el.innerHTML = '<div class="empty-state"><div class="icon-host">' + icons.makeIcon('news', 32) + '</div>No stories</div>';
        return;
      }
      el.innerHTML = hits.slice(0, 30).map((h, i) => `
        <div class="card" style="margin-bottom:10px; padding:14px">
          <div class="flex gap-12" style="align-items:flex-start">
            <span style="font-weight:700; color:#ffcf5e; min-width:32px">${i+1}.</span>
            <div style="flex:1; min-width:0">
              <a href="${utils.escapeHtml(h.url || h.story_url || 'https://news.ycombinator.com/item?id=' + h.objectID)}" target="_blank" rel="noopener" style="font-weight:600; font-size:14px; line-height:1.4">${utils.escapeHtml(h.title || h.story_title)}</a>
              <div class="text-xs text-dim" style="margin-top:4px">
                ${icons.makeIcon('arrowUp', 12)} ${h.points || 0} · ${icons.makeIcon('message', 12)} ${h.num_comments || 0} · by ${utils.escapeHtml(h.author)} · ${utils.fmt.relative(h.created_at_i * 1000)}
              </div>
              ${h.story_text ? `<div class="text-xs text-dim" style="margin-top:6px; line-height:1.5">${utils.escapeHtml(utils.truncate(h.story_text.replace(/<[^>]+>/g, ''), 200))}</div>` : ''}
            </div>
          </div>
        </div>
      `).join('');
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.hackernews = view;
})(window);
