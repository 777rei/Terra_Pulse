/* TERRA PULSE — Internet Stats view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'network',
    initialized: false,
    timer: null,
    history: [],

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 5_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-network');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Internet Stats</h1>
            <p class="view-sub">Real-time internet activity counters and your connection info.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Live</span>
            <span class="chip" id="netUpdated">—</span>
          </div>
        </div>

        <div class="kpi-grid" id="netKpis"></div>

        <div class="tile-grid">
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('network', 18)} Your Connection</h2></div>
            <div id="netInfo"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('speedometer', 18)} Speed Test</h2></div>
            <div id="speedTest">
              <button class="btn btn-primary" id="runSpeed">${icons.makeIcon('play', 16)} Run speed test</button>
              <div id="speedResult" style="margin-top:12px"></div>
            </div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('activity', 18)} Live Internet Activity</h2></div>
            <div id="netChart"></div>
          </div>
        </div>
      `;
      utils.id('runSpeed').addEventListener('click', () => this.runSpeedTest());
    },

    async refresh() {
      const stats = api.network.internetStats();
      utils.id('netKpis').innerHTML = `
        <div class="kpi kpi-1">
          <div class="kpi-label">Internet Users</div>
          <div class="kpi-value">${utils.fmt.compact(stats.users)}</div>
          <div class="kpi-meta">globally online</div>
        </div>
        <div class="kpi kpi-3">
          <div class="kpi-label">Emails Today</div>
          <div class="kpi-value">${utils.fmt.compact(stats.emailsToday)}</div>
          <div class="kpi-meta">sent since midnight</div>
        </div>
        <div class="kpi kpi-2">
          <div class="kpi-label">Google Searches Today</div>
          <div class="kpi-value">${utils.fmt.compact(stats.searchesToday)}</div>
          <div class="kpi-meta">since midnight</div>
        </div>
        <div class="kpi kpi-4">
          <div class="kpi-label">Tweets Today</div>
          <div class="kpi-value">${utils.fmt.compact(stats.tweetsToday)}</div>
          <div class="kpi-meta">since midnight</div>
        </div>
        <div class="kpi kpi-5">
          <div class="kpi-label">Data Created Today</div>
          <div class="kpi-value">${utils.fmt.compact(stats.dataTodayTB)} TB</div>
          <div class="kpi-meta">global data</div>
        </div>
        <div class="kpi kpi-6">
          <div class="kpi-label">Avg Ping (CF)</div>
          <div class="kpi-value" id="pingValue">—</div>
          <div class="kpi-meta">to cloudflare.com</div>
        </div>
      `;

      this.history.push(stats.users);
      if (this.history.length > 60) this.history.shift();
      this.updateChart();

      try {
        const [trace, ip] = await Promise.allSettled([api.network.trace(), api.network.ipinfo()]);
        const t = trace.status === 'fulfilled' ? trace.value : null;
        const i = ip.status === 'fulfilled' ? ip.value : null;
        utils.id('netInfo').innerHTML = `
          <div class="card-row"><span class="label">IP address</span><span class="value">${utils.escapeHtml(i?.ip || t?.ip || '—')}</span></div>
          <div class="card-row"><span class="label">Location</span><span class="value">${utils.escapeHtml([i?.city, i?.country_name].filter(Boolean).join(', ') || '—')}</span></div>
          <div class="card-row"><span class="label">ISP / ASN</span><span class="value">${utils.escapeHtml(i?.org || t?.loc || '—')}</span></div>
          <div class="card-row"><span class="label">Timezone</span><span class="value">${utils.escapeHtml(i?.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone)}</span></div>
          <div class="card-row"><span class="label">Lat / Lng</span><span class="value">${i?.latitude || '—'}, ${i?.longitude || '—'}</span></div>
          <div class="card-row"><span class="label">Browser</span><span class="value">${utils.escapeHtml(navigator.userAgent.split(' ').slice(-2).join(' '))}</span></div>
          <div class="card-row"><span class="label">Online</span><span class="value">${navigator.onLine ? 'Yes' : 'No'}</span></div>
          <div class="card-row"><span class="label">Connection</span><span class="value">${navigator.connection?.effectiveType || '—'} ${navigator.connection?.downlink ? '· ' + navigator.connection.downlink + ' Mbps' : ''}</span></div>
        `;
      } catch {}

      this.ping();
      utils.id('netUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
    },

    async ping() {
      const start = performance.now();
      try {
        await fetch('https://www.cloudflare.com/cdn-cgi/trace', { cache: 'no-store' });
        const ms = Math.round(performance.now() - start);
        const el = utils.id('pingValue');
        if (el) {
          el.textContent = ms + ' ms';
          el.style.color = ms < 50 ? '#3ee68a' : ms < 150 ? '#ffcf5e' : '#ff5e7a';
        }
      } catch {}
    },

    updateChart() {
      const el = utils.id('netChart');
      if (!el) return;
      const points = utils.sparkline(this.history, 600, 100);
      el.innerHTML = `
        <svg viewBox="0 0 600 120" style="width:100%; height:auto">
          <defs>
            <linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#5ee7ff" stop-opacity="0.4"/>
              <stop offset="100%" stop-color="#5ee7ff" stop-opacity="0"/>
            </linearGradient>
          </defs>
          <polyline points="30,100 ${points} 570,100" fill="url(#netGrad)"/>
          <polyline points="${points}" fill="none" stroke="#5ee7ff" stroke-width="2"/>
        </svg>
        <div class="text-xs text-dim" style="margin-top:6px">Internet users (live estimate, last ${this.history.length} samples)</div>
      `;
    },

    async runSpeedTest() {
      const el = utils.id('speedResult');
      el.innerHTML = '<span class="spinner"></span> Testing download speed…';
      try {
        const start = performance.now();
        const r = await fetch('https://speed.cloudflare.com/__down?bytes=1000000', { cache: 'no-store' });
        const buf = await r.arrayBuffer();
        const elapsed = (performance.now() - start) / 1000;
        const mbps = (buf.byteLength * 8 / 1_000_000) / elapsed;
        el.innerHTML = `
          <div class="card-row"><span class="label">Download</span><span class="value" style="color:#3ee68a; font-weight:700">${mbps.toFixed(2)} Mbps</span></div>
          <div class="card-row"><span class="label">Download time</span><span class="value">${elapsed.toFixed(2)} s</span></div>
          <div class="card-row"><span class="label">Data</span><span class="value">${(buf.byteLength / 1_000_000).toFixed(1)} MB</span></div>
          <div class="text-xs text-dim" style="margin-top:8px">Indicative only — not a lab-grade measurement.</div>
        `;
      } catch (e) {
        el.innerHTML = '<div class="text-dim text-sm">Speed test failed (CORS or network)</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.network = view;
})(window);
