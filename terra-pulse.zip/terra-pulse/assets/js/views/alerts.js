/* TERRA PULSE — Alerts view */
(function (global) {
  'use strict';
  const { utils, api, store, icons } = global.TP;

  const view = {
    id: 'alerts',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-alerts');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Global Alerts</h1>
            <p class="view-sub">Significant earthquakes, tsunami warnings, and space weather alerts.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Live</span>
            <span class="chip" id="alertUpdated">—</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('alert', 18)} Significant Earthquakes (Past Week)</h2></div>
            <div id="sigQuakes"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('wave', 18)} Tsunami Flags</h2></div>
            <div id="tsunamiAlerts"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('zap', 18)} Space Weather</h2></div>
            <div id="spaceAlerts"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('bell', 18)} App Notifications</h2><button class="link-btn" id="clearNotif2">Clear</button></div>
            <div id="appNotifs"></div>
          </div>
        </div>
      `;
      utils.id('clearNotif2').addEventListener('click', () => {
        store.clearNotifications();
        this.renderNotifs();
      });
    },

    async refresh() {
      await Promise.allSettled([
        this.refreshSigQuakes(),
        this.refreshTsunami(),
        this.refreshSpace(),
        this.renderNotifs()
      ]);
      const el = utils.id('alertUpdated');
      if (el) el.textContent = 'Updated ' + utils.fmt.time(new Date());
    },

    async refreshSigQuakes() {
      const el = utils.id('sigQuakes');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(3);
      try {
        const q = await api.earthquakes.significant();
        const features = q?.features || [];
        if (!features.length) {
          const daily = await api.earthquakes.summary('week');
          const sig = (daily?.features || []).filter((f) => (f.properties?.mag || 0) >= 5).slice(0, 10);
          if (!sig.length) {
            el.innerHTML = '<div class="empty-state"><div class="icon-host">' + icons.makeIcon('success', 32) + '</div>No significant earthquakes this week</div>';
            return;
          }
          this.renderQuakes(el, sig);
          return;
        }
        this.renderQuakes(el, features);
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">USGS feed unavailable</div>';
      }
    },

    renderQuakes(el, features) {
      el.innerHTML = features.map((f) => {
        const mag = f.properties?.mag || 0;
        const place = f.properties?.place || 'Unknown';
        const [lng, lat, depth] = f.geometry?.coordinates || [];
        const time = f.properties?.time ? new Date(f.properties.time) : null;
        const color = mag >= 6 ? '#ff5e7a' : mag >= 5 ? '#ffcf5e' : '#3ee68a';
        return `
          <div class="card" style="margin-bottom:8px; padding:12px; border-left:3px solid ${color}">
            <div class="flex between center">
              <div>
                <span class="quake-mag ${utils.color.mag(mag)}" style="background:${color}22; color:${color}">M${mag.toFixed(1)}</span>
                <span style="margin-left:8px; font-weight:600">${utils.escapeHtml(place)}</span>
              </div>
              <div class="text-xs text-dim">${time ? utils.fmt.relative(time) : ''}</div>
            </div>
            <div class="text-xs text-dim" style="margin-top:6px">${icons.makeIcon('location', 12)} ${lat?.toFixed(2)}°, ${lng?.toFixed(2)}° · Depth ${depth?.toFixed(1)} km</div>
            ${f.properties?.url ? `<a href="${utils.escapeHtml(f.properties.url)}" target="_blank" class="link text-xs" style="margin-top:4px; display:inline-block">USGS details →</a>` : ''}
          </div>
        `;
      }).join('');
    },

    async refreshTsunami() {
      const el = utils.id('tsunamiAlerts');
      if (!el) return;
      el.innerHTML = '<div class="skeleton"></div>'.repeat(3);
      try {
        const q = await api.earthquakes.summary('day');
        const tsunamis = (q?.features || []).filter((f) => f.properties?.tsunami);
        if (!tsunamis.length) {
          el.innerHTML = '<div class="empty-state"><div class="icon-host">' + icons.makeIcon('success', 32) + '</div>No tsunami warnings today</div>';
          return;
        }
        el.innerHTML = tsunamis.map((f) => {
          const mag = f.properties?.mag || 0;
          const place = f.properties?.place || 'Unknown';
          return `
            <div class="card" style="margin-bottom:8px; border-left:3px solid #ff5e7a">
              <div style="font-weight:600">${icons.makeIcon('wave', 14)} M${mag.toFixed(1)} — ${utils.escapeHtml(place)}</div>
              <div class="text-xs text-dim" style="margin-top:4px">${utils.fmt.relative(f.properties?.time)}</div>
            </div>
          `;
        }).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Tsunami feed unavailable</div>';
      }
    },

    async refreshSpace() {
      const el = utils.id('spaceAlerts');
      if (!el) return;
      el.innerHTML = '<div class="skeleton"></div>'.repeat(3);
      try {
        const d = await api.space.spaceWeather();
        if (!Array.isArray(d) || !d.length) {
          el.innerHTML = '<div class="empty-state"><div class="icon-host">' + icons.makeIcon('success', 32) + '</div>No active space weather alerts</div>';
          return;
        }
        el.innerHTML = d.slice(0, 6).map((a) => `
          <div class="card" style="margin-bottom:8px; border-left:3px solid ${a.product_id?.includes('WARNING') ? '#ff5e7a' : '#ffcf5e'}">
            <div class="text-sm" style="font-weight:600">${utils.escapeHtml(a.summary || a.headline || 'Alert')}</div>
            <div class="text-xs text-dim" style="margin-top:4px">${utils.escapeHtml(a.issue_datetime || '')}</div>
          </div>
        `).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Space weather unavailable</div>';
      }
    },

    renderNotifs() {
      const el = utils.id('appNotifs');
      if (!el) return;
      const notifs = store.notifications;
      if (!notifs.length) {
        el.innerHTML = '<div class="empty-state"><div class="icon-host">' + icons.makeIcon('bell', 32) + '</div>No notifications yet</div>';
        return;
      }
      el.innerHTML = notifs.slice(0, 15).map((n) => `
        <div class="card" style="margin-bottom:6px; padding:10px; border-left:3px solid ${n.type === 'error' ? '#ff5e7a' : n.type === 'success' ? '#3ee68a' : n.type === 'warn' ? '#ffcf5e' : '#5ec3ff'}">
          <div style="font-weight:600; font-size:13px">${utils.escapeHtml(n.title)}</div>
          ${n.message ? `<div class="text-xs text-dim" style="margin-top:2px">${utils.escapeHtml(n.message)}</div>` : ''}
          <div class="text-xs text-dim" style="margin-top:4px">${utils.fmt.relative(n.ts)}</div>
        </div>
      `).join('');
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.alerts = view;
})(window);
