/* TERRA PULSE — Forex view (with live heatmap + bar graph) */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const POPULAR = ['USD', 'EUR', 'GBP', 'JPY', 'CNY', 'INR', 'AUD', 'CAD', 'CHF', 'BRL', 'ZAR', 'KRW', 'SGD', 'HKD', 'MXN', 'RUB', 'TRY', 'AED', 'NZD', 'SEK', 'NOK', 'PLN', 'THB', 'IDR', 'MYR', 'PHP', 'CZK', 'HUF', 'ILS', 'CLP'];

  const view = {
    id: 'forex',
    initialized: false,
    timer: null,
    tickerTimer: null,
    base: 'USD',
    target: 'EUR',
    history: {}, // currency → last rate (for live change)

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 30_000);
      // Animate heatmap bars (visual jitter to show "live")
      this.tickerTimer = setInterval(() => this.animateBars(), 1500);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      if (this.tickerTimer) clearInterval(this.tickerTimer);
      this.timer = null;
      this.tickerTimer = null;
    },

    render() {
      const root = utils.id('view-forex');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Foreign Exchange</h1>
            <p class="view-sub">Live currency rates, animated heatmap, and historical trends.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>open.er-api · Frankfurter</span>
            <span class="chip" id="fxUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('activity', 18)} Live Forex Ticker</h2></div>
          <div class="ticker-wrap">
            <div class="ticker" id="fxTicker"></div>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('exchange', 18)} Currency Converter</h2></div>
          <div class="flex gap-12" style="flex-wrap:wrap; align-items:end">
            <div class="field" style="margin:0; flex:1; min-width:120px">
              <label>Amount</label>
              <input type="number" id="fxAmount" class="input" value="1" min="0" />
            </div>
            <div class="field" style="margin:0; flex:1; min-width:120px">
              <label>From</label>
              <select id="fxBase" class="select">${POPULAR.map((c) => `<option value="${c}">${c}</option>`).join('')}</select>
            </div>
            <button class="btn btn-ghost" id="fxSwap" title="Swap">${icons.makeIcon('exchange', 18)}</button>
            <div class="field" style="margin:0; flex:1; min-width:120px">
              <label>To</label>
              <select id="fxTarget" class="select">${POPULAR.map((c) => `<option value="${c}" ${c === 'EUR' ? 'selected' : ''}>${c}</option>`).join('')}</select>
            </div>
            <div class="field" style="margin:0; flex:1; min-width:160px">
              <label>Result</label>
              <div id="fxResult" class="input" style="font-weight:600">—</div>
            </div>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('grid', 18)} Live Heatmap (vs ${this.base})</h2><span class="chip" id="fxHeatCount">— pairs</span></div>
            <div id="fxHeatmap" class="heatmap-grid"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('chartBar', 18)} Live Bar Graph</h2></div>
            <div id="fxBarGraph" class="heatmap-bar"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('chart', 18)} 30-Day Trend (<span id="fxPairLabel">USD/EUR</span>)</h2></div>
            <div id="fxChart"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('list', 18)} All Rates (Base: <span id="fxBaseLabel">USD</span>)</h2></div>
            <div id="fxRates" class="table-wrap"></div>
          </div>
        </div>
      `;

      utils.id('fxBase').value = this.base;
      utils.id('fxTarget').value = this.target;
      ['fxAmount', 'fxBase', 'fxTarget'].forEach((id) => {
        utils.id(id).addEventListener('input', () => this.updateConverter());
        utils.id(id).addEventListener('change', () => this.updateConverter());
      });
      utils.id('fxSwap').addEventListener('click', () => {
        const b = utils.id('fxBase').value;
        utils.id('fxBase').value = utils.id('fxTarget').value;
        utils.id('fxTarget').value = b;
        this.updateConverter();
      });
    },

    async refresh() {
      try {
        const data = await api.forex.latest(this.base);
        this.rates = data?.rates || {};
        utils.id('fxBaseLabel').textContent = this.base;
        utils.id('fxUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());

        // Compute change vs previous snapshot
        const changes = {};
        for (const cur of Object.keys(this.rates)) {
          const prev = this.history[cur];
          if (prev != null) {
            changes[cur] = ((this.rates[cur] - prev) / prev) * 100;
          }
          this.history[cur] = this.rates[cur];
        }
        this.changes = changes;

        this.renderHeatmap();
        this.renderBarGraph();
        this.renderTicker();
        this.renderRatesTable();
        this.updateConverter();
        await this.refreshChart();
      } catch {
        const el = utils.id('fxRates');
        if (el) el.innerHTML = '<div class="text-dim">Forex data unavailable</div>';
      }
    },

    renderHeatmap() {
      const el = utils.id('fxHeatmap');
      if (!el || !this.rates) return;
      const pairs = POPULAR.filter((c) => this.rates[c] && c !== this.base);
      utils.id('fxHeatCount').textContent = pairs.length + ' pairs';
      el.innerHTML = pairs.map((cur) => {
        const rate = this.rates[cur];
        const chg = this.changes[cur] || 0;
        const color = utils.color.heatColor(chg);
        const opacity = Math.max(0.4, utils.color.heatOpacity(chg));
        return `
          <div class="heatmap-cell" style="background:${color}; opacity:${opacity}" data-cur="${cur}">
            <div class="hm-symbol">${this.base}/${cur}</div>
            <div class="hm-price">${rate.toFixed(rate < 10 ? 4 : 2)}</div>
            <div class="hm-change">${chg ? utils.fmt.percent(chg) : '—'}</div>
          </div>
        `;
      }).join('');
    },

    renderBarGraph() {
      const el = utils.id('fxBarGraph');
      if (!el || !this.rates) return;
      const pairs = POPULAR.filter((c) => this.rates[c] && c !== this.base).slice(0, 15);
      // Normalize rates to log scale (since JPY ~150, EUR ~0.9)
      const logRates = pairs.map((c) => ({ cur: c, rate: this.rates[c], logRate: Math.log(this.rates[c]) }));
      const maxLog = Math.max(...logRates.map((p) => Math.abs(p.logRate)));
      el.innerHTML = logRates.map((p) => {
        const chg = this.changes[p.cur] || 0;
        const widthPct = (Math.abs(p.logRate) / maxLog) * 100;
        const isUp = chg >= 0;
        return `
          <div class="heatbar-row">
            <div class="heatbar-name">${this.base}/${p.cur}</div>
            <div class="heatbar-track">
              <div class="heatbar-fill ${isUp ? 'up' : 'down'}" style="width:${widthPct}%; transition:width 800ms var(--ease)"></div>
            </div>
            <div class="heatbar-value">${p.rate.toFixed(p.rate < 10 ? 4 : 2)}</div>
            <div class="heatbar-change ${utils.color.changeColor(chg)}">${chg ? utils.fmt.percent(chg) : '—'}</div>
          </div>
        `;
      }).join('');
    },

    renderTicker() {
      const el = utils.id('fxTicker');
      if (!el || !this.rates) return;
      const items = POPULAR.filter((c) => this.rates[c] && c !== this.base).slice(0, 15).map((cur) => {
        const rate = this.rates[cur];
        const chg = this.changes[cur] || 0;
        return `<span class="ticker-item">
          <span class="t-sym">${this.base}/${cur}</span>
          <span class="t-price">${rate.toFixed(rate < 10 ? 4 : 2)}</span>
          <span class="t-chg ${utils.color.changeColor(chg)}">${chg ? utils.fmt.percent(chg) : '—'}</span>
        </span>`;
      }).join('');
      el.innerHTML = items + items;
    },

    renderRatesTable() {
      const el = utils.id('fxRates');
      if (!el || !this.rates) return;
      const sorted = Object.entries(this.rates).filter(([c]) => POPULAR.includes(c)).sort((a, b) => a[0].localeCompare(b[0]));
      el.innerHTML = `
        <table class="data">
          <thead><tr><th>Currency</th><th>Rate</th><th>Inverse</th><th>Change</th></tr></thead>
          <tbody>
            ${sorted.map(([cur, rate]) => {
              const chg = this.changes[cur] || 0;
              return `<tr>
                <td><strong>${cur}</strong></td>
                <td class="num">${rate.toFixed(rate < 10 ? 4 : 2)}</td>
                <td class="num">${(1 / rate).toFixed(4)}</td>
                <td class="num ${utils.color.changeColor(chg)}">${chg ? utils.fmt.percent(chg) : '—'}</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      `;
    },

    // Visual animation: subtle width variation to show "live" movement
    animateBars() {
      const bars = utils.qsa('#fxBarGraph .heatbar-fill');
      bars.forEach((bar) => {
        const cur = bar.parentElement.parentElement.querySelector('.heatbar-name')?.textContent?.split('/')[1];
        if (!cur || !this.rates[cur]) return;
        const logR = Math.log(this.rates[cur]);
        // Tiny simulated fluctuation
        const fluct = (Math.random() - 0.5) * 0.02;
        const newLog = logR + fluct;
        const maxLog = Math.max(...Object.values(this.rates).filter((r) => r > 0).map((r) => Math.abs(Math.log(r))));
        const widthPct = (Math.abs(newLog) / maxLog) * 100;
        bar.style.width = widthPct + '%';
      });
    },

    async refreshChart() {
      const chartEl = utils.id('fxChart');
      if (!chartEl) return;
      const base = utils.id('fxBase').value;
      const target = utils.id('fxTarget').value;
      utils.id('fxPairLabel').textContent = base + '/' + target;
      try {
        const data = await api.forex.timeseries(base, target, 30);
        if (!data?.rates) {
          chartEl.innerHTML = '<div class="text-dim text-sm">Historical data unavailable</div>';
          return;
        }
        const entries = Object.entries(data.rates).sort((a, b) => a[0].localeCompare(b[0]));
        const values = entries.map(([d, r]) => r[target]);
        const dates = entries.map(([d]) => d);
        const W = 600, H = 200, pad = 30;
        const max = Math.max(...values);
        const min = Math.min(...values);
        const range = max - min || 1;
        const stepX = (W - pad * 2) / (values.length - 1);
        const points = values.map((v, i) => {
          const x = pad + i * stepX;
          const y = H - pad - ((v - min) / range) * (H - pad * 2);
          return `${x},${y}`;
        }).join(' ');

        chartEl.innerHTML = `
          <svg viewBox="0 0 ${W} ${H}" style="width:100%; height:auto">
            <defs>
              <linearGradient id="fxGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#5ee7ff" stop-opacity="0.3"/>
                <stop offset="100%" stop-color="#5ee7ff" stop-opacity="0"/>
              </linearGradient>
            </defs>
            <polyline points="${pad},${H-pad} ${points} ${W-pad},${H-pad}" fill="url(#fxGrad)"/>
            <polyline points="${points}" fill="none" stroke="#5ee7ff" stroke-width="2"/>
            ${[0, 0.25, 0.5, 0.75, 1].map((p) => {
              const y = pad + p * (H - pad * 2);
              const v = max - p * range;
              return `<line x1="${pad}" y1="${y}" x2="${W-pad}" y2="${y}" stroke="rgba(120,180,255,.1)" stroke-width="0.5"/>
                      <text x="${pad-4}" y="${y+3}" font-size="9" fill="#aeb8d8" text-anchor="end">${v.toFixed(4)}</text>`;
            }).join('')}
            <text x="${pad}" y="${H-8}" font-size="9" fill="#aeb8d8">${dates[0]}</text>
            <text x="${W-pad}" y="${H-8}" font-size="9" fill="#aeb8d8" text-anchor="end">${dates[dates.length-1]}</text>
          </svg>
          <div class="flex gap-12 mt-12 text-xs text-dim">
            <span>30-day low: <strong style="color:#ff5e7a">${min.toFixed(4)}</strong></span>
            <span>30-day high: <strong style="color:#3ee68a">${max.toFixed(4)}</strong></span>
            <span>Change: <strong style="color:${values[values.length-1] >= values[0] ? '#3ee68a' : '#ff5e7a'}">${((values[values.length-1] - values[0]) / values[0] * 100).toFixed(2)}%</strong></span>
          </div>
        `;
      } catch {
        chartEl.innerHTML = '<div class="text-dim">Chart unavailable</div>';
      }
    },

    updateConverter() {
      const amt = parseFloat(utils.id('fxAmount').value) || 0;
      const base = utils.id('fxBase').value;
      const target = utils.id('fxTarget').value;
      const result = utils.id('fxResult');
      if (base === target) {
        result.textContent = amt.toFixed(2) + ' ' + target;
        return;
      }
      if (!this.rates || !this.rates[target]) {
        result.textContent = '—';
        return;
      }
      const val = amt * this.rates[target];
      result.textContent = val.toFixed(val < 1 ? 4 : 2) + ' ' + target;
      this.refreshChart();
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.forex = view;
})(window);
