/* TERRA PULSE — Trends view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'trends',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 10 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-trends');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Trends</h1>
            <p class="view-sub">What the world is searching, watching, and talking about right now.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Live</span>
            <span class="chip" id="trendsUpdated">—</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('search', 18)} Daily Search Trends</h2></div>
            <div id="trendsDaily"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('trending', 18)} Top Reddit Posts</h2></div>
            <div id="trendsReddit"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('news', 18)} Hacker News Top</h2></div>
            <div id="trendsHN"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('video', 18)} YouTube Trending</h2></div>
            <div id="trendsYT"></div>
          </div>
        </div>
      `;
    },

    async refresh() {
      await Promise.allSettled([
        this.refreshDaily(),
        this.refreshReddit(),
        this.refreshHN(),
        this.refreshYT()
      ]);
      const el = utils.id('trendsUpdated');
      if (el) el.textContent = 'Updated ' + utils.fmt.time(new Date());
    },

    async refreshDaily() {
      const el = utils.id('trendsDaily');
      if (!el) return;
      el.innerHTML = '<div class="skeleton"></div>'.repeat(5);
      try {
        const d = await api.news.rss('https://trends.google.com/trending/rss');
        if (!d?.items?.length) {
          el.innerHTML = '<div class="text-dim text-sm">No trending searches</div>';
          return;
        }
        el.innerHTML = d.items.slice(0, 15).map((it, i) => `
          <div class="flex gap-12 center" style="padding:8px 0; border-bottom:1px solid var(--glass-border-2)">
            <span style="font-weight:700; color:#ffcf5e; min-width:24px">#${i+1}</span>
            <div style="flex:1">
              <a href="${utils.escapeHtml(it.link)}" target="_blank" rel="noopener">${utils.escapeHtml(it.title)}</a>
              ${it.description ? `<div class="text-xs text-dim">${utils.escapeHtml(utils.truncate(it.description, 100))}</div>` : ''}
            </div>
            ${it.pubDate ? `<span class="text-xs text-dim">${utils.fmt.relative(it.pubDate)}</span>` : ''}
          </div>
        `).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Google Trends unavailable</div>';
      }
    },

    async refreshReddit() {
      const el = utils.id('trendsReddit');
      if (!el) return;
      el.innerHTML = '<div class="skeleton"></div>'.repeat(5);
      try {
        const d = await api.news.rss('https://www.reddit.com/r/all/top/.rss?limit=10&t=day');
        if (!d?.items?.length) {
          el.innerHTML = '<div class="text-dim text-sm">Reddit unavailable</div>';
          return;
        }
        el.innerHTML = d.items.slice(0, 10).map((it) => `
          <div style="padding:8px 0; border-bottom:1px solid var(--glass-border-2)">
            <a href="${utils.escapeHtml(it.link)}" target="_blank" rel="noopener" class="text-sm">${utils.escapeHtml(utils.truncate(it.title, 80))}</a>
            <div class="text-xs text-dim">${utils.fmt.relative(it.pubDate)}</div>
          </div>
        `).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Reddit unavailable</div>';
      }
    },

    async refreshHN() {
      const el = utils.id('trendsHN');
      if (!el) return;
      el.innerHTML = '<div class="skeleton"></div>'.repeat(5);
      try {
        const d = await api.news.hackernews('', 'front_page');
        const hits = d?.hits || [];
        if (!hits.length) {
          el.innerHTML = '<div class="text-dim text-sm">Hacker News unavailable</div>';
          return;
        }
        el.innerHTML = hits.slice(0, 15).map((h, i) => `
          <div class="flex gap-12 center" style="padding:8px 0; border-bottom:1px solid var(--glass-border-2)">
            <span style="font-weight:700; color:#ffcf5e; min-width:24px">${i+1}.</span>
            <div style="flex:1; min-width:0">
              <a href="${utils.escapeHtml(h.url || h.story_url || '#')}" target="_blank" rel="noopener" class="text-sm">${utils.escapeHtml(h.title || h.story_title)}</a>
              <div class="text-xs text-dim">${h.points} points · ${h.num_comments} comments · by ${utils.escapeHtml(h.author)}</div>
            </div>
          </div>
        `).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">HN unavailable</div>';
      }
    },

    async refreshYT() {
      const el = utils.id('trendsYT');
      if (!el) return;
      el.innerHTML = '<div class="skeleton"></div>'.repeat(5);
      try {
        const d = await api.news.rss('https://www.youtube.com/feeds/videos.xml?channel_id=UCFbMj5xrRrQqXWz9C-Rqmbw');
        if (!d?.items?.length) {
          el.innerHTML = '<div class="text-dim text-sm">YouTube feed unavailable</div>';
          return;
        }
        el.innerHTML = d.items.slice(0, 10).map((it) => `
          <div style="padding:8px 0; border-bottom:1px solid var(--glass-border-2)">
            <a href="${utils.escapeHtml(it.link)}" target="_blank" rel="noopener" class="text-sm">${utils.escapeHtml(utils.truncate(it.title, 70))}</a>
            <div class="text-xs text-dim">${utils.fmt.relative(it.pubDate)}</div>
          </div>
        `).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">YouTube unavailable</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.trends = view;
})(window);
