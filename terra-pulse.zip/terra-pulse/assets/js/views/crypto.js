/* TERRA PULSE — Crypto view (with live ticker + heatmap) */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'crypto',
    initialized: false,
    timer: null,
    tickerTimer: null,
    page: 1,
    cached: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 60_000);
      // Live ticker every 10s (just re-renders prices)
      this.tickerTimer = setInterval(() => this.refreshTicker(), 10_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      if (this.tickerTimer) clearInterval(this.tickerTimer);
      this.timer = null;
      this.tickerTimer = null;
    },

    render() {
      const root = utils.id('view-crypto');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Crypto Markets</h1>
            <p class="view-sub">Live prices, market caps, and 7-day trends for top cryptocurrencies.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>CoinGecko</span>
            <span class="chip" id="cryptoUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('activity', 18)} Live Price Ticker</h2></div>
          <div class="ticker-wrap">
            <div class="ticker" id="cryptoTicker"></div>
          </div>
        </div>

        <div class="kpi-grid" id="cryptoKpis"></div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('chartBar', 18)} Global Market Stats</h2></div>
          <div id="cryptoGlobal" class="card-grid"></div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('flame2', 18)} Trending</h2></div>
          <div id="cryptoTrending" class="card-grid"></div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('grid', 18)} Live Heatmap (24h change)</h2></div>
          <div id="cryptoHeatmap" class="heatmap-grid"></div>
        </div>

        <div class="tile">
          <div class="tile-head">
            <h2>${icons.makeIcon('chart', 18)} Top 50 by Market Cap</h2>
            <div class="flex gap-8">
              <button class="btn btn-ghost" id="cryptoPrev">${icons.makeIcon('chevronLeft', 16)} Prev</button>
              <span class="chip" id="cryptoPage">Page 1</span>
              <button class="btn btn-ghost" id="cryptoNext">Next ${icons.makeIcon('chevronRight', 16)}</button>
            </div>
          </div>
          <div id="cryptoTable" class="table-wrap"></div>
        </div>
      `;

      utils.id('cryptoPrev').addEventListener('click', () => { if (this.page > 1) { this.page--; this.refresh(); } });
      utils.id('cryptoNext').addEventListener('click', () => { if (this.page < 10) { this.page++; this.refresh(); } });
    },

    async refresh() {
      try {
        const [globalRes, trendingRes, marketsRes] = await Promise.allSettled([
          api.crypto.global(),
          api.crypto.trending(),
          api.crypto.markets(50, this.page)
        ]);

        const global = globalRes.status === 'fulfilled' ? globalRes.value : null;
        const trending = trendingRes.status === 'fulfilled' ? trendingRes.value : null;
        const markets = marketsRes.status === 'fulfilled' ? marketsRes.value : null;
        this.cached = { global, trending, markets };

        if (global) {
          const d = global.data;
          utils.id('cryptoKpis').innerHTML = `
            <div class="kpi kpi-3">
              <div class="kpi-label">Total Market Cap</div>
              <div class="kpi-value">$${utils.fmt.compact(d.total_market_cap.usd)}</div>
              <div class="kpi-meta ${utils.color.changeColor(d.market_cap_change_percentage_24h_usd)}">${utils.fmt.percent(d.market_cap_change_percentage_24h_usd)} (24h)</div>
            </div>
            <div class="kpi kpi-2">
              <div class="kpi-label">24h Volume</div>
              <div class="kpi-value">$${utils.fmt.compact(d.total_volume.usd)}</div>
              <div class="kpi-meta">Total traded</div>
            </div>
            <div class="kpi kpi-4">
              <div class="kpi-label">BTC Dominance</div>
              <div class="kpi-value">${d.market_cap_percentage.btc.toFixed(1)}%</div>
              <div class="kpi-meta">ETH: ${d.market_cap_percentage.eth.toFixed(1)}%</div>
            </div>
            <div class="kpi kpi-1">
              <div class="kpi-label">Active Cryptos</div>
              <div class="kpi-value">${utils.fmt.int(d.active_cryptocurrencies)}</div>
              <div class="kpi-meta">${utils.fmt.int(d.markets)} markets</div>
            </div>
          `;

          utils.id('cryptoGlobal').innerHTML = `
            <div class="card-row"><span class="label">Total Market Cap (USD)</span><span class="value">$${utils.fmt.int(d.total_market_cap.usd)}</span></div>
            <div class="card-row"><span class="label">Total Volume (USD)</span><span class="value">$${utils.fmt.int(d.total_volume.usd)}</span></div>
            <div class="card-row"><span class="label">BTC Dominance</span><span class="value">${d.market_cap_percentage.btc.toFixed(2)}%</span></div>
            <div class="card-row"><span class="label">ETH Dominance</span><span class="value">${d.market_cap_percentage.eth.toFixed(2)}%</span></div>
            <div class="card-row"><span class="label">Active Cryptocurrencies</span><span class="value">${utils.fmt.int(d.active_cryptocurrencies)}</span></div>
            <div class="card-row"><span class="label">Markets</span><span class="value">${utils.fmt.int(d.markets)}</span></div>
            <div class="card-row"><span class="label">24h Change</span><span class="value ${utils.color.changeColor(d.market_cap_change_percentage_24h_usd)}">${utils.fmt.percent(d.market_cap_change_percentage_24h_usd)}</span></div>
          `;
        }

        if (trending?.coins?.length) {
          utils.id('cryptoTrending').innerHTML = trending.coins.slice(0, 8).map((c, i) => {
            const item = c.item;
            return `
              <div class="card" style="cursor:pointer" data-id="${item.id}">
                <div class="flex gap-8 center">
                  <span class="text-2xl" style="color:#ffcf5e; font-weight:700">#${i + 1}</span>
                  <div style="flex:1">
                    <div class="card-title">${utils.escapeHtml(item.name)}</div>
                    <div class="text-xs text-dim">${utils.escapeHtml(item.symbol)}</div>
                  </div>
                </div>
                <div class="card-row"><span class="label">Rank</span><span class="value">#${item.market_cap_rank || '—'}</span></div>
                ${item.price_btc ? `<div class="card-row"><span class="label">Price (BTC)</span><span class="value">${parseFloat(item.price_btc).toFixed(8)}</span></div>` : ''}
              </div>
            `;
          }).join('');
        }

        // Live heatmap (top 30 coins by 24h change)
        if (markets?.length) {
          utils.id('cryptoHeatmap').innerHTML = markets.slice(0, 30).map((c) => {
            const chg = c.price_change_percentage_24h || 0;
            const color = utils.color.heatColor(chg);
            const opacity = utils.color.heatOpacity(chg);
            const sparkPts = c.sparkline_in_7d?.price ? utils.sparkline(c.sparkline_in_7d.price.slice(-24), 80, 20) : '';
            return `
              <div class="heatmap-cell" style="background:${color}; opacity:${opacity}" title="${utils.escapeHtml(c.name)} · ${utils.fmt.percent(chg)}">
                <div class="hm-symbol">${icons.coinIcon(c.symbol)} ${utils.escapeHtml((c.symbol || '').toUpperCase())}</div>
                <div class="hm-price">$${utils.fmt.decimals(c.current_price, c.current_price < 1 ? 6 : 2)}</div>
                <div class="hm-change">${utils.fmt.percent(chg)}</div>
                ${sparkPts ? `<svg class="hm-spark" viewBox="0 0 80 20" preserveAspectRatio="none"><polyline points="${sparkPts}" fill="none" stroke="${chg >= 0 ? '#3ee68a' : '#ff5e7a'}" stroke-width="1"/></svg>` : ''}
              </div>
            `;
          }).join('');

          utils.id('cryptoTable').innerHTML = `
            <table class="data">
              <thead><tr><th>#</th><th>Coin</th><th>Price</th><th>1h</th><th>24h</th><th>7d</th><th>Market Cap</th><th>Volume 24h</th><th>7d Trend</th></tr></thead>
              <tbody>
                ${markets.map((c) => {
                  const chg1h = c.price_change_percentage_1h_in_currency || 0;
                  const chg24h = c.price_change_percentage_24h_in_currency || 0;
                  const chg7d = c.price_change_percentage_7d_in_currency || 0;
                  const sparkPts = c.sparkline_in_7d?.price ? utils.sparkline(c.sparkline_in_7d.price, 80, 20) : '';
                  return `<tr>
                    <td class="num">${c.market_cap_rank || '—'}</td>
                    <td><div class="flex gap-8 center">${icons.coinIcon(c.symbol)}<div><div style="font-weight:700">${utils.escapeHtml((c.symbol || '').toUpperCase())}</div><div class="text-dim text-xs">${utils.escapeHtml(c.name)}</div></div></div></td>
                    <td class="num">$${utils.fmt.decimals(c.current_price, c.current_price < 1 ? 6 : 2)}</td>
                    <td class="num ${utils.color.changeColor(chg1h)}">${utils.fmt.percent(chg1h)}</td>
                    <td class="num ${utils.color.changeColor(chg24h)}">${utils.fmt.percent(chg24h)}</td>
                    <td class="num ${utils.color.changeColor(chg7d)}">${utils.fmt.percent(chg7d)}</td>
                    <td class="num">$${utils.fmt.compact(c.market_cap)}</td>
                    <td class="num">$${utils.fmt.compact(c.total_volume)}</td>
                    <td><svg viewBox="0 0 80 20" style="width:80px; height:20px"><polyline points="${sparkPts}" fill="none" stroke="${chg7d >= 0 ? '#3ee68a' : '#ff5e7a'}" stroke-width="1"/></svg></td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>
          `;
        }

        this.renderTicker(markets);
        utils.id('cryptoPage').textContent = 'Page ' + this.page;
        utils.id('cryptoUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch (e) {
        utils.id('cryptoTable').innerHTML = '<div class="text-dim">Failed to load crypto data</div>';
      }
    },

    renderTicker(markets) {
      const el = utils.id('cryptoTicker');
      if (!el || !markets?.length) return;
      const items = markets.slice(0, 20).map((c) => {
        const chg = c.price_change_percentage_24h || 0;
        return `<span class="ticker-item">
          <span class="t-sym">${icons.coinIcon(c.symbol)} ${utils.escapeHtml((c.symbol || '').toUpperCase())}</span>
          <span class="t-price">$${utils.fmt.decimals(c.current_price, c.current_price < 1 ? 6 : 2)}</span>
          <span class="t-chg ${utils.color.changeColor(chg)}">${utils.fmt.percent(chg)}</span>
        </span>`;
      }).join('');
      // Duplicate for seamless scroll
      el.innerHTML = items + items;
    },

    async refreshTicker() {
      // Lightweight: just refresh prices from cached markets + simple price API
      if (!this.cached?.markets) return;
      try {
        const ids = this.cached.markets.slice(0, 10).map((c) => c.id);
        const prices = await api.crypto.priceSimple(ids);
        if (!prices) return;
        // Update ticker with fresh prices
        const updated = this.cached.markets.slice(0, 20).map((c) => {
          const fresh = prices[c.id];
          return {
            ...c,
            current_price: fresh?.usd ?? c.current_price,
            price_change_percentage_24h: fresh?.usd_24h_change ?? c.price_change_percentage_24h
          };
        });
        this.renderTicker(updated);
      } catch {}
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.crypto = view;
})(window);
