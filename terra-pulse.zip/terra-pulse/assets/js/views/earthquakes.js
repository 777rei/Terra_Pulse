/* TERRA PULSE — Earthquakes view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'earthquakes',
    initialized: false,
    timer: null,
    timeframe: 'day',
    minMag: 0,
    map: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-earthquakes');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Earthquake Monitor</h1>
            <p class="view-sub">Live data from USGS Earthquake Hazards Program. Updated every minute.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>USGS Live</span>
            <span class="chip" id="eqCount">— events</span>
            <span class="chip" id="eqUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('filter', 18)} Filters</h2></div>
          <div class="flex gap-12" style="flex-wrap:wrap; align-items:center">
            <label class="text-sm">Timeframe:</label>
            <select id="eqTimeframe" class="select" style="width:auto">
              <option value="hour">Last hour</option>
              <option value="day" selected>Last 24h</option>
              <option value="week">Last 7 days</option>
              <option value="month">Last 30 days</option>
            </select>
            <label class="text-sm">Min magnitude:</label>
            <select id="eqMinMag" class="select" style="width:auto">
              <option value="0" selected>All</option>
              <option value="2.5">2.5+</option>
              <option value="4.5">4.5+</option>
              <option value="6">6+ (significant)</option>
            </select>
            <button class="btn btn-primary" id="eqRefresh">${icons.makeIcon('refresh', 16)} Refresh</button>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('map', 18)} Quake Map</h2></div>
            <div id="eqMap" style="min-height:380px"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('chartBar', 18)} Magnitude Distribution</h2></div>
            <div id="eqChart"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('gauge', 18)} Stats</h2></div>
            <div id="eqStats"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Recent Earthquakes</h2></div>
            <div id="eqTable" class="table-wrap"></div>
          </div>
        </div>
      `;

      this.map = new global.TP.WorldMap(utils.id('eqMap'), { showCityLabels: false });

      utils.id('eqTimeframe').addEventListener('change', (e) => { this.timeframe = e.target.value; this.refresh(); });
      utils.id('eqMinMag').addEventListener('change', (e) => { this.minMag = parseFloat(e.target.value); this.refresh(); });
      utils.id('eqRefresh').addEventListener('click', () => this.refresh());
    },

    async refresh() {
      try {
        const data = await api.earthquakes.summary(this.timeframe);
        const allFeatures = data?.features || [];
        const features = allFeatures.filter((f) => (f.properties?.mag || 0) >= this.minMag);

        const events = features.slice(0, 100).map((f) => {
          const mag = f.properties?.mag || 0;
          const [lng, lat] = f.geometry?.coordinates || [];
          let color = '#5ec3ff';
          if (mag >= 6) color = '#ff5e7a';
          else if (mag >= 4.5) color = '#ffcf5e';
          else if (mag >= 2.5) color = '#3ee68a';
          return {
            lat, lng,
            color, size: Math.max(2, mag * 0.8),
            magnitude: mag.toFixed(1),
            title: f.properties?.place || 'Earthquake',
            text: 'Magnitude ' + mag.toFixed(1) + (f.properties?.tsunami ? ' · TSUNAMI WARNING' : ''),
            time: f.properties?.time ? new Date(f.properties.time) : null
          };
        });
        this.map.setEvents(events);

        const stats = this.computeStats(features);
        utils.id('eqCount').textContent = features.length + ' events';
        utils.id('eqUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
        utils.id('eqStats').innerHTML = `
          <div class="card-row"><span class="label">Total events</span><span class="value">${stats.count}</span></div>
          <div class="card-row"><span class="label">Max magnitude</span><span class="value" style="color:${stats.maxMag >= 5 ? '#ff5e7a' : '#ffcf5e'}">M${stats.maxMag.toFixed(1)}</span></div>
          <div class="card-row"><span class="label">Avg magnitude</span><span class="value">M${stats.avgMag.toFixed(2)}</span></div>
          <div class="card-row"><span class="label">Significant (M4.5+)</span><span class="value">${stats.significant}</span></div>
          <div class="card-row"><span class="label">Tsunami warnings</span><span class="value">${stats.tsunamis}</span></div>
          <div class="card-row"><span class="label">Deepest</span><span class="value">${stats.deepest} km</span></div>
          <div class="card-row"><span class="label">Shallowest</span><span class="value">${stats.shallowest} km</span></div>
        `;

        const buckets = [0, 1, 2, 2.5, 3, 4, 4.5, 5, 6, 7];
        const counts = buckets.map((b) => features.filter((f) => {
          const m = f.properties?.mag || 0;
          return m >= b && m < (b === 7 ? 11 : buckets[buckets.indexOf(b) + 1]);
        }).length);
        const max = Math.max(...counts, 1);
        utils.id('eqChart').innerHTML = `
          <svg viewBox="0 0 280 140" style="width:100%; height:auto">
            ${buckets.map((b, i) => {
              const h = (counts[i] / max) * 100;
              const x = 30 + i * 28;
              const y = 120 - h;
              return `<rect x="${x}" y="${y}" width="20" height="${h}" fill="#5ee7ff" rx="2"/>
                      <text x="${x + 10}" y="135" font-size="9" fill="#aeb8d8" text-anchor="middle">${b}+</text>
                      <text x="${x + 10}" y="${y - 4}" font-size="10" fill="#e9eefc" text-anchor="middle" font-weight="700">${counts[i]}</text>`;
            }).join('')}
            <text x="10" y="20" font-size="10" fill="#aeb8d8">Count</text>
          </svg>
          <div class="text-xs text-dim" style="margin-top:6px; text-align:center">Magnitude (M)</div>
        `;

        const sorted = [...features].sort((a, b) => (b.properties?.mag || 0) - (a.properties?.mag || 0));
        utils.id('eqTable').innerHTML = `
          <table class="data">
            <thead><tr><th>Mag</th><th>Place</th><th>Depth</th><th>Time</th><th>Coords</th><th>Tsunami</th></tr></thead>
            <tbody>
              ${sorted.slice(0, 25).map((f) => {
                const mag = f.properties?.mag || 0;
                const place = f.properties?.place || 'Unknown';
                const [lng, lat, depth] = f.geometry?.coordinates || [];
                const time = f.properties?.time ? new Date(f.properties.time) : null;
                return `<tr>
                  <td><span class="quake-mag ${utils.color.mag(mag)}">M${mag.toFixed(1)}</span></td>
                  <td>${utils.escapeHtml(place)}</td>
                  <td class="num">${depth?.toFixed(1) || '—'} km</td>
                  <td class="num">${time ? utils.fmt.relative(time) : '—'}</td>
                  <td class="num">${lat?.toFixed(2)}°, ${lng?.toFixed(2)}°</td>
                  <td>${f.properties?.tsunami ? 'Yes' : '—'}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        `;
      } catch (e) {
        utils.id('eqTable').innerHTML = '<div class="text-dim">Failed to load earthquakes</div>';
      }
    },

    computeStats(features) {
      let maxMag = 0, sumMag = 0, significant = 0, tsunamis = 0, deepest = 0, shallowest = 9999;
      for (const f of features) {
        const m = f.properties?.mag || 0;
        if (m > maxMag) maxMag = m;
        sumMag += m;
        if (m >= 4.5) significant++;
        if (f.properties?.tsunami) tsunamis++;
        const depth = f.geometry?.coordinates?.[2] || 0;
        if (depth > deepest) deepest = depth;
        if (depth > 0 && depth < shallowest) shallowest = depth;
      }
      return {
        count: features.length,
        maxMag,
        avgMag: features.length ? sumMag / features.length : 0,
        significant,
        tsunamis,
        deepest: deepest.toFixed(1),
        shallowest: shallowest === 9999 ? 0 : shallowest.toFixed(1)
      };
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.earthquakes = view;
})(window);
