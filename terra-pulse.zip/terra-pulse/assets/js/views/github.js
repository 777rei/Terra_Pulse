/* TERRA PULSE — GitHub Trending view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const LANGS = ['', 'javascript', 'typescript', 'python', 'rust', 'go', 'java', 'c++', 'c', 'c#', 'php', 'ruby', 'swift', 'kotlin'];

  const view = {
    id: 'github',
    initialized: false,
    timer: null,
    lang: '',
    since: 'daily',

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 30 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-github');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">GitHub Trending</h1>
            <p class="view-sub">Most-starred repositories created recently. Updated every 30 minutes.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>GitHub API</span>
            <span class="chip" id="ghUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="flex gap-12" style="flex-wrap:wrap; align-items:center">
            <label class="text-sm">Language:</label>
            <select id="ghLang" class="select" style="width:auto">
              ${LANGS.map((l) => `<option value="${l}">${l || 'All languages'}</option>`).join('')}
            </select>
            <label class="text-sm">Since:</label>
            <select id="ghSince" class="select" style="width:auto">
              <option value="daily">Today</option>
              <option value="weekly">This week</option>
              <option value="monthly">This month</option>
            </select>
            <button class="btn btn-primary" id="ghRefresh">${icons.makeIcon('refresh', 16)} Refresh</button>
          </div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('flame2', 18)} Trending Repositories</h2></div>
          <div id="ghList" class="card-grid"></div>
        </div>
      `;

      utils.id('ghLang').addEventListener('change', (e) => { this.lang = e.target.value; this.refresh(); });
      utils.id('ghSince').addEventListener('change', (e) => { this.since = e.target.value; this.refresh(); });
      utils.id('ghRefresh').addEventListener('click', () => this.refresh());
    },

    async refresh() {
      const el = utils.id('ghList');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(6);
      try {
        const d = await api.github.trendingSince(this.since, this.lang);
        const repos = d?.items || [];
        if (!repos.length) {
          el.innerHTML = '<div class="text-dim">No trending repos</div>';
          return;
        }
        el.innerHTML = repos.slice(0, 24).map((r) => `
          <div class="card" style="cursor:pointer" onclick="window.open('${utils.escapeHtml(r.html_url)}', '_blank')">
            <div class="flex between" style="gap:8px; align-items:flex-start">
              <div style="flex:1; min-width:0">
                <div style="font-weight:600; font-size:13px; margin-bottom:2px">${utils.escapeHtml(r.full_name)}</div>
                <div class="text-xs text-dim" style="line-height:1.5; max-height:60px; overflow:hidden">${utils.escapeHtml(r.description || 'No description')}</div>
              </div>
              <span style="color:#ffcf5e; font-size:18px">${icons.makeIcon('star', 18)}</span>
            </div>
            <div class="flex gap-8 mt-12" style="flex-wrap:wrap">
              ${r.language ? `<span class="chip text-xs">${icons.makeIcon('code', 12)} ${utils.escapeHtml(r.language)}</span>` : ''}
              <span class="chip text-xs">${icons.makeIcon('star', 12)} ${utils.fmt.compact(r.stargazers_count)}</span>
              <span class="chip text-xs">${icons.makeIcon('github', 12)} ${utils.fmt.compact(r.forks_count)}</span>
              <span class="chip text-xs">${icons.makeIcon('eye', 12)} ${utils.fmt.compact(r.watchers_count)}</span>
            </div>
          </div>
        `).join('');
        utils.id('ghUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        el.innerHTML = '<div class="text-dim">GitHub API rate-limited (60/hr without token)</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.github = view;
})(window);
