/* TERRA PULSE — Launches view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'launches',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 10 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-launches');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Space Launches</h1>
            <p class="view-sub">Upcoming orbital launch attempts worldwide. Data via The Space Devs.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Launch Library 2</span>
            <span class="chip" id="launchUpdated">—</span>
          </div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('rocket', 18)} Upcoming Launches</h2></div>
          <div id="launchList"></div>
        </div>
      `;
    },

    async refresh() {
      const el = utils.id('launchList');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(5);
      try {
        const d = await api.space.launches(20);
        const launches = d?.results || [];
        if (!launches.length) {
          el.innerHTML = '<div class="text-dim">No upcoming launches in feed</div>';
          return;
        }
        el.innerHTML = launches.map((l) => {
          const date = new Date(l.net);
          const isUpcoming = date > new Date();
          const countdown = this.countdown(date);
          return `
            <div class="card" style="margin-bottom:10px; padding:14px">
              <div class="flex between" style="gap:12px; align-items:flex-start">
                <div style="flex:1; min-width:0">
                  <div style="font-weight:600; font-size:14px; margin-bottom:4px">${utils.escapeHtml(l.mission?.name || l.name)}</div>
                  <div class="text-sm text-dim" style="line-height:1.5">
                    ${l.launch_service_provider?.name ? `<div>${icons.makeIcon('briefcase', 12)} ${utils.escapeHtml(l.launch_service_provider.name)}</div>` : ''}
                    ${l.rocket?.configuration?.full_name ? `<div>${icons.makeIcon('rocket', 12)} ${utils.escapeHtml(l.rocket.configuration.full_name)}</div>` : ''}
                    ${l.pad?.name ? `<div>${icons.makeIcon('location', 12)} ${utils.escapeHtml(l.pad.name)}, ${utils.escapeHtml(l.pad.location?.name || '')}</div>` : ''}
                    <div>${icons.makeIcon('clock', 12)} ${utils.fmt.datetime(date)}</div>
                    ${l.mission?.description ? `<div style="margin-top:6px">${utils.escapeHtml(utils.truncate(l.mission.description, 200))}</div>` : ''}
                  </div>
                </div>
                <div style="text-align:right">
                  <span class="pill ${isUpcoming ? 'pill-info' : 'pill-good'}">${isUpcoming ? 'T-' + countdown : 'Launched'}</span>
                  ${l.probability ? `<div class="text-xs text-dim" style="margin-top:4px">${l.probability}% go</div>` : ''}
                </div>
              </div>
            </div>
          `;
        }).join('');
        utils.id('launchUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        el.innerHTML = '<div class="text-dim">Launch data unavailable (rate-limited)</div>';
      }
    },

    countdown(date) {
      const diff = date - Date.now();
      if (diff < 0) return 'T+0';
      const days = Math.floor(diff / 86400000);
      const hours = Math.floor((diff % 86400000) / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      if (days > 0) return `${days}d ${hours}h`;
      if (hours > 0) return `${hours}h ${mins}m`;
      return `${mins}m`;
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.launches = view;
})(window);
