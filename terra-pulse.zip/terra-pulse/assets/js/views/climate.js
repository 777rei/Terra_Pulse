/* TERRA PULSE — Climate view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const STATIONS = [
    { name: 'London', lat: 51.5074, lng: -0.1278 },
    { name: 'New York', lat: 40.7128, lng: -74.0060 },
    { name: 'Tokyo', lat: 35.6762, lng: 139.6503 },
    { name: 'Sydney', lat: -33.8688, lng: 151.2093 },
    { name: 'Reykjavik', lat: 64.1466, lng: -21.9426 },
    { name: 'Singapore', lat: 1.3521, lng: 103.8198 }
  ];

  const view = {
    id: 'climate',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 30 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-climate');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Climate Monitor</h1>
            <p class="view-sub">30-day temperature history for major cities. Long-term trends and anomalies.</p>
          </div>
          <div class="view-meta">
            <span class="chip">Open-Meteo Archive</span>
            <span class="chip" id="climateUpdated">—</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('chart', 18)} 30-Day Temperature Trends</h2></div>
            <div id="climateChart"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('gauge', 18)} City Stats (30d)</h2></div>
            <div id="climateStats"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('rain', 18)} Precipitation (30d)</h2></div>
            <div id="climatePrecip"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('info', 18)} About the data</h2></div>
            <div class="card-row"><span class="label">Source</span><span class="value">Open-Meteo Archive</span></div>
            <div class="card-row"><span class="label">Refresh</span><span class="value">Every 6 hours</span></div>
            <div class="card-row"><span class="label">Window</span><span class="value">Last 30 days</span></div>
          </div>
        </div>
      `;
    },

    async refresh() {
      const chartEl = utils.id('climateChart');
      if (!chartEl) return;
      chartEl.innerHTML = '<span class="spinner"></span> Loading historical data…';

      try {
        const results = await Promise.allSettled(
          STATIONS.map((s) => api.weather.history(s.lat, s.lng, 30).then((d) => ({ ...s, data: d })))
        );
        const data = results.filter((r) => r.status === 'fulfilled' && r.value.data).map((r) => r.value);

        const W = 800, H = 280, pad = 30;
        const allTemps = data.flatMap((d) => d.data.daily.temperature_2m_max.concat(d.data.daily.temperature_2m_min));
        const maxT = Math.max(...allTemps);
        const minT = Math.min(...allTemps);
        const range = maxT - minT || 1;
        const days = data[0]?.data.daily.time.length || 30;
        const stepX = (W - pad * 2) / (days - 1);
        const colors = ['#5ee7ff', '#ffcf5e', '#3ee68a', '#ff5e7a', '#b07bff', '#5ec3ff'];

        const lines = data.map((d, idx) => {
          const color = colors[idx % colors.length];
          const points = d.data.daily.temperature_2m_max.map((t, i) => {
            const x = pad + i * stepX;
            const y = H - pad - ((t - minT) / range) * (H - pad * 2);
            return `${x},${y}`;
          }).join(' ');
          return `<polyline points="${points}" fill="none" stroke="${color}" stroke-width="2"/>
                  <polyline points="${d.data.daily.temperature_2m_min.map((t, i) => {
                    const x = pad + i * stepX;
                    const y = H - pad - ((t - minT) / range) * (H - pad * 2);
                    return `${x},${y}`;
                  }).join(' ')}" fill="none" stroke="${color}" stroke-width="1" stroke-opacity="0.5" stroke-dasharray="2 2"/>`;
        }).join('');

        const yLabels = [];
        for (let i = 0; i <= 4; i++) {
          const v = minT + (range / 4) * i;
          const y = H - pad - (i / 4) * (H - pad * 2);
          yLabels.push(`<text x="${pad - 4}" y="${y + 3}" font-size="9" fill="#aeb8d8" text-anchor="end">${v.toFixed(0)}°</text>
                       <line x1="${pad}" y1="${y}" x2="${W - pad}" y2="${y}" stroke="rgba(120,180,255,.08)" stroke-width="0.5"/>`);
        }

        chartEl.innerHTML = `
          <svg viewBox="0 0 ${W} ${H}" style="width:100%; height:auto">
            ${yLabels.join('')}
            ${lines}
            <line x1="${pad}" y1="${H-pad}" x2="${W-pad}" y2="${H-pad}" stroke="rgba(120,180,255,.3)" stroke-width="0.5"/>
            <line x1="${pad}" y1="${pad}" x2="${pad}" y2="${H-pad}" stroke="rgba(120,180,255,.3)" stroke-width="0.5"/>
            <text x="${pad + (W-pad*2)/2}" y="${H-6}" font-size="10" fill="#aeb8d8" text-anchor="middle">Days ago</text>
          </svg>
          <div class="flex gap-12" style="margin-top:8px; flex-wrap:wrap">
            ${data.map((d, idx) => `<span class="chip" style="border-color:${colors[idx % colors.length]}">${utils.escapeHtml(d.name)}</span>`).join('')}
          </div>
          <div class="text-xs text-dim" style="margin-top:6px">Solid line = daily high · Dashed line = daily low</div>
        `;

        utils.id('climateStats').innerHTML = data.map((d) => {
          const maxes = d.data.daily.temperature_2m_max;
          const mins = d.data.daily.temperature_2m_min;
          const avg = maxes.reduce((s, t) => s + t, 0) / maxes.length;
          return `
            <div class="card" style="margin-bottom:8px">
              <div class="card-title">${utils.escapeHtml(d.name)}</div>
              <div class="card-row"><span class="label">Avg max</span><span class="value">${avg.toFixed(1)}°C</span></div>
              <div class="card-row"><span class="label">Highest</span><span class="value">${Math.max(...maxes).toFixed(1)}°C</span></div>
              <div class="card-row"><span class="label">Lowest</span><span class="value">${Math.min(...mins).toFixed(1)}°C</span></div>
              <div class="card-row"><span class="label">Range</span><span class="value">${(Math.max(...maxes) - Math.min(...mins)).toFixed(1)}°C</span></div>
            </div>
          `;
        }).join('');

        const precipData = data.map((d) => ({
          name: d.name,
          total: d.data.daily.precipitation_sum.reduce((s, p) => s + (p || 0), 0),
          max: Math.max(...d.data.daily.precipitation_sum, 0)
        }));
        const maxPrecip = Math.max(...precipData.map((p) => p.total), 1);
        utils.id('climatePrecip').innerHTML = `
          <svg viewBox="0 0 400 200" style="width:100%; height:auto">
            ${precipData.map((p, i) => {
              const h = (p.total / maxPrecip) * 140;
              const x = 40 + i * 60;
              const y = 170 - h;
              return `<rect x="${x}" y="${y}" width="40" height="${h}" fill="#5ec3ff" rx="3"/>
                      <text x="${x + 20}" y="185" font-size="9" fill="#aeb8d8" text-anchor="middle">${utils.escapeHtml(p.name.slice(0, 8))}</text>
                      <text x="${x + 20}" y="${y - 4}" font-size="10" fill="#e9eefc" text-anchor="middle" font-weight="700">${p.total.toFixed(0)}mm</text>`;
            }).join('')}
          </svg>
        `;

        utils.id('climateUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        chartEl.innerHTML = '<div class="text-dim">Climate data unavailable</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.climate = view;
})(window);
