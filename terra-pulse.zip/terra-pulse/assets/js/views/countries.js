/* TERRA PULSE — Countries view (REST Countries data) */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'countries',
    initialized: false,
    timer: null,
    data: null,
    filter: '',
    region: 'all',

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 24 * 60 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-countries');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Countries of the World</h1>
            <p class="view-sub">Comprehensive data for all countries — population, capital, region, currency, languages.</p>
          </div>
          <div class="view-meta">
            <span class="chip">REST Countries</span>
            <span class="chip" id="countriesCount">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="flex gap-12" style="flex-wrap:wrap; align-items:center">
            <input type="search" id="countrySearch" class="input" style="flex:1; min-width:240px" placeholder="Search by name, capital, currency, language…" />
            <select id="countryRegion" class="select" style="width:auto">
              <option value="all">All regions</option>
              <option value="Africa">Africa</option>
              <option value="Americas">Americas</option>
              <option value="Asia">Asia</option>
              <option value="Europe">Europe</option>
              <option value="Oceania">Oceania</option>
              <option value="Antarctic">Antarctic</option>
            </select>
            <button class="btn btn-primary" id="countryRefresh">${icons.makeIcon('refresh', 16)} Refresh</button>
          </div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('flag', 18)} Country List</h2></div>
          <div id="countryTable" class="table-wrap"></div>
        </div>
      `;

      utils.id('countrySearch').addEventListener('input', (e) => { this.filter = e.target.value; this.renderTable(); });
      utils.id('countryRegion').addEventListener('change', (e) => { this.region = e.target.value; this.renderTable(); });
      utils.id('countryRefresh').addEventListener('click', () => this.refresh());
    },

    async refresh() {
      const el = utils.id('countryTable');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(8);
      try {
        this.data = await api.population.byCountry();
        this.renderTable();
        const cntEl = utils.id('countriesCount');
        if (cntEl) cntEl.textContent = (this.data?.length || 0) + ' countries';
      } catch {
        el.innerHTML = '<div class="text-dim">Failed to load country data</div>';
      }
    },

    renderTable() {
      const el = utils.id('countryTable');
      if (!el || !this.data) return;
      let filtered = this.data;
      if (this.region !== 'all') {
        filtered = filtered.filter((c) => c.region === this.region);
      }
      if (this.filter) {
        const f = this.filter.toLowerCase();
        filtered = filtered.filter((c) => {
          const name = c.name?.common?.toLowerCase() || '';
          const cap = (c.capital?.[0] || '').toLowerCase();
          const langs = Object.values(c.languages || {}).join(' ').toLowerCase();
          const curr = Object.keys(c.currencies || {}).join(' ').toLowerCase();
          return name.includes(f) || cap.includes(f) || langs.includes(f) || curr.includes(f);
        });
      }
      filtered.sort((a, b) => (b.population || 0) - (a.population || 0));
      el.innerHTML = `
        <table class="data">
          <thead><tr><th>Flag</th><th>Country</th><th>Capital</th><th>Region</th><th>Population</th><th>Area (km²)</th><th>Currency</th><th>Languages</th></tr></thead>
          <tbody>
            ${filtered.slice(0, 100).map((c) => `
              <tr>
                <td style="font-size:20px">${c.flags?.emoji || ''}</td>
                <td style="font-weight:600">${utils.escapeHtml(c.name?.common || c.name?.official || '—')}</td>
                <td>${utils.escapeHtml(c.capital?.[0] || '—')}</td>
                <td>${utils.escapeHtml(c.region || '—')}</td>
                <td class="num">${utils.fmt.int(c.population)}</td>
                <td class="num">${utils.fmt.int(c.area || 0)}</td>
                <td class="text-xs">${Object.keys(c.currencies || {}).join(', ') || '—'}</td>
                <td class="text-xs text-dim">${utils.escapeHtml(utils.truncate(Object.values(c.languages || {}).join(', '), 30))}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        ${filtered.length > 100 ? `<div class="text-xs text-dim" style="text-align:center; padding:8px">Showing 100 of ${filtered.length} countries. Refine search to see more.</div>` : ''}
      `;
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.countries = view;
})(window);
