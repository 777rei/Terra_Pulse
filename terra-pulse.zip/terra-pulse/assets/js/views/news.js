/* TERRA PULSE — News view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const SOURCES = [
    { id: 'world', name: 'World', icon: 'globe', get: () => api.news.world() },
    { id: 'tech', name: 'Technology', icon: 'cpu', get: function() { return api.news.rss('https://feeds.arstechnica.com/arstechnica/index.xml'); } },
    { id: 'business', name: 'Business', icon: 'briefcase', get: function() { return api.news.rss('https://feeds.bloomberg.com/markets/news.rss'); } },
    { id: 'space', name: 'Space', icon: 'rocket', get: () => api.news.spaceflight(20) },
    { id: 'crypto', name: 'Crypto', icon: 'bitcoin', get: () => api.news.cryptoCompare() },
    { id: 'hacker', name: 'Hacker News', icon: 'news', get: () => api.news.hackernews() }
  ];

  const view = {
    id: 'news',
    initialized: false,
    timer: null,
    activeSource: 'world',
    articles: [],

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 5 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-news');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">World News</h1>
            <p class="view-sub">Aggregated live news from multiple sources.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Live feeds</span>
            <span class="chip" id="newsUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('broadcast', 18)} Sources</h2></div>
          <div class="flex gap-8" style="flex-wrap:wrap" id="newsSources"></div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Articles</h2><input type="search" id="newsFilter" class="input" style="width:240px" placeholder="Filter…" /></div>
          <div id="newsList"></div>
        </div>
      `;

      const srcEl = utils.id('newsSources');
      srcEl.innerHTML = SOURCES.map((s) => `
        <button class="btn ${s.id === this.activeSource ? 'btn-primary' : ''}" data-src="${s.id}">${icons.makeIcon(s.icon, 16)} ${s.name}</button>
      `).join('');
      srcEl.querySelectorAll('[data-src]').forEach((b) => {
        b.addEventListener('click', () => {
          this.activeSource = b.dataset.src;
          srcEl.querySelectorAll('button').forEach((x) => x.className = 'btn');
          b.className = 'btn btn-primary';
          this.refresh();
        });
      });

      utils.id('newsFilter').addEventListener('input', (e) => this.renderArticles(e.target.value));
    },

    async refresh() {
      const listEl = utils.id('newsList');
      if (!listEl) return;
      listEl.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(5);
      try {
        const source = SOURCES.find((s) => s.id === this.activeSource);
        let items = [];
        if (this.activeSource === 'world') {
          items = await source.get();
        } else if (this.activeSource === 'space') {
          const d = await source.get();
          items = (d?.results || []).map((a) => ({
            title: a.title, link: a.url, pubDate: a.published_at,
            author: a.news_site, thumbnail: a.image_url, summary: a.summary
          }));
        } else if (this.activeSource === 'crypto') {
          const d = await source.get();
          items = (d?.Data || []).map((a) => ({
            title: a.title, link: a.url, pubDate: a.published_on * 1000,
            author: a.source_info?.name, summary: a.body
          }));
        } else if (this.activeSource === 'hacker') {
          const d = await source.get();
          items = (d?.hits || []).map((a) => ({
            title: a.title || a.story_title, link: a.url || a.story_url,
            pubDate: a.created_at_i * 1000, author: a.author, summary: a.story_text || ''
          }));
        } else {
          const d = await source.get();
          items = (d?.items || []).map((a) => ({ ...a }));
        }

        this.articles = items.filter((a) => a && a.title);
        this.renderArticles('');
        utils.id('newsUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch (e) {
        listEl.innerHTML = '<div class="text-dim">Failed to load news</div>';
      }
    },

    renderArticles(filter) {
      const listEl = utils.id('newsList');
      if (!listEl) return;
      let items = this.articles;
      if (filter) {
        const f = filter.toLowerCase();
        items = items.filter((a) => (a.title || '').toLowerCase().includes(f) || (a.summary || '').toLowerCase().includes(f));
      }
      if (!items.length) {
        listEl.innerHTML = '<div class="empty-state"><div class="icon-host">' + icons.makeIcon('news', 32) + '</div>No articles</div>';
        return;
      }
      listEl.innerHTML = items.slice(0, 30).map((a) => `
        <article class="card" style="margin-bottom:10px; padding:14px">
          <div class="flex between" style="gap:12px; align-items:flex-start">
            <div style="flex:1; min-width:0">
              <a href="${utils.escapeHtml(a.link || '#')}" target="_blank" rel="noopener noreferrer" style="font-weight:600; font-size:14px; line-height:1.4">${utils.escapeHtml(a.title)}</a>
              ${a.summary ? `<div class="text-sm text-dim" style="margin-top:6px; line-height:1.5">${utils.escapeHtml(utils.truncate(a.summary, 200))}</div>` : ''}
              <div class="text-xs text-dim" style="margin-top:6px">
                ${a.author ? `<span style="margin-right:8px">${utils.escapeHtml(a.author)}</span>` : ''}
                ${a.pubDate ? `<span>${utils.fmt.relative(a.pubDate)}</span>` : ''}
              </div>
            </div>
            ${a.thumbnail ? `<img src="${utils.escapeHtml(a.thumbnail)}" alt="" style="width:80px; height:80px; object-fit:cover; border-radius:8px" loading="lazy" onerror="this.style.display='none'" />` : ''}
          </div>
        </article>
      `).join('');
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.news = view;
})(window);
