/* TERRA PULSE — Solar System view (planets, orbits, sun) */
(function (global) {
  'use strict';
  const { utils, icons } = global.TP;

  // Planetary data (mean orbital elements, simplified)
  const PLANETS = [
    { name: 'Mercury', icon: 'planet', color: '#a8a8a8', radius: 2.4, distance: 0.39, period: 88, mass: 0.055, gravity: 3.7, moons: 0, temp: 167, diameter: 4879 },
    { name: 'Venus', icon: 'planet', color: '#ffcf5e', radius: 6.0, distance: 0.72, period: 225, mass: 0.815, gravity: 8.87, moons: 0, temp: 464, diameter: 12104 },
    { name: 'Earth', icon: 'globe', color: '#5ec3ff', radius: 6.37, distance: 1.0, period: 365, mass: 1.0, gravity: 9.81, moons: 1, temp: 15, diameter: 12742 },
    { name: 'Mars', icon: 'mars', color: '#ff5e7a', radius: 3.39, distance: 1.52, period: 687, mass: 0.107, gravity: 3.71, moons: 2, temp: -65, diameter: 6779 },
    { name: 'Jupiter', icon: 'jupiter', color: '#ff9c5e', radius: 69.9, distance: 5.20, period: 4333, mass: 317.8, gravity: 24.79, moons: 95, temp: -110, diameter: 139820 },
    { name: 'Saturn', icon: 'saturn', color: '#ffcf5e', radius: 58.2, distance: 9.58, period: 10759, mass: 95.2, gravity: 10.44, moons: 146, temp: -140, diameter: 116460 },
    { name: 'Uranus', icon: 'planet', color: '#5ec3ff', radius: 25.4, distance: 19.22, period: 30687, mass: 14.5, gravity: 8.69, moons: 27, temp: -195, diameter: 50724 },
    { name: 'Neptune', icon: 'planet', color: '#5ee7ff', radius: 24.6, distance: 30.05, period: 60190, mass: 17.1, gravity: 11.15, moons: 14, temp: -200, diameter: 49244 }
  ];

  const SUN = { name: 'Sun', color: '#ffd75e', radius: 696.34, mass: 332946, gravity: 274, temp: 5505, diameter: 1391400 };

  const view = {
    id: 'planets',
    initialized: false,
    timer: null,
    selected: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.tick();
      this.timer = setInterval(() => this.tick(), 1000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-planets');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Solar System</h1>
            <p class="view-sub">Live orbital positions, planetary data, and the Sun.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Live orbit sim</span>
            <span class="chip" id="planetsUpdated">—</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('orbit', 18)} Live Orbital Diagram</h2></div>
            <div id="orbitDiagram"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('sun', 18)} The Sun</h2></div>
            <div id="sunInfo"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Planetary Data</h2></div>
            <div id="planetTable" class="table-wrap"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('info', 18)} Selected Planet</h2></div>
            <div id="planetDetail"></div>
          </div>
        </div>
      `;
      this.renderOrbit();
      this.renderSun();
      this.renderTable();
    },

    renderOrbit() {
      const el = utils.id('orbitDiagram');
      if (!el) return;
      const W = 800, H = 500, cx = W / 2, cy = H / 2;
      // Scale distances logarithmically so outer planets fit
      const maxDist = 30.05;
      const maxR = Math.min(cx, cy) - 30;
      const distScale = (d) => Math.log(d + 1) / Math.log(maxDist + 1) * maxR;

      let svg = `<svg viewBox="0 0 ${W} ${H}" style="width:100%; height:auto">`;
      // Background stars
      for (let i = 0; i < 50; i++) {
        const x = Math.random() * W, y = Math.random() * H, r = Math.random() * 0.6;
        svg += `<circle cx="${x}" cy="${y}" r="${r}" fill="#fff" opacity="${Math.random() * 0.6}"/>`;
      }
      // Orbit rings
      PLANETS.forEach((p) => {
        const r = distScale(p.distance);
        svg += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(174,184,216,.15)" stroke-width="0.5" stroke-dasharray="2 3"/>`;
      });
      // Sun
      svg += `<circle cx="${cx}" cy="${cy}" r="8" fill="${SUN.color}" filter="url(#sunGlow)"/>`;
      svg += `<circle cx="${cx}" cy="${cy}" r="14" fill="none" stroke="${SUN.color}" stroke-opacity="0.3"/>`;
      // Planets
      PLANETS.forEach((p, i) => {
        const r = distScale(p.distance);
        const angle = (Date.now() / 1000 / p.period * 2 * Math.PI) % (2 * Math.PI);
        const x = cx + Math.cos(angle) * r;
        const y = cy + Math.sin(angle) * r;
        const size = Math.max(2, Math.log(p.diameter / 1000) * 1.5);
        svg += `<circle cx="${x}" cy="${y}" r="${size}" fill="${p.color}" stroke="#fff" stroke-width="0.3" style="cursor:pointer" data-planet="${i}"/>`;
        svg += `<text x="${x + size + 2}" y="${y + 3}" font-size="9" fill="#aeb8d8">${p.name}</text>`;
      });
      svg += `<defs><filter id="sunGlow"><feGaussianBlur stdDeviation="3"/><feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
      svg += '</svg>';
      el.innerHTML = svg;
      // Wire planet clicks
      el.querySelectorAll('[data-planet]').forEach((node) => {
        node.addEventListener('click', () => {
          const idx = parseInt(node.dataset.planet, 10);
          this.selectPlanet(idx);
        });
      });
    },

    renderSun() {
      const el = utils.id('sunInfo');
      if (!el) return;
      el.innerHTML = `
        <div style="text-align:center; padding:12px">
          <div class="icon-host" style="color:${SUN.color}; margin-bottom:8px">${icons.makeIcon('sun', 64)}</div>
          <div style="font-size:18px; font-weight:700">${SUN.name}</div>
        </div>
        <div class="card-row"><span class="label">Diameter</span><span class="value">${SUN.diameter.toLocaleString()} km</span></div>
        <div class="card-row"><span class="label">Mass (Earth=1)</span><span class="value">${SUN.mass.toLocaleString()}</span></div>
        <div class="card-row"><span class="label">Surface temp</span><span class="value" style="color:${SUN.color}">${SUN.temp}°C</span></div>
        <div class="card-row"><span class="label">Gravity</span><span class="value">${SUN.gravity} m/s²</span></div>
      `;
    },

    renderTable() {
      const el = utils.id('planetTable');
      if (!el) return;
      el.innerHTML = `
        <table class="data">
          <thead><tr><th>Planet</th><th>Distance (AU)</th><th>Period (days)</th><th>Diameter (km)</th><th>Mass (E=1)</th><th>Gravity (m/s²)</th><th>Moons</th><th>Avg Temp</th></tr></thead>
          <tbody>
            ${PLANETS.map((p, i) => `
              <tr style="cursor:pointer" data-planet="${i}">
                <td><span style="display:inline-flex; align-items:center; gap:6px"><span style="width:10px; height:10px; background:${p.color}; border-radius:50%"></span>${icons.makeIcon(p.icon, 14)} ${p.name}</span></td>
                <td class="num">${p.distance}</td>
                <td class="num">${p.period}</td>
                <td class="num">${p.diameter.toLocaleString()}</td>
                <td class="num">${p.mass}</td>
                <td class="num">${p.gravity}</td>
                <td class="num">${p.moons}</td>
                <td class="num" style="color:${utils.color.temp(p.temp)}">${p.temp}°C</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
      el.querySelectorAll('[data-planet]').forEach((tr) => {
        tr.addEventListener('click', () => this.selectPlanet(parseInt(tr.dataset.planet, 10)));
      });
    },

    selectPlanet(idx) {
      const p = PLANETS[idx];
      if (!p) return;
      this.selected = p;
      const el = utils.id('planetDetail');
      if (!el) return;
      el.innerHTML = `
        <div style="text-align:center; padding:12px">
          <div class="icon-host" style="color:${p.color}; margin-bottom:8px">${icons.makeIcon(p.icon, 56)}</div>
          <div style="font-size:18px; font-weight:700; color:${p.color}">${p.name}</div>
        </div>
        <div class="card-row"><span class="label">Distance from Sun</span><span class="value">${p.distance} AU (${(p.distance * 149.6).toFixed(1)}M km)</span></div>
        <div class="card-row"><span class="label">Orbital period</span><span class="value">${p.period} days (${(p.period / 365).toFixed(2)} years)</span></div>
        <div class="card-row"><span class="label">Diameter</span><span class="value">${p.diameter.toLocaleString()} km</span></div>
        <div class="card-row"><span class="label">Mass (Earth=1)</span><span class="value">${p.mass}</span></div>
        <div class="card-row"><span class="label">Surface gravity</span><span class="value">${p.gravity} m/s²</span></div>
        <div class="card-row"><span class="label">Number of moons</span><span class="value">${p.moons}</span></div>
        <div class="card-row"><span class="label">Average temperature</span><span class="value" style="color:${utils.color.temp(p.temp)}">${p.temp}°C</span></div>
        <div class="card-row"><span class="label">Current orbit position</span><span class="value">${((Date.now() / 1000 / p.period * 360) % 360).toFixed(1)}°</span></div>
      `;
    },

    tick() {
      this.renderOrbit();
      const updEl = utils.id('planetsUpdated');
      if (updEl) updEl.textContent = utils.fmt.time(new Date());
      if (this.selected) {
        const idx = PLANETS.findIndex((p) => p.name === this.selected.name);
        if (idx >= 0) this.selectPlanet(idx);
      } else {
        this.selectPlanet(2); // Earth
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.planets = view;
})(window);
