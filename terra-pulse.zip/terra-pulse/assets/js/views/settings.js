/* TERRA PULSE — Settings view */
(function (global) {
  'use strict';
  const { utils, store, icons } = global.TP;

  const view = {
    id: 'settings',
    initialized: false,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
    },

    destroy() {},

    render() {
      const root = utils.id('view-settings');
      if (!root) return;
      const s = store.get();
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Settings</h1>
            <p class="view-sub">Customize your TERRA PULSE experience. Saved locally to your device.</p>
          </div>
          <div class="view-meta">
            <span class="chip">v1.0.0</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('palette', 18)} Appearance</h2></div>
            <div class="field">
              <label>Theme (8 available)</label>
              <select id="setTheme" class="select">
                <option value="dark" ${s.theme === 'dark' ? 'selected' : ''}>Dark (Aurora)</option>
                <option value="light" ${s.theme === 'light' ? 'selected' : ''}>Light</option>
                <option value="amoled" ${s.theme === 'amoled' ? 'selected' : ''}>AMOLED (True Black)</option>
                <option value="sunset" ${s.theme === 'sunset' ? 'selected' : ''}>Sunset (Warm)</option>
                <option value="ocean" ${s.theme === 'ocean' ? 'selected' : ''}>Ocean (Teal)</option>
                <option value="forest" ${s.theme === 'forest' ? 'selected' : ''}>Forest (Green)</option>
                <option value="midnight" ${s.theme === 'midnight' ? 'selected' : ''}>Midnight (Purple)</option>
                <option value="neon" ${s.theme === 'neon' ? 'selected' : ''}>Neon (Cyberpunk)</option>
              </select>
            </div>
            <div class="field">
              <label class="switch">
                <input type="checkbox" id="setSidebar" ${s.sidebarCollapsed ? 'checked' : ''}>
                <span class="track"></span>
                <span>Collapse sidebar by default</span>
              </label>
            </div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('refresh', 18)} Refresh</h2></div>
            <div class="field">
              <label>Auto-refresh interval (seconds)</label>
              <input type="number" id="setInterval" class="input" min="10" max="600" value="${s.refreshInterval}" />
            </div>
            <div class="field">
              <label class="switch">
                <input type="checkbox" id="setAutoRefresh" ${s.autoRefresh ? 'checked' : ''}>
                <span class="track"></span>
                <span>Enable auto-refresh</span>
              </label>
            </div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('bell', 18)} Notifications</h2></div>
            <div class="field">
              <label class="switch">
                <input type="checkbox" id="setNotif" ${s.notificationsEnabled ? 'checked' : ''}>
                <span class="track"></span>
                <span>Enable in-app notifications</span>
              </label>
            </div>
            <div class="field">
              <label class="switch">
                <input type="checkbox" id="setSound" ${s.soundEnabled ? 'checked' : ''}>
                <span class="track"></span>
                <span>Play sound on alerts</span>
              </label>
            </div>
            <button class="btn" id="testNotif">${icons.makeIcon('bell', 16)} Send test notification</button>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('thermometer', 18)} Units</h2></div>
            <div class="field">
              <label>Temperature unit</label>
              <select id="setTemp" class="select">
                <option value="C" ${s.temperatureUnit === 'C' ? 'selected' : ''}>Celsius (°C)</option>
                <option value="F" ${s.temperatureUnit === 'F' ? 'selected' : ''}>Fahrenheit (°F)</option>
              </select>
            </div>
            <div class="field">
              <label>Measurement system</label>
              <select id="setUnits" class="select">
                <option value="metric" ${s.units === 'metric' ? 'selected' : ''}>Metric (km, kg)</option>
                <option value="imperial" ${s.units === 'imperial' ? 'selected' : ''}>Imperial (mi, lb)</option>
              </select>
            </div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('database', 18)} Data & Cache</h2></div>
            <div class="card-row"><span class="label">Cache size</span><span class="value" id="cacheSize">—</span></div>
            <div class="card-row"><span class="label">Service worker</span><span class="value" id="swStatus">—</span></div>
            <div class="card-row"><span class="label">Install state</span><span class="value" id="installState">—</span></div>
            <div class="flex gap-8 mt-12" style="flex-wrap:wrap">
              <button class="btn" id="clearCache">${icons.makeIcon('trash', 16)} Clear cache</button>
              <button class="btn" id="installApp">${icons.makeIcon('download', 16)} Install app</button>
              <button class="btn btn-ghost" id="resetAll">${icons.makeIcon('refresh', 16)} Reset all settings</button>
            </div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('info', 18)} About</h2></div>
            <div class="card-row"><span class="label">Name</span><span class="value">TERRA PULSE</span></div>
            <div class="card-row"><span class="label">Version</span><span class="value">1.0.0</span></div>
            <div class="card-row"><span class="label">Type</span><span class="value">PWA · Static HTML</span></div>
            <div class="card-row"><span class="label">License</span><span class="value">MIT</span></div>
            <div class="card-row"><span class="label">Created by</span><span class="value" style="color:var(--accent); font-weight:600">Rei</span></div>
            <div class="card-row"><span class="label">Storage used</span><span class="value" id="storageUsed">—</span></div>
          </div>
        </div>
      `;

      utils.id('setTheme').addEventListener('change', (e) => {
        store.set('theme', e.target.value);
        document.body.className = 'theme-' + e.target.value;
      });
      utils.id('setSidebar').addEventListener('change', (e) => {
        store.set('sidebarCollapsed', e.target.checked);
        document.body.classList.toggle('sidebar-collapsed', e.target.checked);
      });
      utils.id('setInterval').addEventListener('change', (e) => {
        store.set('refreshInterval', parseInt(e.target.value, 10) || 30);
      });
      utils.id('setAutoRefresh').addEventListener('change', (e) => store.set('autoRefresh', e.target.checked));
      utils.id('setNotif').addEventListener('change', (e) => store.set('notificationsEnabled', e.target.checked));
      utils.id('setSound').addEventListener('change', (e) => store.set('soundEnabled', e.target.checked));
      utils.id('setTemp').addEventListener('change', (e) => store.set('temperatureUnit', e.target.value));
      utils.id('setUnits').addEventListener('change', (e) => store.set('units', e.target.value));
      utils.id('testNotif').addEventListener('click', () => {
        store.addNotification({ type: 'info', title: 'Test notification', message: 'If you can see this, notifications are working.' });
        global.TP.app.toast('Test notification sent', 'success');
      });
      utils.id('clearCache').addEventListener('click', () => {
        store.cache.clear();
        if (navigator.serviceWorker?.controller) {
          navigator.serviceWorker.controller.postMessage('CLEAR_CACHE');
        }
        global.TP.app.toast('Cache cleared', 'success');
        this.updateStorageInfo();
      });
      utils.id('installApp').addEventListener('click', () => {
        if (global.TP.app.deferredPrompt) {
          global.TP.app.deferredPrompt.prompt();
        } else {
          global.TP.app.toast('Use browser menu → "Install app" or "Add to Home Screen"', 'info');
        }
      });
      utils.id('resetAll').addEventListener('click', () => {
        if (confirm('Reset all settings to defaults?')) {
          store.reset();
          location.reload();
        }
      });

      this.updateStorageInfo();
    },

    async updateStorageInfo() {
      try {
        if (navigator.storage?.estimate) {
          const est = await navigator.storage.estimate();
          const used = est.usage || 0;
          const quota = est.quota || 0;
          const sz = utils.id('storageUsed');
          if (sz) sz.textContent = `${utils.fmt.compact(used)} / ${utils.fmt.compact(quota)} bytes`;
        }
      } catch {}

      const cacheKeys = Object.keys(localStorage).filter((k) => k.startsWith('tp:cache:'));
      const cs = utils.id('cacheSize');
      if (cs) cs.textContent = `${cacheKeys.length} items`;

      const sw = utils.id('swStatus');
      if (sw) sw.textContent = navigator.serviceWorker?.controller ? 'Active' : 'Not active';

      const ins = utils.id('installState');
      if (ins) {
        const standalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
        ins.textContent = standalone ? 'Installed' : 'Available';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.settings = view;
})(window);
