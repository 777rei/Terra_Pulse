/* TERRA PULSE — Health view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'health',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 30 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-health');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">World Health</h1>
            <p class="view-sub">COVID-19 statistics and global health indicators. Data via disease.sh.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>disease.sh</span>
            <span class="chip" id="healthUpdated">—</span>
          </div>
        </div>

        <div class="kpi-grid" id="healthKpis"></div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('trophy', 18)} Top 15 Countries by Cases</h2></div>
            <div id="healthTable" class="table-wrap"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('chart', 18)} 30-Day Global Trend</h2></div>
            <div id="healthChart"></div>
          </div>
        </div>
      `;
    },

    async refresh() {
      const kpiEl = utils.id('healthKpis');
      const tableEl = utils.id('healthTable');
      if (!kpiEl) return;
      kpiEl.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(4);
      try {
        const [global, countries, history] = await Promise.allSettled([
          api.health.global(),
          api.health.countries(),
          api.health.history('all', 30)
        ]);

        const g = global.status === 'fulfilled' ? global.value : null;
        const c = countries.status === 'fulfilled' ? countries.value : null;
        const h = history.status === 'fulfilled' ? history.value : null;

        if (g) {
          kpiEl.innerHTML = `
            <div class="kpi kpi-1">
              <div class="kpi-label">Total Cases</div>
              <div class="kpi-value">${utils.fmt.compact(g.cases)}</div>
              <div class="kpi-meta">+${utils.fmt.compact(g.todayCases)} today</div>
            </div>
            <div class="kpi kpi-4">
              <div class="kpi-label">Total Deaths</div>
              <div class="kpi-value">${utils.fmt.compact(g.deaths)}</div>
              <div class="kpi-meta">+${utils.fmt.compact(g.todayDeaths)} today</div>
            </div>
            <div class="kpi kpi-3">
              <div class="kpi-label">Recovered</div>
              <div class="kpi-value">${utils.fmt.compact(g.recovered)}</div>
              <div class="kpi-meta">${((g.recovered / g.cases) * 100).toFixed(1)}% recovery</div>
            </div>
            <div class="kpi kpi-2">
              <div class="kpi-label">Active Cases</div>
              <div class="kpi-value">${utils.fmt.compact(g.active)}</div>
              <div class="kpi-meta">${utils.fmt.compact(g.critical)} critical</div>
            </div>
            <div class="kpi kpi-5">
              <div class="kpi-label">Tests</div>
              <div class="kpi-value">${utils.fmt.compact(g.tests)}</div>
              <div class="kpi-meta">${utils.fmt.compact(g.testsPerOneMillion)} per M</div>
            </div>
            <div class="kpi kpi-6">
              <div class="kpi-label">Affected Countries</div>
              <div class="kpi-value">${g.affectedCountries}</div>
              <div class="kpi-meta">countries reporting</div>
            </div>
          `;
        }

        if (c && Array.isArray(c)) {
          tableEl.innerHTML = `
            <table class="data">
              <thead><tr><th>#</th><th>Country</th><th>Cases</th><th>Today</th><th>Deaths</th><th>Today</th><th>Recovered</th><th>Active</th><th>Critical</th></tr></thead>
              <tbody>
                ${c.slice(0, 15).map((country, i) => `
                  <tr>
                    <td class="num">${i + 1}</td>
                    <td><div class="flex gap-8 center">${country.countryInfo?.flag ? `<img src="${utils.escapeHtml(country.countryInfo.flag)}" alt="" width="20" height="14" loading="lazy" onerror="this.style.display='none'"/>` : ''}<span style="font-weight:600">${utils.escapeHtml(country.country)}</span></div></td>
                    <td class="num">${utils.fmt.int(country.cases)}</td>
                    <td class="num up">+${utils.fmt.int(country.todayCases)}</td>
                    <td class="num">${utils.fmt.int(country.deaths)}</td>
                    <td class="num down">+${utils.fmt.int(country.todayDeaths)}</td>
                    <td class="num">${utils.fmt.int(country.recovered)}</td>
                    <td class="num">${utils.fmt.int(country.active)}</td>
                    <td class="num">${utils.fmt.int(country.critical)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          `;
        }

        if (h?.timeline?.cases) {
          const cases = Object.entries(h.timeline.cases).sort((a, b) => a[0].localeCompare(b[0]));
          const values = cases.map(([, v]) => v);
          const dailyNew = values.map((v, i) => i === 0 ? 0 : v - values[i - 1]);
          const W = 600, H = 180, pad = 30;
          const max = Math.max(...dailyNew, 1);
          const stepX = (W - pad * 2) / (dailyNew.length - 1);
          const points = dailyNew.map((v, i) => `${pad + i * stepX},${H - pad - (v / max) * (H - pad * 2)}`).join(' ');
          utils.id('healthChart').innerHTML = `
            <svg viewBox="0 0 ${W} ${H}" style="width:100%; height:auto">
              <defs>
                <linearGradient id="hgGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="#ff5e7a" stop-opacity="0.4"/>
                  <stop offset="100%" stop-color="#ff5e7a" stop-opacity="0"/>
                </linearGradient>
              </defs>
              <polyline points="${pad},${H-pad} ${points} ${W-pad},${H-pad}" fill="url(#hgGrad)"/>
              <polyline points="${points}" fill="none" stroke="#ff5e7a" stroke-width="2"/>
              <text x="${pad}" y="${H-8}" font-size="9" fill="#aeb8d8">${cases[0]?.[0]}</text>
              <text x="${W-pad}" y="${H-8}" font-size="9" fill="#aeb8d8" text-anchor="end">${cases[cases.length-1]?.[0]}</text>
            </svg>
            <div class="text-xs text-dim" style="margin-top:6px">Daily new cases (last 30 days)</div>
          `;
        }

        utils.id('healthUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        kpiEl.innerHTML = '<div class="text-dim">Health data unavailable</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.health = view;
})(window);
