/* TERRA PULSE — Commodities view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'commodities',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 10 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-commodities');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Commodities</h1>
            <p class="view-sub">Energy, metals, and agricultural futures. End-of-day prices via Stooq.</p>
          </div>
          <div class="view-meta">
            <span class="chip">Stooq</span>
            <span class="chip" id="comUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('grid', 18)} Commodity Heatmap (day change)</h2></div>
          <div id="comHeatmap" class="heatmap-grid"></div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('chartBar', 18)} Commodity Prices</h2></div>
          <div id="comTable" class="table-wrap"></div>
        </div>
      `;
    },

    async refresh() {
      const el = utils.id('comTable');
      const heatEl = utils.id('comHeatmap');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(5);
      try {
        const data = await api.commodities.all();
        el.innerHTML = `
          <table class="data">
            <thead><tr><th>Commodity</th><th>Symbol</th><th>Price</th><th>Open</th><th>High</th><th>Low</th><th>Day Change</th><th>Date</th></tr></thead>
            <tbody>
              ${data.map((c) => {
                if (!c.price) return `<tr><td>${utils.escapeHtml(c.name)}</td><td class="num">${utils.escapeHtml(c.symbol)}</td><td colspan="6" class="text-dim">N/A</td></tr>`;
                const change = c.close - c.open;
                const changePct = c.open ? (change / c.open * 100) : 0;
                return `<tr>
                  <td style="font-weight:600">${utils.escapeHtml(c.name)}</td>
                  <td class="num text-dim">${utils.escapeHtml(c.symbol)}</td>
                  <td class="num" style="font-weight:700">$${utils.fmt.decimals(c.price, 2)}</td>
                  <td class="num">$${utils.fmt.decimals(c.open, 2)}</td>
                  <td class="num up">$${utils.fmt.decimals(c.high, 2)}</td>
                  <td class="num down">$${utils.fmt.decimals(c.low, 2)}</td>
                  <td class="num ${utils.color.changeColor(change)}">${change >= 0 ? '+' : ''}${utils.fmt.decimals(change, 2)} (${utils.fmt.percent(changePct)})</td>
                  <td class="text-xs text-dim">${utils.escapeHtml(c.date || '—')}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        `;

        if (heatEl) {
          heatEl.innerHTML = data.filter((c) => c.price).map((c) => {
            const change = c.close - c.open;
            const changePct = c.open ? (change / c.open * 100) : 0;
            const color = utils.color.heatColor(changePct);
            const opacity = Math.max(0.4, utils.color.heatOpacity(changePct));
            const ic = c.name.includes('Oil') ? 'oil' : c.name.includes('Gold') ? 'gold' : c.name.includes('Silver') ? 'silver' : c.name.includes('Copper') ? 'gold' : c.name.includes('Gas') ? 'flame' : c.name.includes('Wheat') || c.name.includes('Corn') ? 'plant' : c.name.includes('Coffee') || c.name.includes('Sugar') ? 'droplet' : 'chart';
            return `
              <div class="heatmap-cell" style="background:${color}; opacity:${opacity}">
                <div class="hm-symbol">${icons.makeIcon(ic, 14)} ${utils.escapeHtml(c.name.split(' ')[0])}</div>
                <div class="hm-price">$${utils.fmt.decimals(c.price, 2)}</div>
                <div class="hm-change">${utils.fmt.percent(changePct)}</div>
              </div>
            `;
          }).join('');
        }
        utils.id('comUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        el.innerHTML = '<div class="text-dim">Commodities data unavailable</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.commodities = view;
})(window);
