/* TERRA PULSE — Air Quality view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const CITIES = [
    { name: 'Beijing', lat: 39.9042, lng: 116.4074 },
    { name: 'Delhi', lat: 28.7041, lng: 77.1025 },
    { name: 'Los Angeles', lat: 34.0522, lng: -118.2437 },
    { name: 'London', lat: 51.5074, lng: -0.1278 },
    { name: 'Paris', lat: 48.8566, lng: 2.3522 },
    { name: 'Tokyo', lat: 35.6762, lng: 139.6503 },
    { name: 'São Paulo', lat: -23.5505, lng: -46.6333 },
    { name: 'Cairo', lat: 30.0444, lng: 31.2357 },
    { name: 'Moscow', lat: 55.7558, lng: 37.6173 },
    { name: 'Bangkok', lat: 13.7563, lng: 100.5018 },
    { name: 'Mexico City', lat: 19.4326, lng: -99.1332 },
    { name: 'Lahore', lat: 31.5204, lng: 74.3587 }
  ];

  const view = {
    id: 'airquality',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 10 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-airquality');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Air Quality Monitor</h1>
            <p class="view-sub">Real-time AQI, PM2.5, PM10, ozone, NO₂, SO₂ across world cities.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Open-Meteo Air Quality</span>
            <span class="chip" id="aqUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('grid', 18)} AQI Heatmap by City</h2></div>
          <div id="aqGrid" class="card-grid"></div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Detailed Pollutant Levels</h2></div>
          <div id="aqTable" class="table-wrap"></div>
        </div>

        <div class="tile mt-16">
          <div class="tile-head"><h2>${icons.makeIcon('info', 18)} AQI Scale</h2></div>
          <div class="card-grid">
            <div class="card"><div class="flex between center"><span class="pill pill-good">0–50</span><span>Good</span></div></div>
            <div class="card"><div class="flex between center"><span class="pill pill-warn">51–100</span><span>Moderate</span></div></div>
            <div class="card"><div class="flex between center"><span class="pill" style="background:#ff9c5e22; color:#ff9c5e">101–150</span><span>Unhealthy (Sensitive)</span></div></div>
            <div class="card"><div class="flex between center"><span class="pill pill-bad">151–200</span><span>Unhealthy</span></div></div>
            <div class="card"><div class="flex between center"><span class="pill" style="background:#b07bff22; color:#b07bff">201–300</span><span>Very Unhealthy</span></div></div>
            <div class="card"><div class="flex between center"><span class="pill" style="background:#7a1f3d22; color:#ff5e7a">301+</span><span>Hazardous</span></div></div>
          </div>
        </div>
      `;
    },

    async refresh() {
      const gridEl = utils.id('aqGrid');
      const tableEl = utils.id('aqTable');
      if (!gridEl) return;
      gridEl.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(6);
      try {
        const results = await Promise.allSettled(
          CITIES.map((c) => api.weather.airQuality(c.lat, c.lng).then((d) => ({ ...c, data: d })))
        );
        const data = results
          .filter((r) => r.status === 'fulfilled' && r.value.data)
          .map((r) => r.value)
          .sort((a, b) => (b.data.current.us_aqi || 0) - (a.data.current.us_aqi || 0));

        gridEl.innerHTML = data.map((d) => {
          const aqi = d.data.current.us_aqi;
          const [color, label] = utils.color.aqi(aqi);
          return `
            <div class="card" style="border-left:4px solid ${color}">
              <div class="flex between center">
                <div>
                  <div class="card-title">${utils.escapeHtml(d.name)}</div>
                  <div class="text-xs text-dim">${utils.escapeHtml(label)}</div>
                </div>
                <div style="font-size:28px; font-weight:700; color:${color}">${aqi || '—'}</div>
              </div>
              <div class="card-row"><span class="label">PM2.5</span><span class="value">${d.data.current.pm2_5?.toFixed(1) || '—'} µg/m³</span></div>
              <div class="card-row"><span class="label">PM10</span><span class="value">${d.data.current.pm10?.toFixed(1) || '—'} µg/m³</span></div>
              <div class="card-row"><span class="label">O₃</span><span class="value">${d.data.current.ozone?.toFixed(1) || '—'} µg/m³</span></div>
              <div class="card-row"><span class="label">NO₂</span><span class="value">${d.data.current.nitrogen_dioxide?.toFixed(1) || '—'} µg/m³</span></div>
            </div>
          `;
        }).join('');

        tableEl.innerHTML = `
          <table class="data">
            <thead><tr><th>City</th><th>AQI</th><th>Category</th><th>PM2.5</th><th>PM10</th><th>O₃</th><th>NO₂</th><th>SO₂</th><th>CO</th></tr></thead>
            <tbody>
              ${data.map((d) => {
                const aqi = d.data.current.us_aqi;
                const [color, label] = utils.color.aqi(aqi);
                return `<tr>
                  <td>${utils.escapeHtml(d.name)}</td>
                  <td class="num" style="color:${color}; font-weight:700">${aqi || '—'}</td>
                  <td>${utils.escapeHtml(label)}</td>
                  <td class="num">${d.data.current.pm2_5?.toFixed(1) || '—'}</td>
                  <td class="num">${d.data.current.pm10?.toFixed(1) || '—'}</td>
                  <td class="num">${d.data.current.ozone?.toFixed(1) || '—'}</td>
                  <td class="num">${d.data.current.nitrogen_dioxide?.toFixed(1) || '—'}</td>
                  <td class="num">${d.data.current.sulphur_dioxide?.toFixed(1) || '—'}</td>
                  <td class="num">${d.data.current.carbon_monoxide?.toFixed(1) || '—'}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        `;

        const updEl = utils.id('aqUpdated');
        if (updEl) updEl.textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        gridEl.innerHTML = '<div class="text-dim">Air quality data unavailable</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.airquality = view;
})(window);
