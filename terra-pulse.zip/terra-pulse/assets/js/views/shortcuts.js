/* TERRA PULSE — Shortcuts view (redirects to overlay) */
(function (global) {
  'use strict';
  const view = {
    id: 'shortcuts',
    initialized: false,
    init() {
      if (this.initialized) return;
      this.initialized = true;
      // Just open the overlay
      if (global.TP.app?.openKbdOverlay) global.TP.app.openKbdOverlay();
      // Navigate back to overview
      setTimeout(() => { location.hash = 'overview'; }, 100);
    },
    destroy() {}
  };
  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.shortcuts = view;
})(window);
