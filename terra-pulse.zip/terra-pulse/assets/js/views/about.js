/* TERRA PULSE — About view */
(function (global) {
  'use strict';
  const { utils, icons } = global.TP;

  const view = {
    id: 'about',
    initialized: false,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
    },

    destroy() {},

    render() {
      const root = utils.id('view-about');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">About TERRA PULSE</h1>
            <p class="view-sub">A real-time global data dashboard built as a static PWA. Free, open, offline-capable. Created by Rei.</p>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('globe', 18)} What is TERRA PULSE?</h2></div>
            <p style="line-height:1.7; color:var(--text-2)">
              TERRA PULSE is a single-page progressive web app that brings together real-time data from dozens of free, public APIs into one cohesive dashboard. It tracks weather, climate, air quality, earthquakes, crypto, stocks, forex, commodities, world news, space launches, the ISS, internet activity, and much more — all in a single, beautiful, responsive interface.
            </p>
            <p style="line-height:1.7; color:var(--text-2); margin-top:12px">
              The app is built as 100% static HTML, CSS, and JavaScript. There's no backend, no server-side code, no analytics, no tracking. Everything runs in your browser, and once installed it works offline thanks to a service worker that caches all assets.
            </p>
            <p style="line-height:1.7; color:var(--text-2); margin-top:12px">
              The dashboard is fully responsive — it works on phones, tablets, desktops, and any device with a modern browser. It's a PWA, so you can install it to your home screen on iOS, Android, Windows, macOS, and Linux.
            </p>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('plug', 18)} Data Sources</h2></div>
            <ul style="line-height:1.8; color:var(--text-2); font-size:13px">
              <li>${icons.makeIcon('sunCloud', 14)} <strong>Open-Meteo</strong> — Weather, air quality, climate archive</li>
              <li>${icons.makeIcon('earthquake', 14)} <strong>USGS</strong> — Earthquake feeds (real-time)</li>
              <li>${icons.makeIcon('bitcoin', 14)} <strong>CoinGecko</strong> — Crypto markets & global stats</li>
              <li>${icons.makeIcon('exchange', 14)} <strong>open.er-api.com</strong> — Live forex rates</li>
              <li>${icons.makeIcon('chartUp', 14)} <strong>Yahoo Finance / Stooq</strong> — Stocks & commodities</li>
              <li>${icons.makeIcon('rocket', 14)} <strong>Open Notify / NASA</strong> — ISS, APOD, Mars weather</li>
              <li>${icons.makeIcon('news', 14)} <strong>RSS feeds</strong> — BBC, NYT, Al Jazeera, Ars Technica</li>
              <li>${icons.makeIcon('news', 14)} <strong>Hacker News (Algolia)</strong> — Top stories</li>
              <li>${icons.makeIcon('book', 14)} <strong>Wikimedia</strong> — Recent edits, "On this day"</li>
              <li>${icons.makeIcon('satellite', 14)} <strong>The Space Devs</strong> — Upcoming launches</li>
              <li>${icons.makeIcon('calendar', 14)} <strong>Nager.Date</strong> — Public holidays</li>
              <li>${icons.makeIcon('medical', 14)} <strong>disease.sh</strong> — COVID-19 statistics</li>
              <li>${icons.makeIcon('network', 14)} <strong>Cloudflare</strong> — Network trace, IP info</li>
              <li>${icons.makeIcon('users', 14)} <strong>REST Countries</strong> — Country data</li>
              <li>${icons.makeIcon('map', 14)} <strong>world-atlas TopoJSON</strong> — Accurate country boundaries</li>
            </ul>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('sparkles', 18)} Features</h2></div>
            <ul style="line-height:1.8; color:var(--text-2); font-size:13px">
              <li>25+ live data views</li>
              <li>Accurate world map (real TopoJSON)</li>
              <li>Live animated forex heatmap</li>
              <li>Live stock market heatmap</li>
              <li>Crypto heatmap with sparklines</li>
              <li>KPI dashboard with sparklines</li>
              <li>Global search across data</li>
              <li>Dark/light themes</li>
              <li>Full PWA: installable, offline-capable</li>
              <li>Responsive on all devices</li>
              <li>No accounts, no API keys, no tracking</li>
              <li>Auto-refresh with smart caching</li>
              <li>Animated aurora background + starfield</li>
              <li>Professional SVG outline icons (no emoji)</li>
              <li>Toast notifications & alerts panel</li>
              <li>Geolocation-based weather</li>
              <li>Currency converter</li>
              <li>Earthquake filters & magnitude chart</li>
              <li>ISS live tracker on world map</li>
              <li>30-day historical charts</li>
              <li>Live ticker for crypto, stocks, forex</li>
            </ul>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('cpu', 18)} Tech Stack</h2></div>
            <div class="card-row"><span class="label">Languages</span><span class="value">HTML, CSS, vanilla JS</span></div>
            <div class="card-row"><span class="label">Frameworks</span><span class="value">None (zero dependencies)</span></div>
            <div class="card-row"><span class="label">Map data</span><span class="value">world-atlas TopoJSON</span></div>
            <div class="card-row"><span class="label">Storage</span><span class="value">localStorage + Cache API</span></div>
            <div class="card-row"><span class="label">Offline</span><span class="value">Service Worker</span></div>
            <div class="card-row"><span class="label">Manifest</span><span class="value">Web App Manifest</span></div>
            <div class="card-row"><span class="label">Icons</span><span class="value">Custom SVG outline library</span></div>
            <div class="card-row"><span class="label">License</span><span class="value">MIT</span></div>
          </div>

          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('shield', 18)} Privacy</h2></div>
            <p style="line-height:1.7; color:var(--text-2)">
              TERRA PULSE does not collect, store, or transmit any personal data. All settings are saved locally in your browser's localStorage. No analytics, no tracking pixels, no advertising SDKs, no third-party scripts (other than direct API calls to data sources).
            </p>
            <p style="line-height:1.7; color:var(--text-2); margin-top:12px">
              Your IP address is sent only to public APIs you actively query (e.g., weather, forex, news) — exactly as if you visited those services directly. The app does not proxy any requests through a server.
            </p>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('download', 18)} Install</h2></div>
            <p style="color:var(--text-2); line-height:1.6; font-size:13px">
              Install TERRA PULSE to your home screen / desktop for a native-app experience:
            </p>
            <ul style="line-height:1.8; color:var(--text-2); font-size:13px; margin-top:8px">
              <li>${icons.makeIcon('phone', 14)} <strong>Android (Chrome):</strong> Menu → "Install app"</li>
              <li>${icons.makeIcon('phone', 14)} <strong>iOS (Safari):</strong> Share → "Add to Home Screen"</li>
              <li>${icons.makeIcon('cpu', 14)} <strong>Desktop (Chrome/Edge):</strong> Click install icon in address bar</li>
              <li>${icons.makeIcon('cpu', 14)} <strong>Linux/Mac/Windows:</strong> Chrome → install</li>
            </ul>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('award', 18)} Credits</h2></div>
            <div class="card-row"><span class="label">Created by</span><span class="value" style="color:var(--accent); font-weight:700; font-size:14px">Rei</span></div>
            <div class="card-row"><span class="label">Map data</span><span class="value">Natural Earth (public domain)</span></div>
            <div class="card-row"><span class="label">TopoJSON</span><span class="value">world-atlas package</span></div>
            <div class="card-row"><span class="label">All APIs</span><span class="value">Free, no-key public endpoints</span></div>
            <div class="card-row"><span class="label">License</span><span class="value">MIT</span></div>
          </div>
        </div>
      `;
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.about = view;
})(window);
