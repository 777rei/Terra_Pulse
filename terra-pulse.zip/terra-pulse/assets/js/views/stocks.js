/* TERRA PULSE — Stocks view (with live heatmap) */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const DEFAULT_SYMBOLS = ['AAPL', 'MSFT', 'GOOG', 'AMZN', 'TSLA', 'META', 'NVDA', 'NFLX', 'JPM', 'V', 'DIS', 'BAC', 'WMT', 'PG', 'KO', 'PEP', 'INTC', 'AMD', 'CSCO', 'ORCL', 'ADBE', 'CRM', 'XOM', 'CVX', 'PFE', 'MRK', 'T', 'VZ', 'UBER', 'PYPL'];

  const view = {
    id: 'stocks',
    initialized: false,
    timer: null,
    tickerTimer: null,
    symbols: [],
    history: {},

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.symbols = JSON.parse(localStorage.getItem('tp:stockSymbols') || JSON.stringify(DEFAULT_SYMBOLS));
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 60_000);
      this.tickerTimer = setInterval(() => this.animateHeatmap(), 2000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      if (this.tickerTimer) clearInterval(this.tickerTimer);
      this.timer = null;
      this.tickerTimer = null;
    },

    render() {
      const root = utils.id('view-stocks');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Stock Market</h1>
            <p class="view-sub">Major US equities with live heatmap visualization. Add your own symbols.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Yahoo · Stooq</span>
            <span class="chip" id="stocksUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('activity', 18)} Live Stock Ticker</h2></div>
          <div class="ticker-wrap">
            <div class="ticker" id="stockTicker"></div>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('plus', 18)} Manage Symbols</h2></div>
          <div class="flex gap-12" style="flex-wrap:wrap">
            <input type="text" id="stockAdd" class="input" style="width:140px" placeholder="AAPL" />
            <button class="btn btn-primary" id="stockAddBtn">${icons.makeIcon('plus', 16)} Add</button>
            <button class="btn btn-ghost" id="stockReset">Reset to defaults</button>
            <div class="chip" id="stockSymbolsCount">0 symbols</div>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="tile-head"><h2>${icons.makeIcon('grid', 18)} Live Heatmap (day change)</h2></div>
          <div id="stockHeatmap" class="heatmap-grid"></div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('list', 18)} Live Quotes</h2></div>
          <div id="stocksTable" class="table-wrap"></div>
        </div>
      `;

      utils.id('stockAddBtn').addEventListener('click', () => this.addSymbol());
      utils.id('stockAdd').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.addSymbol(); });
      utils.id('stockReset').addEventListener('click', () => {
        this.symbols = [...DEFAULT_SYMBOLS];
        localStorage.setItem('tp:stockSymbols', JSON.stringify(this.symbols));
        this.refresh();
      });
    },

    addSymbol() {
      const v = utils.id('stockAdd').value.trim().toUpperCase();
      if (!v) return;
      if (this.symbols.includes(v)) {
        global.TP.app.toast('Already in list', 'warn');
        return;
      }
      this.symbols.push(v);
      localStorage.setItem('tp:stockSymbols', JSON.stringify(this.symbols));
      utils.id('stockAdd').value = '';
      this.refresh();
    },

    removeSymbol(sym) {
      this.symbols = this.symbols.filter((s) => s !== sym);
      localStorage.setItem('tp:stockSymbols', JSON.stringify(this.symbols));
      this.refresh();
    },

    async refresh() {
      const el = utils.id('stocksTable');
      const cntEl = utils.id('stockSymbolsCount');
      if (cntEl) cntEl.textContent = this.symbols.length + ' symbols';
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(5);
      try {
        const data = await api.stocks.quote(this.symbols);
        const results = data?.quoteResponse?.result || data?.result || [];
        if (!results.length) {
          el.innerHTML = '<div class="text-dim text-sm">No data. Yahoo Finance may be blocked; using fallback.</div>';
          return;
        }

        // Store for animation
        this.quotes = results;

        // Compute changes (vs previous snapshot)
        for (const q of results) {
          const sym = q.symbol;
          const change = (q.regularMarketChange != null) ? q.regularMarketChange : ((q.close || 0) - (q.open || 0));
          const changePct = (q.regularMarketChangePercent != null) ? q.regularMarketChangePercent : (q.open ? ((q.close - q.open) / q.open * 100) : 0);
          this.history[sym] = { change, changePct, price: q.regularMarketPrice || q.close || q.price };
        }

        this.renderHeatmap();
        this.renderTicker();

        el.innerHTML = `
          <table class="data">
            <thead><tr><th>Symbol</th><th>Name</th><th>Price</th><th>Change</th><th>Change %</th><th>Day High</th><th>Day Low</th><th>Volume</th><th>Market Cap</th><th></th></tr></thead>
            <tbody>
              ${results.map((q) => {
                const change = (q.regularMarketChange != null) ? q.regularMarketChange : ((q.close || 0) - (q.open || 0));
                const changePct = (q.regularMarketChangePercent != null) ? q.regularMarketChangePercent : (q.open ? ((q.close - q.open) / q.open * 100) : 0);
                return `<tr>
                  <td style="font-weight:700">${utils.escapeHtml(q.symbol)}</td>
                  <td>${utils.escapeHtml(q.shortName || q.longName || q.symbol)}</td>
                  <td class="num" style="font-weight:600">$${utils.fmt.decimals(q.regularMarketPrice || q.close || q.price, 2)}</td>
                  <td class="num ${utils.color.changeColor(change)}">${change >= 0 ? '+' : ''}${utils.fmt.decimals(change, 2)}</td>
                  <td class="num ${utils.color.changeColor(changePct)}">${utils.fmt.percent(changePct)}</td>
                  <td class="num">$${utils.fmt.decimals(q.regularMarketDayHigh || q.high, 2)}</td>
                  <td class="num">$${utils.fmt.decimals(q.regularMarketDayLow || q.low, 2)}</td>
                  <td class="num">${q.regularMarketVolume ? utils.fmt.compact(q.regularMarketVolume) : '—'}</td>
                  <td class="num">${q.marketCap ? '$' + utils.fmt.compact(q.marketCap) : '—'}</td>
                  <td><button class="link-btn" data-rm="${utils.escapeHtml(q.symbol)}">${icons.makeIcon('close', 14)}</button></td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        `;
        el.querySelectorAll('[data-rm]').forEach((b) => {
          b.addEventListener('click', () => this.removeSymbol(b.dataset.rm));
        });
        utils.id('stocksUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        el.innerHTML = '<div class="text-dim">Stock data unavailable. Yahoo Finance may require CORS proxy.</div>';
      }
    },

    renderHeatmap() {
      const el = utils.id('stockHeatmap');
      if (!el || !this.quotes) return;
      el.innerHTML = this.quotes.map((q) => {
        const changePct = (q.regularMarketChangePercent != null) ? q.regularMarketChangePercent : (q.open ? ((q.close - q.open) / q.open * 100) : 0);
        const color = utils.color.heatColor(changePct);
        const opacity = Math.max(0.4, utils.color.heatOpacity(changePct));
        const price = q.regularMarketPrice || q.close || q.price;
        return `
          <div class="heatmap-cell" style="background:${color}; opacity:${opacity}" data-sym="${utils.escapeHtml(q.symbol)}">
            <div class="hm-symbol">${utils.escapeHtml(q.symbol)}</div>
            <div class="hm-price">$${utils.fmt.decimals(price, 2)}</div>
            <div class="hm-change">${utils.fmt.percent(changePct)}</div>
          </div>
        `;
      }).join('');
    },

    renderTicker() {
      const el = utils.id('stockTicker');
      if (!el || !this.quotes) return;
      const items = this.quotes.slice(0, 20).map((q) => {
        const changePct = (q.regularMarketChangePercent != null) ? q.regularMarketChangePercent : (q.open ? ((q.close - q.open) / q.open * 100) : 0);
        const price = q.regularMarketPrice || q.close || q.price;
        return `<span class="ticker-item">
          <span class="t-sym">${utils.escapeHtml(q.symbol)}</span>
          <span class="t-price">$${utils.fmt.decimals(price, 2)}</span>
          <span class="t-chg ${utils.color.changeColor(changePct)}">${utils.fmt.percent(changePct)}</span>
        </span>`;
      }).join('');
      el.innerHTML = items + items;
    },

    // Visual animation: subtle opacity flicker to show "live" movement
    animateHeatmap() {
      const cells = utils.qsa('#stockHeatmap .heatmap-cell');
      cells.forEach((cell) => {
        const cur = parseFloat(cell.querySelector('.hm-change')?.textContent);
        if (isNaN(cur)) return;
        const flicker = (Math.random() - 0.5) * 0.1;
        cell.style.opacity = Math.max(0.4, utils.color.heatOpacity(cur) + flicker);
      });
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.stocks = view;
})(window);
