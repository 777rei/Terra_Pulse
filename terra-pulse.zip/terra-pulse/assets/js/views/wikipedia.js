/* TERRA PULSE — Wikipedia Pulse view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'wikipedia',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-wikipedia');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Wikipedia Pulse</h1>
            <p class="view-sub">Live recent edits on Wikipedia and "On this day" historical events.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Wikimedia</span>
            <span class="chip" id="wikiUpdated">—</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('edit', 18)} Recent Edits</h2></div>
            <div id="wikiRecent"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('calendar', 18)} On This Day</h2></div>
            <div id="wikiOTD"></div>
          </div>
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('search', 18)} Search Wikipedia</h2></div>
            <div class="flex gap-12 mb-12">
              <input type="search" id="wikiSearch" class="input" placeholder="Search Wikipedia…" />
              <button class="btn btn-primary" id="wikiSearchBtn">Search</button>
            </div>
            <div id="wikiResults"></div>
          </div>
        </div>
      `;

      utils.id('wikiSearchBtn').addEventListener('click', () => this.search());
      utils.id('wikiSearch').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.search(); });
    },

    async refresh() {
      await Promise.allSettled([this.refreshRecent(), this.refreshOTD()]);
      const el = utils.id('wikiUpdated');
      if (el) el.textContent = 'Updated ' + utils.fmt.time(new Date());
    },

    async refreshRecent() {
      const el = utils.id('wikiRecent');
      if (!el) return;
      el.innerHTML = '<div class="skeleton"></div>'.repeat(5);
      try {
        const d = await api.wikipedia.recentChanges();
        const changes = d?.query?.recentchanges || [];
        if (!changes.length) {
          el.innerHTML = '<div class="text-dim text-sm">No recent changes</div>';
          return;
        }
        el.innerHTML = changes.slice(0, 15).map((c) => `
          <div style="padding:8px 0; border-bottom:1px solid var(--glass-border-2)">
            <a href="https://en.wikipedia.org/wiki/${encodeURIComponent(c.title)}" target="_blank" rel="noopener" class="text-sm">${utils.escapeHtml(c.title)}</a>
            <div class="text-xs text-dim">by ${utils.escapeHtml(c.user)} · ${utils.fmt.relative(c.timestamp)} · ${c.sizediff > 0 ? '+' : ''}${c.sizediff || 0} bytes</div>
          </div>
        `).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Wikipedia unavailable</div>';
      }
    },

    async refreshOTD() {
      const el = utils.id('wikiOTD');
      if (!el) return;
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(3);
      try {
        const d = await api.wikipedia.news();
        const events = d?.events || [];
        if (!events.length) {
          el.innerHTML = '<div class="text-dim text-sm">No historical events found</div>';
          return;
        }
        el.innerHTML = events.slice(0, 12).map((e) => `
          <div class="card" style="margin-bottom:8px">
            <div class="flex gap-12">
              <span class="pill pill-info" style="flex:0 0 auto; min-width:60px; text-align:center">${e.year || '—'}</span>
              <div style="flex:1">
                <div class="text-sm">${utils.escapeHtml(e.text || e.title || '')}</div>
                ${e.pages?.length ? `<a href="${utils.escapeHtml(e.pages[0].content_urls?.desktop?.page || '#')}" target="_blank" rel="noopener" class="link text-xs">Read more →</a>` : ''}
              </div>
            </div>
          </div>
        `).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">On-this-day feed unavailable</div>';
      }
    },

    async search() {
      const q = utils.id('wikiSearch').value.trim();
      if (!q) return;
      const el = utils.id('wikiResults');
      el.innerHTML = '<span class="spinner"></span> Searching…';
      try {
        const d = await api.wikipedia.search(q);
        const results = d?.query?.search || [];
        if (!results.length) {
          el.innerHTML = '<div class="text-dim text-sm">No results</div>';
          return;
        }
        el.innerHTML = results.map((r) => `
          <div class="card" style="margin-bottom:8px; cursor:pointer" data-title="${utils.escapeHtml(r.title)}">
            <div class="card-title">${utils.escapeHtml(r.title)}</div>
            <div class="text-xs text-dim" style="margin-top:4px; line-height:1.5">${utils.escapeHtml(utils.truncate(r.snippet.replace(/<[^>]+>/g, ''), 160))}</div>
          </div>
        `).join('');
        el.querySelectorAll('.card').forEach((c) => {
          c.addEventListener('click', async () => {
            const s = await api.wikipedia.summary(c.dataset.title);
            if (s) {
              global.TP.app.toast('Opening ' + c.dataset.title + '…', 'info');
              window.open(s.content_urls?.desktop?.page, '_blank');
            }
          });
        });
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Search failed</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.wikipedia = view;
})(window);
