/* TERRA PULSE — Calculators view (financial + crypto + forex tools) */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'calculators',
    initialized: false,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
    },

    destroy() {},

    render() {
      const root = utils.id('view-calculators');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Financial Calculators</h1>
            <p class="view-sub">Compound interest, mortgage, ROI, crypto profit, and more.</p>
          </div>
          <div class="view-meta">
            <span class="chip">${icons.makeIcon('calculator', 14)} Live rates</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('growth', 18)} Compound Interest</h2></div>
            <div class="field"><label>Principal ($)</label><input type="number" id="cmpP" class="input" value="10000"></div>
            <div class="field"><label>Annual rate (%)</label><input type="number" id="cmpR" class="input" value="7" step="0.1"></div>
            <div class="field"><label>Years</label><input type="number" id="cmpY" class="input" value="10"></div>
            <div class="field"><label>Compounds/year</label><input type="number" id="cmpN" class="input" value="12"></div>
            <button class="btn btn-primary" id="cmpCalc">${icons.makeIcon('calculator', 16)} Calculate</button>
            <div id="cmpResult" style="margin-top:12px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('home', 18)} Mortgage Calculator</h2></div>
            <div class="field"><label>Loan amount ($)</label><input type="number" id="mortP" class="input" value="300000"></div>
            <div class="field"><label>Down payment ($)</label><input type="number" id="mortD" class="input" value="60000"></div>
            <div class="field"><label>Interest rate (%)</label><input type="number" id="mortR" class="input" value="6.5" step="0.1"></div>
            <div class="field"><label>Term (years)</label><input type="number" id="mortY" class="input" value="30"></div>
            <button class="btn btn-primary" id="mortCalc">${icons.makeIcon('calculator', 16)} Calculate</button>
            <div id="mortResult" style="margin-top:12px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('bitcoin', 18)} Crypto Profit</h2></div>
            <div class="field"><label>Buy price ($)</label><input type="number" id="cryB" class="input" value="40000" step="0.01"></div>
            <div class="field"><label>Sell price ($)</label><input type="number" id="cryS" class="input" value="65000" step="0.01"></div>
            <div class="field"><label>Amount (units)</label><input type="number" id="cryA" class="input" value="0.5" step="0.0001"></div>
            <div class="field"><label>Fee (%)</label><input type="number" id="cryF" class="input" value="0.5" step="0.01"></div>
            <button class="btn btn-primary" id="cryCalc">${icons.makeIcon('calculator', 16)} Calculate</button>
            <div id="cryResult" style="margin-top:12px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('percent', 18)} ROI Calculator</h2></div>
            <div class="field"><label>Initial investment ($)</label><input type="number" id="roiI" class="input" value="5000"></div>
            <div class="field"><label>Final value ($)</label><input type="number" id="roiF" class="input" value="7500"></div>
            <div class="field"><label>Years held</label><input type="number" id="roiY" class="input" value="3" step="0.1"></div>
            <button class="btn btn-primary" id="roiCalc">${icons.makeIcon('calculator', 16)} Calculate</button>
            <div id="roiResult" style="margin-top:12px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('savings', 18)} Savings Goal</h2></div>
            <div class="field"><label>Target amount ($)</label><input type="number" id="savT" class="input" value="100000"></div>
            <div class="field"><label>Monthly contribution ($)</label><input type="number" id="savM" class="input" value="500"></div>
            <div class="field"><label>Annual rate (%)</label><input type="number" id="savR" class="input" value="4" step="0.1"></div>
            <button class="btn btn-primary" id="savCalc">${icons.makeIcon('calculator', 16)} Calculate</button>
            <div id="savResult" style="margin-top:12px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('exchange', 18)} Currency Convert</h2></div>
            <div class="field"><label>Amount</label><input type="number" id="curA" class="input" value="100"></div>
            <div class="field"><label>From</label><input type="text" id="curF" class="input" value="USD" maxlength="3"></div>
            <div class="field"><label>To</label><input type="text" id="curT" class="input" value="EUR" maxlength="3"></div>
            <button class="btn btn-primary" id="curCalc">${icons.makeIcon('calculator', 16)} Convert</button>
            <div id="curResult" style="margin-top:12px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('flame2', 18)} Inflation Impact</h2></div>
            <div class="field"><label>Present value ($)</label><input type="number" id="infP" class="input" value="1000"></div>
            <div class="field"><label>Inflation rate (%)</label><input type="number" id="infR" class="input" value="3" step="0.1"></div>
            <div class="field"><label>Years</label><input type="number" id="infY" class="input" value="10"></div>
            <button class="btn btn-primary" id="infCalc">${icons.makeIcon('calculator', 16)} Calculate</button>
            <div id="infResult" style="margin-top:12px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('percent2', 18)} Tip Splitter</h2></div>
            <div class="field"><label>Bill ($)</label><input type="number" id="tipB" class="input" value="50" step="0.01"></div>
            <div class="field"><label>Tip (%)</label><input type="number" id="tipP" class="input" value="18" step="0.5"></div>
            <div class="field"><label>Number of people</label><input type="number" id="tipN" class="input" value="2"></div>
            <button class="btn btn-primary" id="tipCalc">${icons.makeIcon('calculator', 16)} Calculate</button>
            <div id="tipResult" style="margin-top:12px"></div>
          </div>
        </div>
      `;

      utils.id('cmpCalc').addEventListener('click', () => this.compound());
      utils.id('mortCalc').addEventListener('click', () => this.mortgage());
      utils.id('cryCalc').addEventListener('click', () => this.cryptoProfit());
      utils.id('roiCalc').addEventListener('click', () => this.roi());
      utils.id('savCalc').addEventListener('click', () => this.savings());
      utils.id('curCalc').addEventListener('click', () => this.currency());
      utils.id('infCalc').addEventListener('click', () => this.inflation());
      utils.id('tipCalc').addEventListener('click', () => this.tip());

      // Auto-calc on load for visual feedback
      setTimeout(() => { this.compound(); this.mortgage(); this.cryptoProfit(); this.roi(); this.savings(); this.inflation(); this.tip(); }, 300);
    },

    compound() {
      const P = parseFloat(utils.id('cmpP').value) || 0;
      const r = (parseFloat(utils.id('cmpR').value) || 0) / 100;
      const t = parseFloat(utils.id('cmpY').value) || 0;
      const n = parseFloat(utils.id('cmpN').value) || 1;
      const amount = P * Math.pow(1 + r / n, n * t);
      const interest = amount - P;
      utils.id('cmpResult').innerHTML = `
        <div class="card-row"><span class="label">Final amount</span><span class="value" style="color:var(--good); font-weight:700">$${utils.fmt.decimals(amount, 2)}</span></div>
        <div class="card-row"><span class="label">Interest earned</span><span class="value" style="color:var(--accent)">+$${utils.fmt.decimals(interest, 2)}</span></div>
        <div class="card-row"><span class="label">Growth</span><span class="value">${(interest / P * 100).toFixed(1)}%</span></div>
      `;
    },

    mortgage() {
      const P = (parseFloat(utils.id('mortP').value) || 0) - (parseFloat(utils.id('mortD').value) || 0);
      const r = (parseFloat(utils.id('mortR').value) || 0) / 100 / 12;
      const n = (parseFloat(utils.id('mortY').value) || 0) * 12;
      if (r === 0) {
        const monthly = P / n;
        utils.id('mortResult').innerHTML = `<div class="card-row"><span class="label">Monthly payment</span><span class="value" style="color:var(--accent); font-weight:700">$${utils.fmt.decimals(monthly, 2)}</span></div>`;
        return;
      }
      const monthly = P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
      const total = monthly * n;
      const interest = total - P;
      utils.id('mortResult').innerHTML = `
        <div class="card-row"><span class="label">Loan principal</span><span class="value">$${utils.fmt.decimals(P, 2)}</span></div>
        <div class="card-row"><span class="label">Monthly payment</span><span class="value" style="color:var(--accent); font-weight:700">$${utils.fmt.decimals(monthly, 2)}</span></div>
        <div class="card-row"><span class="label">Total paid</span><span class="value">$${utils.fmt.decimals(total, 2)}</span></div>
        <div class="card-row"><span class="label">Total interest</span><span class="value" style="color:var(--bad)">$${utils.fmt.decimals(interest, 2)}</span></div>
      `;
    },

    cryptoProfit() {
      const buy = parseFloat(utils.id('cryB').value) || 0;
      const sell = parseFloat(utils.id('cryS').value) || 0;
      const amt = parseFloat(utils.id('cryA').value) || 0;
      const fee = (parseFloat(utils.id('cryF').value) || 0) / 100;
      const cost = buy * amt * (1 + fee);
      const proceeds = sell * amt * (1 - fee);
      const profit = proceeds - cost;
      const roi = (profit / cost) * 100;
      utils.id('cryResult').innerHTML = `
        <div class="card-row"><span class="label">Cost basis</span><span class="value">$${utils.fmt.decimals(cost, 2)}</span></div>
        <div class="card-row"><span class="label">Proceeds</span><span class="value">$${utils.fmt.decimals(proceeds, 2)}</span></div>
        <div class="card-row"><span class="label">Profit / Loss</span><span class="value" style="color:${profit >= 0 ? 'var(--good)' : 'var(--bad)'}; font-weight:700">${profit >= 0 ? '+' : ''}$${utils.fmt.decimals(profit, 2)}</span></div>
        <div class="card-row"><span class="label">ROI</span><span class="value ${utils.color.changeColor(roi)}">${utils.fmt.percent(roi)}</span></div>
      `;
    },

    roi() {
      const initial = parseFloat(utils.id('roiI').value) || 0;
      const final = parseFloat(utils.id('roiF').value) || 0;
      const years = parseFloat(utils.id('roiY').value) || 1;
      const totalROI = (final - initial) / initial * 100;
      const annualROI = (Math.pow(final / initial, 1 / years) - 1) * 100;
      const profit = final - initial;
      utils.id('roiResult').innerHTML = `
        <div class="card-row"><span class="label">Total profit</span><span class="value" style="color:${profit >= 0 ? 'var(--good)' : 'var(--bad)'}">${profit >= 0 ? '+' : ''}$${utils.fmt.decimals(profit, 2)}</span></div>
        <div class="card-row"><span class="label">Total ROI</span><span class="value ${utils.color.changeColor(totalROI)}">${utils.fmt.percent(totalROI)}</span></div>
        <div class="card-row"><span class="label">Annualized ROI</span><span class="value ${utils.color.changeColor(annualROI)}">${utils.fmt.percent(annualROI)}</span></div>
      `;
    },

    savings() {
      const target = parseFloat(utils.id('savT').value) || 0;
      const monthly = parseFloat(utils.id('savM').value) || 0;
      const r = (parseFloat(utils.id('savR').value) || 0) / 100 / 12;
      // FV = PMT * ((1+r)^n - 1) / r = target → solve for n
      let months;
      if (r === 0) months = target / monthly;
      else months = Math.log(1 + target * r / monthly) / Math.log(1 + r);
      const years = months / 12;
      const totalContrib = monthly * months;
      const interest = target - totalContrib;
      utils.id('savResult').innerHTML = `
        <div class="card-row"><span class="label">Time to goal</span><span class="value" style="color:var(--accent); font-weight:700">${Math.floor(years)}y ${Math.floor((years % 1) * 12)}m</span></div>
        <div class="card-row"><span class="label">Total contributions</span><span class="value">$${utils.fmt.decimals(totalContrib, 2)}</span></div>
        <div class="card-row"><span class="label">Interest earned</span><span class="value" style="color:var(--good)">$${utils.fmt.decimals(interest, 2)}</span></div>
      `;
    },

    async currency() {
      const amt = parseFloat(utils.id('curA').value) || 0;
      const from = (utils.id('curF').value || 'USD').toUpperCase();
      const to = (utils.id('curT').value || 'EUR').toUpperCase();
      const el = utils.id('curResult');
      el.innerHTML = '<span class="spinner"></span> Converting…';
      try {
        const data = await api.forex.latest(from);
        const rate = data?.rates?.[to];
        if (!rate) {
          el.innerHTML = `<div class="text-dim text-sm">No rate for ${from}/${to}</div>`;
          return;
        }
        const result = amt * rate;
        el.innerHTML = `
          <div class="card-row"><span class="label">Rate</span><span class="value">1 ${from} = ${rate.toFixed(4)} ${to}</span></div>
          <div class="card-row"><span class="label">${amt} ${from}</span><span class="value" style="color:var(--accent); font-weight:700">${result.toFixed(2)} ${to}</span></div>
          <div class="card-row"><span class="label">Inverse</span><span class="value">1 ${to} = ${(1 / rate).toFixed(4)} ${from}</span></div>
        `;
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Conversion failed</div>';
      }
    },

    inflation() {
      const P = parseFloat(utils.id('infP').value) || 0;
      const r = (parseFloat(utils.id('infR').value) || 0) / 100;
      const y = parseFloat(utils.id('infY').value) || 0;
      const future = P * Math.pow(1 + r, y);
      const realValue = P / Math.pow(1 + r, y);
      const lost = P - realValue;
      utils.id('infResult').innerHTML = `
        <div class="card-row"><span class="label">Future cost (same goods)</span><span class="value" style="color:var(--bad)">$${utils.fmt.decimals(future, 2)}</span></div>
        <div class="card-row"><span class="label">Real value of $${P} in ${y}y</span><span class="value" style="color:var(--good)">$${utils.fmt.decimals(realValue, 2)}</span></div>
        <div class="card-row"><span class="label">Purchasing power lost</span><span class="value" style="color:var(--bad)">$${utils.fmt.decimals(lost, 2)} (${(lost / P * 100).toFixed(1)}%)</span></div>
      `;
    },

    tip() {
      const bill = parseFloat(utils.id('tipB').value) || 0;
      const tipP = parseFloat(utils.id('tipP').value) || 0;
      const n = parseFloat(utils.id('tipN').value) || 1;
      const tip = bill * tipP / 100;
      const total = bill + tip;
      const perPerson = total / n;
      utils.id('tipResult').innerHTML = `
        <div class="card-row"><span class="label">Tip amount</span><span class="value">$${utils.fmt.decimals(tip, 2)}</span></div>
        <div class="card-row"><span class="label">Total</span><span class="value" style="color:var(--accent); font-weight:700">$${utils.fmt.decimals(total, 2)}</span></div>
        <div class="card-row"><span class="label">Per person</span><span class="value">$${utils.fmt.decimals(perPerson, 2)}</span></div>
      `;
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.calculators = view;
})(window);
