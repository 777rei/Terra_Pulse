/* TERRA PULSE — World Clocks view */
(function (global) {
  'use strict';
  const { utils, icons } = global.TP;

  const TIMEZONES = [
    { city: 'Los Angeles', tz: 'America/Los_Angeles', country: 'USA' },
    { city: 'Mexico City', tz: 'America/Mexico_City', country: 'Mexico' },
    { city: 'New York', tz: 'America/New_York', country: 'USA' },
    { city: 'São Paulo', tz: 'America/Sao_Paulo', country: 'Brazil' },
    { city: 'London', tz: 'Europe/London', country: 'UK' },
    { city: 'Paris', tz: 'Europe/Paris', country: 'France' },
    { city: 'Berlin', tz: 'Europe/Berlin', country: 'Germany' },
    { city: 'Moscow', tz: 'Europe/Moscow', country: 'Russia' },
    { city: 'Dubai', tz: 'Asia/Dubai', country: 'UAE' },
    { city: 'Mumbai', tz: 'Asia/Kolkata', country: 'India' },
    { city: 'Bangkok', tz: 'Asia/Bangkok', country: 'Thailand' },
    { city: 'Singapore', tz: 'Asia/Singapore', country: 'Singapore' },
    { city: 'Beijing', tz: 'Asia/Shanghai', country: 'China' },
    { city: 'Tokyo', tz: 'Asia/Tokyo', country: 'Japan' },
    { city: 'Sydney', tz: 'Australia/Sydney', country: 'Australia' },
    { city: 'Auckland', tz: 'Pacific/Auckland', country: 'New Zealand' }
  ];

  const view = {
    id: 'clocks',
    initialized: false,
    timer: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.tick();
      this.timer = setInterval(() => this.tick(), 1000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-clocks');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">World Clocks</h1>
            <p class="view-sub">Real-time clocks across major world cities. Updates every second.</p>
          </div>
          <div class="view-meta">
            <span class="chip" id="utcChip">UTC —</span>
            <span class="chip"><span class="dot dot-live"></span>Live</span>
          </div>
        </div>

        <div class="card-grid" id="clockGrid"></div>

        <div class="tile-grid mt-16">
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('sunrise', 18)} Sun & Moon</h2></div>
            <div id="sunMoon"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('calendar', 18)} Today</h2></div>
            <div id="todayInfo"></div>
          </div>
          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('clock', 18)} Unix Time</h2></div>
            <div id="unixTime"></div>
          </div>
        </div>
      `;

      const grid = utils.id('clockGrid');
      grid.innerHTML = TIMEZONES.map((t, i) => `
        <div class="card" data-tz="${t.tz}" data-i="${i}">
          <div class="flex between center">
            <div>
              <div class="card-title">${utils.escapeHtml(t.city)}</div>
              <div class="text-xs text-dim">${utils.escapeHtml(t.country)} · ${utils.escapeHtml(t.tz)}</div>
            </div>
            <div class="icon-host" data-day-icon></div>
          </div>
          <div class="text-mono" style="font-size:28px; font-weight:700; margin-top:8px" data-time>--:--:--</div>
          <div class="flex between text-xs text-dim" style="margin-top:6px">
            <span data-date>—</span>
            <span data-offset>—</span>
          </div>
        </div>
      `).join('');

      const today = new Date();
      const todayInfo = utils.id('todayInfo');
      if (todayInfo) {
        todayInfo.innerHTML = `
          <div class="card-row"><span class="label">Date</span><span class="value">${utils.fmt.date(today)}</span></div>
          <div class="card-row"><span class="label">Day</span><span class="value">${today.toLocaleDateString('en-US', { weekday: 'long' })}</span></div>
          <div class="card-row"><span class="label">Week</span><span class="value">Week ${this.getWeek(today)}</span></div>
          <div class="card-row"><span class="label">Day of year</span><span class="value">${this.dayOfYear(today)} / 365</span></div>
          <div class="card-row"><span class="label">Days left</span><span class="value">${365 - this.dayOfYear(today)}</span></div>
        `;
      }
    },

    getWeek(d) {
      const onejan = new Date(d.getFullYear(), 0, 1);
      return Math.ceil((((d - onejan) / 86400000) + onejan.getDay() + 1) / 7);
    },

    dayOfYear(d) {
      const start = new Date(d.getFullYear(), 0, 0);
      const diff = d - start;
      return Math.floor(diff / 86400000);
    },

    isDaytime(hour) { return hour >= 6 && hour < 19; },

    tick() {
      const now = new Date();
      const utcChip = utils.id('utcChip');
      if (utcChip) {
        const utcTime = now.toLocaleTimeString('en-US', { timeZone: 'UTC', hour12: false });
        utcChip.textContent = 'UTC ' + utcTime;
      }

      const unixEl = utils.id('unixTime');
      if (unixEl) {
        unixEl.innerHTML = `
          <div class="text-mono" style="font-size:24px; font-weight:700">${Math.floor(now.getTime() / 1000)}</div>
          <div class="text-xs text-dim" style="margin-top:6px">Seconds since Jan 1, 1970</div>
        `;
      }

      const smEl = utils.id('sunMoon');
      if (smEl) {
        const hour = now.getHours() + now.getMinutes() / 60;
        const isDay = this.isDaytime(hour);
        const dayProgress = (hour / 24 * 100).toFixed(1);
        smEl.innerHTML = `
          <div class="flex between center" style="margin-bottom:8px">
            <div class="icon-host" style="color:${isDay ? '#ffcf5e' : '#b07bff'}">${icons.makeIcon(isDay ? 'sun' : 'moon', 36)}</div>
            <div class="text-right">
              <div class="text-sm" style="font-weight:600">${isDay ? 'Daytime' : 'Nighttime'}</div>
              <div class="text-xs text-dim">UTC ${now.getUTCHours()}:${String(now.getUTCMinutes()).padStart(2,'0')}</div>
            </div>
          </div>
          <div class="card-row"><span class="label">Day progress</span><span class="value">${dayProgress}%</span></div>
          <div class="card-row"><span class="label">UTC offset</span><span class="value">${-now.getTimezoneOffset() / 60 >= 0 ? '+' : ''}${-now.getTimezoneOffset() / 60}h</span></div>
        `;
      }

      const cards = utils.qsa('#clockGrid .card');
      cards.forEach((card) => {
        const tz = card.dataset.tz;
        try {
          const timeStr = now.toLocaleTimeString('en-US', { timeZone: tz, hour12: false });
          const dateStr = now.toLocaleDateString('en-US', { timeZone: tz, weekday: 'short', month: 'short', day: 'numeric' });
          const localParts = now.toLocaleString('en-US', { timeZone: tz, hour12: false }).split(', ');
          const localDate = new Date(localParts[0] + ' ' + localParts[1]);
          const utc = new Date(now.toLocaleString('en-US', { timeZone: 'UTC', hour12: false }));
          const offset = Math.round((localDate - utc) / 3600000);

          const timeEl = card.querySelector('[data-time]');
          const dateEl = card.querySelector('[data-date]');
          const offsetEl = card.querySelector('[data-offset]');
          const iconEl = card.querySelector('[data-day-icon]');

          if (timeEl) timeEl.textContent = timeStr;
          if (dateEl) dateEl.textContent = dateStr;
          if (offsetEl) offsetEl.textContent = 'UTC' + (offset >= 0 ? '+' : '') + offset;

          const hourStr = timeStr.split(':')[0];
          const hour = parseInt(hourStr, 10);
          if (iconEl) {
            iconEl.innerHTML = icons.makeIcon(this.isDaytime(hour) ? 'sun' : 'moon', 20);
            iconEl.style.color = this.isDaytime(hour) ? '#ffcf5e' : '#b07bff';
          }
        } catch (e) {}
      });
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.clocks = view;
})(window);
