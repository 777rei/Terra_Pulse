/* TERRA PULSE — Overview view */
(function (global) {
  'use strict';
  const { utils, api, store, icons } = global.TP;

  const CITIES = [
    { name: 'London', lat: 51.5074, lng: -0.1278 },
    { name: 'New York', lat: 40.7128, lng: -74.0060 },
    { name: 'Tokyo', lat: 35.6762, lng: 139.6503 },
    { name: 'Sydney', lat: -33.8688, lng: 151.2093 },
    { name: 'Dubai', lat: 25.2048, lng: 55.2708 },
    { name: 'São Paulo', lat: -23.5505, lng: -46.6333 },
    { name: 'Cape Town', lat: -33.9249, lng: 18.4241 },
    { name: 'Mumbai', lat: 19.0760, lng: 72.8777 }
  ];

  const view = {
    id: 'overview',
    initialized: false,
    map: null,
    history: { population: [], temp: [], crypto: [], quakes: [], iss: [], internet: [] },
    timers: [],

    async init() {
      if (this.initialized) return;
      this.initialized = true;
      await this.render();
      this.refresh();
      this.timers.push(setInterval(() => this.refresh(), 30_000));
    },

    destroy() {
      this.timers.forEach((t) => clearInterval(t));
      this.timers = [];
    },

    async render() {
      const mapEl = utils.id('overviewMap');
      if (mapEl && !this.map) {
        this.map = new global.TP.WorldMap(mapEl, { showCityLabels: true });
      }
    },

    async refresh() {
      this.updateClockMini();
      await Promise.allSettled([
        this.refreshKpis(),
        this.refreshMap(),
        this.refreshNews(),
        this.refreshCrypto(),
        this.refreshQuakes(),
        this.refreshWeather(),
        this.refreshIss(),
        this.refreshForex()
      ]);
      const updEl = utils.id('overviewUpdated');
      if (updEl) updEl.textContent = 'Updated ' + utils.fmt.time(new Date());
      store.emit('overview:refreshed');
    },

    updateClockMini() {
      const el = utils.id('clockMini');
      if (el) el.textContent = new Date().toLocaleTimeString('en-US', { hour12: false });
    },

    async refreshKpis() {
      const pop = api.population.snapshot();
      const popEl = utils.id('kpiPopulation');
      if (popEl) {
        const prev = parseInt(popEl.dataset.value || '0', 10);
        utils.animateNumber(popEl, prev, pop.total, 800, (n) => utils.fmt.compact(n));
        popEl.dataset.value = pop.total;
      }
      const birthsEl = utils.id('kpiBirths');
      if (birthsEl) birthsEl.textContent = utils.fmt.compact(Math.floor(pop.birthsToday / 60 / 24));
      this.history.population.push(pop.total);
      if (this.history.population.length > 30) this.history.population.shift();
      this.updateSpark('sparkPopulation', this.history.population);

      const net = api.network.internetStats();
      const intEl = utils.id('kpiInternet');
      if (intEl) {
        const prev = parseInt(intEl.dataset.value || '0', 10);
        utils.animateNumber(intEl, prev, net.users, 800, (n) => utils.fmt.compact(n));
        intEl.dataset.value = net.users;
      }
      this.history.internet.push(net.users);
      if (this.history.internet.length > 30) this.history.internet.shift();
      this.updateSpark('sparkInternet', this.history.internet);

      try {
        const g = await api.crypto.global();
        const cap = g?.data?.total_market_cap?.usd;
        const change = g?.data?.market_cap_change_percentage_24h_usd;
        const capEl = utils.id('kpiCrypto');
        if (capEl && cap) capEl.textContent = '$' + utils.fmt.compact(cap);
        const chgEl = utils.id('kpiCryptoChange');
        if (chgEl && change != null) {
          chgEl.textContent = utils.fmt.percent(change);
          chgEl.className = 'kpi-meta ' + utils.color.changeColor(change);
        }
        this.history.crypto.push(cap || 0);
        if (this.history.crypto.length > 30) this.history.crypto.shift();
        this.updateSpark('sparkCrypto', this.history.crypto);
      } catch {}

      try {
        const q = await api.earthquakes.summary('day');
        const features = q?.features || [];
        let maxMag = 0;
        for (const f of features) {
          const m = f.properties?.mag || 0;
          if (m > maxMag) maxMag = m;
        }
        const qEl = utils.id('kpiQuakes');
        if (qEl) qEl.textContent = features.length;
        const maxEl = utils.id('kpiQuakesMax');
        if (maxEl) maxEl.textContent = 'max M' + maxMag.toFixed(1);
        this.history.quakes.push(features.length);
        if (this.history.quakes.length > 30) this.history.quakes.shift();
        this.updateSpark('sparkQuakes', this.history.quakes);
      } catch {}

      try {
        const iss = await api.space.iss();
        if (iss?.iss_position) {
          const altEl = utils.id('kpiIss');
          if (altEl) altEl.textContent = '408 km';
          const spdEl = utils.id('kpiIssSpeed');
          if (spdEl) spdEl.textContent = '27,600 km/h';
        }
      } catch {}

      try {
        const results = await api.weather.currentBatch(CITIES.slice(0, 5));
        const temps = results.map((r) => r.data?.current?.temperature_2m).filter((t) => t != null);
        if (temps.length) {
          const avg = temps.reduce((s, t) => s + t, 0) / temps.length;
          const tEl = utils.id('kpiTemp');
          if (tEl) tEl.textContent = avg.toFixed(1) + ' °C';
          this.history.temp.push(avg);
          if (this.history.temp.length > 30) this.history.temp.shift();
          this.updateSpark('sparkTemp', this.history.temp);
        }
      } catch {}
    },

    updateSpark(id, values) {
      const el = utils.id(id);
      if (!el) return;
      el.setAttribute('points', utils.sparkline(values));
    },

    async refreshMap() {
      if (!this.map) return;
      const events = [];

      try {
        const q = await api.earthquakes.summary('day');
        for (const f of (q?.features || []).slice(0, 30)) {
          const mag = f.properties?.mag || 0;
          const [lng, lat] = f.geometry?.coordinates || [];
          if (lat == null || lng == null) continue;
          let color = '#3ee68a';
          if (mag >= 5) color = '#ff5e7a';
          else if (mag >= 4) color = '#ffcf5e';
          else color = '#5ec3ff';
          events.push({
            lat, lng,
            color, size: Math.max(2, mag * 0.7),
            magnitude: mag.toFixed(1),
            title: f.properties?.place || 'Earthquake',
            text: 'Magnitude ' + mag.toFixed(1),
            time: f.properties?.time ? new Date(f.properties.time) : null
          });
        }
      } catch {}

      try {
        const iss = await api.space.iss();
        if (iss?.iss_position) {
          const lat = parseFloat(iss.iss_position.latitude);
          const lng = parseFloat(iss.iss_position.longitude);
          events.push({
            lat, lng,
            color: '#b07bff', size: 5,
            title: 'ISS',
            text: 'International Space Station',
            time: new Date(iss.timestamp * 1000)
          });
        }
      } catch {}

      this.map.setEvents(events);
      const cntEl = utils.id('mapEventsCount');
      if (cntEl) cntEl.textContent = events.length + ' events';
    },

    async refreshNews() {
      const el = utils.id('overviewNews');
      if (!el) return;
      try {
        const items = await api.news.world();
        if (!items || !items.length) {
          el.innerHTML = '<li class="empty-state text-dim text-sm">No news right now</li>';
          return;
        }
        el.innerHTML = items.slice(0, 5).map((it) => `
          <li>
            <span class="news-source">${utils.escapeHtml((it.author || 'News')).slice(0, 16)}</span>
            <a href="${utils.escapeHtml(it.link)}" target="_blank" rel="noopener noreferrer">${utils.escapeHtml(utils.truncate(it.title, 90))}</a>
          </li>
        `).join('');
      } catch {
        el.innerHTML = '<li class="text-dim text-sm">News unavailable</li>';
      }
    },

    async refreshCrypto() {
      const el = utils.id('overviewCrypto');
      if (!el) return;
      try {
        const markets = await api.crypto.markets(8);
        if (!markets || !markets.length) {
          el.innerHTML = '<li class="text-dim text-sm">Crypto unavailable</li>';
          return;
        }
        el.innerHTML = markets.slice(0, 6).map((c) => {
          const chg = c.price_change_percentage_24h || 0;
          return `
            <li>
              <span class="coin-info">${icons.coinIcon(c.symbol)}<span><span class="coin-sym">${utils.escapeHtml((c.symbol || '').toUpperCase())}</span><span class="coin-name">${utils.escapeHtml(c.name)}</span></span></span>
              <span class="coin-price">$${utils.fmt.decimals(c.current_price, c.current_price < 1 ? 6 : 2)}</span>
              <span class="coin-change ${utils.color.changeColor(chg)}">${utils.fmt.percent(chg)}</span>
            </li>
          `;
        }).join('');
      } catch {
        el.innerHTML = '<li class="text-dim text-sm">Crypto unavailable</li>';
      }
    },

    async refreshQuakes() {
      const el = utils.id('overviewQuakes');
      if (!el) return;
      try {
        const q = await api.earthquakes.summary('day');
        const features = (q?.features || []).slice(0, 6);
        if (!features.length) {
          el.innerHTML = '<li class="text-dim text-sm">No recent activity</li>';
          return;
        }
        el.innerHTML = features.map((f) => {
          const mag = f.properties?.mag || 0;
          const place = f.properties?.place || 'Unknown';
          const time = f.properties?.time ? new Date(f.properties.time) : null;
          return `
            <li>
              <span class="quake-mag ${utils.color.mag(mag)}">M${mag.toFixed(1)}</span>
              <span class="quake-place" title="${utils.escapeHtml(place)}">${utils.escapeHtml(place)}</span>
              <span class="quake-time">${time ? utils.fmt.relative(time) : ''}</span>
            </li>
          `;
        }).join('');
      } catch {
        el.innerHTML = '<li class="text-dim text-sm">Earthquake feed unavailable</li>';
      }
    },

    async refreshWeather() {
      const el = utils.id('overviewWeather');
      if (!el) return;
      try {
        const results = await api.weather.currentBatch(CITIES);
        el.innerHTML = results.map((r) => {
          if (!r.data) {
            return `<div class="weather-card"><div class="weather-city">${utils.escapeHtml(r.name)}</div><div class="icon-host">${icons.makeIcon('cloud', 28)}</div><div class="weather-temp">—</div><div class="weather-desc">N/A</div></div>`;
          }
          const c = r.data.current;
          const code = c.weather_code;
          return `
            <div class="weather-card">
              <div class="weather-city">${utils.escapeHtml(r.name)}</div>
              <div class="icon-host" style="margin:6px 0; color:${utils.color.temp(c.temperature_2m)}">${icons.makeIcon(icons.weatherIcon(code), 32)}</div>
              <div class="weather-temp" style="color:${utils.color.temp(c.temperature_2m)}">${Math.round(c.temperature_2m)}°</div>
              <div class="weather-desc">${utils.escapeHtml(global.TP.utils?.weatherDesc?.(code) || '')}</div>
              <div class="weather-extra">${icons.makeIcon('droplet', 12)} ${c.relative_humidity_2m}% · ${icons.makeIcon('wind', 12)} ${Math.round(c.wind_speed_10m)} km/h</div>
            </div>
          `;
        }).join('');
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">Weather unavailable</div>';
      }
    },

    async refreshIss() {
      const el = utils.id('overviewIss');
      if (!el) return;
      try {
        const [iss, people] = await Promise.allSettled([api.space.iss(), api.space.people()]);
        const issData = iss.status === 'fulfilled' ? iss.value : null;
        const peopleData = people.status === 'fulfilled' ? people.value : null;
        if (!issData) {
          el.innerHTML = '<div class="text-dim text-sm">ISS feed unavailable</div>';
          return;
        }
        const lat = parseFloat(issData.iss_position?.latitude || 0);
        const lng = parseFloat(issData.iss_position?.longitude || 0);
        el.innerHTML = `
          <div class="iss-row"><span class="iss-label">Latitude</span><span class="iss-value">${lat.toFixed(3)}°</span></div>
          <div class="iss-row"><span class="iss-label">Longitude</span><span class="iss-value">${lng.toFixed(3)}°</span></div>
          <div class="iss-row"><span class="iss-label">Altitude</span><span class="iss-value">~408 km</span></div>
          <div class="iss-row"><span class="iss-label">Speed</span><span class="iss-value">~27,600 km/h</span></div>
          <div class="iss-row"><span class="iss-label">People in space</span><span class="iss-value">${peopleData?.number ?? '—'}</span></div>
        `;
      } catch {
        el.innerHTML = '<div class="text-dim text-sm">ISS feed unavailable</div>';
      }
    },

    async refreshForex() {
      const el = utils.id('overviewForex');
      if (!el) return;
      try {
        const data = await api.forex.latest('USD');
        if (!data || !data.rates) {
          el.innerHTML = '<li class="text-dim text-sm">Forex unavailable</li>';
          return;
        }
        const pairs = ['EUR', 'GBP', 'JPY', 'CNY', 'INR', 'AUD'];
        el.innerHTML = pairs.map((cur) => {
          const rate = data.rates[cur];
          return `
            <li>
              <span class="coin-info"><span class="coin-sym">USD/${cur}</span></span>
              <span class="text-dim text-sm">1 USD</span>
              <span class="coin-price">${rate ? rate.toFixed(rate < 10 ? 4 : 2) : '—'}</span>
            </li>
          `;
        }).join('');
      } catch {
        el.innerHTML = '<li class="text-dim text-sm">Forex unavailable</li>';
      }
    }
  };

  // Helper - weather description (used in overview)
  utils.weatherDesc = function (code) {
    const m = {
      0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
      45: 'Fog', 48: 'Rime fog', 51: 'Light drizzle', 53: 'Moderate drizzle',
      55: 'Dense drizzle', 56: 'Freezing drizzle', 57: 'Freezing dense drizzle',
      61: 'Slight rain', 63: 'Moderate rain', 65: 'Heavy rain', 66: 'Freezing rain',
      67: 'Heavy freezing rain', 71: 'Slight snow', 73: 'Moderate snow', 75: 'Heavy snow',
      77: 'Snow grains', 80: 'Slight rain showers', 81: 'Moderate rain showers',
      82: 'Violent rain showers', 85: 'Slight snow showers', 86: 'Heavy snow showers',
      95: 'Thunderstorm', 96: 'Thunderstorm w/ hail', 99: 'Severe thunderstorm'
    };
    return m[code] || 'Unknown';
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.overview = view;
})(window);
