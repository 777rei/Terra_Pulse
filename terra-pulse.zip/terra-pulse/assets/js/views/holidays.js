/* TERRA PULSE — Holidays view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'holidays',
    initialized: false,
    timer: null,
    country: 'US',

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 60 * 60_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    async render() {
      const root = utils.id('view-holidays');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Public Holidays</h1>
            <p class="view-sub">Public holidays for ${new Date().getFullYear()} around the world.</p>
          </div>
          <div class="view-meta">
            <span class="chip">Nager.Date API</span>
            <span class="chip" id="holUpdated">—</span>
          </div>
        </div>

        <div class="tile mb-12">
          <div class="flex gap-12" style="flex-wrap:wrap; align-items:center">
            <label class="text-sm">Year:</label>
            <select id="holYear" class="select" style="width:auto">
              ${[new Date().getFullYear() - 1, new Date().getFullYear(), new Date().getFullYear() + 1].map((y) => `<option value="${y}">${y}</option>`).join('')}
            </select>
            <label class="text-sm">Country:</label>
            <select id="holCountry" class="select" style="width:240px">
              <option value="">Loading countries…</option>
            </select>
          </div>
        </div>

        <div class="tile">
          <div class="tile-head"><h2>${icons.makeIcon('calendar', 18)} Holidays</h2></div>
          <div id="holList"></div>
        </div>
      `;

      utils.id('holYear').value = new Date().getFullYear();
      utils.id('holYear').addEventListener('change', () => this.refresh());
      utils.id('holCountry').addEventListener('change', (e) => { this.country = e.target.value; this.refresh(); });

      try {
        const countries = await api.holidays.countries();
        const sel = utils.id('holCountry');
        sel.innerHTML = countries.map((c) => `<option value="${c.countryCode}">${utils.escapeHtml(c.name)}</option>`).join('');
        sel.value = this.country;
      } catch {}
    },

    async refresh() {
      const el = utils.id('holList');
      if (!el) return;
      const year = parseInt(utils.id('holYear')?.value || new Date().getFullYear(), 10);
      el.innerHTML = '<div class="skeleton s-lg"></div>'.repeat(5);
      try {
        const data = await api.holidays.year(year, this.country);
        if (!Array.isArray(data) || !data.length) {
          el.innerHTML = '<div class="text-dim">No holidays found</div>';
          return;
        }
        const today = new Date();
        el.innerHTML = data.map((h) => {
          const date = new Date(h.date);
          const isPast = date < today;
          const isToday = date.toDateString() === today.toDateString();
          return `
            <div class="card" style="margin-bottom:8px; padding:12px; ${isToday ? 'border-left:3px solid #5ee7ff' : ''}">
              <div class="flex between center">
                <div>
                  <div style="font-weight:600; font-size:14px">${utils.escapeHtml(h.name)}</div>
                  ${h.localName ? `<div class="text-sm text-dim">${utils.escapeHtml(h.localName)}</div>` : ''}
                  <div class="text-xs text-dim" style="margin-top:4px">${utils.fmt.date(date)} · ${date.toLocaleDateString('en-US', { weekday: 'long' })}</div>
                </div>
                <div>
                  ${isToday ? '<span class="pill pill-info">Today</span>' :
                    isPast ? '<span class="pill" style="background:rgba(174,184,216,.1); color:#aeb8d8">Past</span>' :
                    '<span class="pill pill-good">Upcoming</span>'}
                  ${h.global ? '<span class="pill pill-warn" style="margin-left:4px">National</span>' : ''}
                </div>
              </div>
              ${h.types?.length ? `<div class="text-xs text-dim" style="margin-top:6px">${h.types.map((t) => utils.escapeHtml(t)).join(' · ')}</div>` : ''}
            </div>
          `;
        }).join('');
        utils.id('holUpdated').textContent = 'Updated ' + utils.fmt.time(new Date());
      } catch {
        el.innerHTML = '<div class="text-dim">Failed to load holidays</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.holidays = view;
})(window);
