/* TERRA PULSE — Space & ISS view */
(function (global) {
  'use strict';
  const { utils, api, icons } = global.TP;

  const view = {
    id: 'space',
    initialized: false,
    timer: null,
    map: null,

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.render();
      this.refresh();
      this.timer = setInterval(() => this.refresh(), 10_000);
    },

    destroy() {
      if (this.timer) clearInterval(this.timer);
      this.timer = null;
    },

    render() {
      const root = utils.id('view-space');
      if (!root) return;
      root.innerHTML = `
        <div class="view-head">
          <div>
            <h1 class="view-title">Space & ISS</h1>
            <p class="view-sub">Real-time ISS tracking, people in space, and the astronomy picture of the day.</p>
          </div>
          <div class="view-meta">
            <span class="chip"><span class="dot dot-live"></span>Open Notify · NASA</span>
            <span class="chip" id="spaceUpdated">—</span>
          </div>
        </div>

        <div class="tile-grid">
          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('iss', 18)} ISS Live Position</h2><span class="chip" id="issPos">—</span></div>
            <div id="issMap" style="min-height:380px"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('gauge', 18)} ISS Telemetry</h2></div>
            <div id="issTelemetry"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('users', 18)} People in Space</h2><span class="chip" id="pisCount">—</span></div>
            <div id="peopleInSpace" style="max-height:280px; overflow-y:auto"></div>
          </div>

          <div class="tile tile-wide">
            <div class="tile-head"><h2>${icons.makeIcon('galaxy', 18)} Astronomy Picture of the Day</h2></div>
            <div id="apod"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('mars', 18)} Mars Weather</h2></div>
            <div id="mars"></div>
          </div>

          <div class="tile">
            <div class="tile-head"><h2>${icons.makeIcon('zap', 18)} Space Weather</h2></div>
            <div id="spaceWx"></div>
          </div>
        </div>
      `;

      this.map = new global.TP.WorldMap(utils.id('issMap'), { showCityLabels: true });
    },

    async refresh() {
      await Promise.allSettled([
        this.refreshIss(),
        this.refreshPeople(),
        this.refreshApod(),
        this.refreshMars(),
        this.refreshSpaceWx()
      ]);
      const el = utils.id('spaceUpdated');
      if (el) el.textContent = 'Updated ' + utils.fmt.time(new Date());
    },

    async refreshIss() {
      try {
        const iss = await api.space.iss();
        if (!iss?.iss_position) return;
        const lat = parseFloat(iss.iss_position.latitude);
        const lng = parseFloat(iss.iss_position.longitude);
        this.map.setEvents([{
          lat, lng,
          color: '#b07bff', size: 6,
          title: 'ISS',
          text: 'International Space Station',
          time: new Date(iss.timestamp * 1000)
        }]);
        utils.id('issPos').textContent = `${lat.toFixed(2)}°, ${lng.toFixed(2)}°`;
        utils.id('issTelemetry').innerHTML = `
          <div class="card-row"><span class="label">Latitude</span><span class="value">${lat.toFixed(4)}°</span></div>
          <div class="card-row"><span class="label">Longitude</span><span class="value">${lng.toFixed(4)}°</span></div>
          <div class="card-row"><span class="label">Altitude</span><span class="value">~408 km</span></div>
          <div class="card-row"><span class="label">Speed</span><span class="value">~27,600 km/h</span></div>
          <div class="card-row"><span class="label">Orbital period</span><span class="value">~92.7 min</span></div>
          <div class="card-row"><span class="label">Orbits/day</span><span class="value">~15.5</span></div>
          <div class="card-row"><span class="label">Last update</span><span class="value">${utils.fmt.time(new Date(iss.timestamp * 1000))}</span></div>
        `;
      } catch {}
    },

    async refreshPeople() {
      try {
        const d = await api.space.people();
        utils.id('pisCount').textContent = d?.number ? d.number + ' people' : '—';
        const people = d?.people || [];
        const groups = {};
        for (const p of people) {
          if (!groups[p.craft]) groups[p.craft] = [];
          groups[p.craft].push(p.name);
        }
        utils.id('peopleInSpace').innerHTML = Object.entries(groups).map(([craft, names]) => `
          <div style="margin-bottom:10px">
            <div class="text-xs text-up text-dim" style="margin-bottom:4px">${icons.makeIcon('rocket', 12)} ${utils.escapeHtml(craft)} (${names.length})</div>
            ${names.map((n) => `<div class="text-sm" style="padding:3px 0">· ${utils.escapeHtml(n)}</div>`).join('')}
          </div>
        `).join('');
      } catch {}
    },

    async refreshApod() {
      try {
        const d = await api.space.apod();
        if (!d) {
          utils.id('apod').innerHTML = '<div class="text-dim text-sm">APOD unavailable (rate-limited)</div>';
          return;
        }
        utils.id('apod').innerHTML = `
          <div class="flex gap-12" style="flex-wrap:wrap">
            ${d.media_type === 'video' ?
              `<iframe src="${utils.escapeHtml(d.url)}" style="width:100%; max-width:480px; aspect-ratio:16/9; border:none; border-radius:8px" allowfullscreen></iframe>` :
              `<img src="${utils.escapeHtml(d.url)}" alt="${utils.escapeHtml(d.title)}" style="width:100%; max-width:480px; border-radius:8px" loading="lazy" />`
            }
            <div style="flex:1; min-width:240px">
              <h3 style="margin:0 0 6px; font-size:16px">${utils.escapeHtml(d.title)}</h3>
              <div class="text-xs text-dim" style="margin-bottom:8px">${utils.escapeHtml(d.date)}</div>
              <div class="text-sm" style="line-height:1.6; max-height:200px; overflow-y:auto">${utils.escapeHtml(d.explanation || '')}</div>
              ${d.copyright ? `<div class="text-xs text-dim" style="margin-top:8px">© ${utils.escapeHtml(d.copyright)}</div>` : ''}
            </div>
          </div>
        `;
      } catch {
        utils.id('apod').innerHTML = '<div class="text-dim text-sm">APOD unavailable</div>';
      }
    },

    async refreshMars() {
      try {
        const d = await api.space.mars();
        if (!d) {
          utils.id('mars').innerHTML = '<div class="text-dim text-sm">Mars weather unavailable</div>';
          return;
        }
        utils.id('mars').innerHTML = `
          <div class="card-row"><span class="label">Sol (Mars day)</span><span class="value">${d.sol || '—'}</span></div>
          <div class="card-row"><span class="label">Season</span><span class="value">${utils.escapeHtml(d.season || '—')}</span></div>
          <div class="card-row"><span class="label">Temp min</span><span class="value">${d.min_temp ?? '—'}°C</span></div>
          <div class="card-row"><span class="label">Temp max</span><span class="value">${d.max_temp ?? '—'}°C</span></div>
          <div class="card-row"><span class="label">Atm. pressure</span><span class="value">${d.pressure ?? '—'} Pa</span></div>
          <div class="card-row"><span class="label">Wind speed</span><span class="value">${d.wind_speed ?? '—'} m/s</span></div>
          <div class="card-row"><span class="label">Sunrise (UTC)</span><span class="value">${utils.escapeHtml(d.sunrise?.slice(11, 16) || '—')}</span></div>
          <div class="card-row"><span class="label">Sunset (UTC)</span><span class="value">${utils.escapeHtml(d.sunset?.slice(11, 16) || '—')}</span></div>
        `;
      } catch {
        utils.id('mars').innerHTML = '<div class="text-dim text-sm">Mars weather unavailable</div>';
      }
    },

    async refreshSpaceWx() {
      try {
        const d = await api.space.spaceWeather();
        if (!Array.isArray(d) || !d.length) {
          utils.id('spaceWx').innerHTML = '<div class="empty-state"><div class="icon-host">' + icons.makeIcon('success', 32) + '</div>No active space weather alerts</div>';
          return;
        }
        utils.id('spaceWx').innerHTML = d.slice(0, 5).map((a) => `
          <div class="card" style="margin-bottom:8px; border-left:3px solid ${a.product_id?.includes('WARNING') ? '#ff5e7a' : '#ffcf5e'}">
            <div class="text-sm" style="font-weight:600">${utils.escapeHtml(a.summary || a.headline || 'Alert')}</div>
            <div class="text-xs text-dim" style="margin-top:4px">${utils.escapeHtml(a.issue_datetime || '')}</div>
          </div>
        `).join('');
      } catch {
        utils.id('spaceWx').innerHTML = '<div class="text-dim text-sm">Space weather unavailable</div>';
      }
    }
  };

  global.TP = global.TP || {};
  global.TP.views = global.TP.views || {};
  global.TP.views.space = view;
})(window);
