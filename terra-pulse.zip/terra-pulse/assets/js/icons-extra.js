/* ============================================================
   TERRA PULSE — Extended Icon Library (200+ additional icons)
   Extends TP.icons.ICONS with more categories.
   ============================================================ */
(function (global) {
  'use strict';

  const MORE_ICONS = {
    // File & document
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM14 2v6h6"/>',
    fileCode: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM14 2v6h6M10 12l-2 2 2 2M14 12l2 2-2 2"/>',
    fileChart: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM14 2v6h6M8 14v4M12 11v7M16 8v7"/>',
    fileSpreadsheet: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>',
    fileZip: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM14 2v6h6M10 4h2v2h-2zM10 8h2v2h-2zM10 12h2v2h-2z"/>',
    clipboard: '<rect x="6" y="4" width="12" height="18" rx="2"/><path d="M9 4V2h6v2M9 12h6M9 16h6"/>',
    folderOpen: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7zM3 11h18"/>',
    folderPlus: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7zM12 11v4M10 13h4"/>',
    folderCheck: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7zM9 14l2 2 4-4"/>',

    // Calculator
    calculator: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01M8 18h4"/>',
    percent2: '<path d="M19 5 5 19M7 8a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0zM20 16a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0z"/>',
    divide: '<circle cx="12" cy="6" r="1"/><circle cx="12" cy="18" r="1"/><path d="M3 12h18"/>',
    equal: '<path d="M5 9h14M5 15h14"/>',
    multiply: '<path d="M6 6l12 12M6 18L18 6"/>',
    infinity: '<path d="M18 8a4 4 0 0 0-4 4 4 4 0 0 1-4 4 4 4 0 1 1 0-8 4 4 0 0 1 4 4 4 4 0 0 0 4 4 4 4 0 0 0 0-8z"/>',
    sigma: '<path d="M18 4H4l8 8-8 8h14M4 4l8 8-8 8"/>',

    // Industry & business
    building: '<rect x="4" y="2" width="16" height="20"/><path d="M9 22v-4h6v4M9 6h.01M15 6h.01M9 10h.01M15 10h.01M9 14h.01M15 14h.01"/>',
    building2: '<path d="M3 22V5l9-3 9 3v17M3 22h18M9 22v-4h6v4M9 10h6M9 14h6"/>',
    store: '<path d="M3 9l1-5h16l1 5M4 9v12h16V9M4 9h16M9 21v-6h6v6"/>',
    shoppingCart: '<circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/><path d="M2 2h3l3 13h12l2-9H6"/>',
    shoppingBag: '<path d="M3 7h18l-1 14H4L3 7zM8 7V4a4 4 0 1 1 8 0v3"/>',
    creditCard: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>',
    bank2: '<path d="M3 10 12 4l9 6M4 10v8M8 10v8M12 10v8M16 10v8M20 10v8M3 21h18"/>',
    receipt: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1-2-1zM8 8h8M8 12h8M8 16h5"/>',
    piggyBank: '<path d="M19 9c0-3-3-5-7-5s-7 2-7 5c0 1 .5 2 1 3l-1 3h2l1-2h4l1 2h2v-3a6 6 0 0 0 4-3zM16 7l3-2M14 11h.01"/>',
    coins2: '<circle cx="8" cy="8" r="5"/><path d="M14.5 3.5a5 5 0 1 1-7 7M7 8h2M8 7v2"/>',
    handMoney: '<path d="M11 15h2a2 2 0 1 0 0-4h-2a2 2 0 1 1 0-4h2M11 6h2M11 15h2M2 13l4 4 3-2 7 4 6-3M22 11l-3 5"/>',
    growth: '<path d="M3 17l6-6 4 4 8-9M21 6v6h-6"/>',
    pieChart: '<path d="M21 12A9 9 0 1 1 12 3v9h9z"/>',
    barChart: '<path d="M3 21V3M3 21h18M7 21v-8M12 21V8M17 21v-12"/>',
    trendingDown2: '<path d="M3 7l6 6 4-4 8 9M21 18v-6h-6"/>',

    // Transport
    airplane: '<path d="M10 16v5l2 1 2-1v-5M22 12L2 9l8-7 12 10z"/>',
    flight: '<path d="M10 16v5l2 1 2-1v-5M22 12L2 9l8-7 12 10z"/>',
    boat: '<path d="M3 17h18l-2 4H5l-2-4zM5 17V9l7-3 7 3v8M12 9v8M9 6V3h6v3"/>',
    taxi: '<path d="M5 17h14M3 17l2-7h14l2 7M5 17v3M19 17v3M7 10l1-3h8l1 3M9 17h.01M15 17h.01"/>',
    bus: '<rect x="3" y="5" width="18" height="13" rx="2"/><path d="M3 11h18M3 18v2M21 18v2M7 15h.01M17 15h.01"/>',
    train2: '<rect x="5" y="3" width="14" height="14" rx="2"/><path d="M5 11h14M8 15h.01M16 15h.01M7 21l2-3M17 21l-2-3"/>',
    subway: '<circle cx="12" cy="12" r="9"/><path d="M8 7l4 5 4-5M8 14h8"/>',
    bike: '<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M6 17l4-7h6l-2 7M10 10l-1-3h-2M14 10l2-3h2"/>',
    scooter: '<circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M5 19l5-12h4l4 12M14 7l-1 7"/>',

    // Weather expanded
    sunrise3: '<path d="M17 18a5 5 0 0 0-10 0M12 2v6M4.2 10.2l1.4 1.4M2 18h2M20 18h2M18.4 11.6l1.4-1.4M22 22H2M8 6l4-4 4 4"/>',
    sunset3: '<path d="M17 18a5 5 0 0 0-10 0M12 8V2M4.2 10.2l1.4 1.4M2 18h2M20 18h2M18.4 11.6l1.4-1.4M22 22H2M16 6l-4-4-4 4"/>',
    fog: '<path d="M3 8h18M3 12h18M3 16h18M3 20h12M19 20h2"/>',
    hail: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h10zM7 19l-1 2M11 19l-1 2M15 19l-1 2M19 19l-1 2"/>',
    mist: '<path d="M3 8h18M3 12h18M3 16h14M3 20h10"/>',
    smoke: '<path d="M3 8h12M3 12h18M3 16h14M3 20h10"/>',
    dust: '<path d="M3 8h18M3 12h18M3 16h14M3 20h10M6 5l1-1M11 5l1-1M16 5l1-1"/>',
    tornado: '<path d="M3 4h14M3 8h18M5 12h14M7 16h12M9 20h8"/>',
    hurricane: '<circle cx="12" cy="12" r="3"/><path d="M12 3v6M12 15v6M3 12h6M15 12h6M5.6 5.6l4.2 4.2M14.2 14.2l4.2 4.2M5.6 18.4l4.2-4.2M14.2 9.8l4.2-4.2"/>',

    // Animals & nature
    cat: '<path d="M12 5c.7-1 1.5-1 2 0v3M10 5c.7-1 1.5-1 2 0v3M5 9c0-2 1-3 3-3M19 9c0-2-1-3-3-3M3 13c0-3 4-5 9-5s9 2 9 5c0 5-4 9-9 9s-9-4-9-9zM9 14h.01M15 14h.01M9 17c1 1 5 1 6 0"/>',
    dog: '<path d="M5 11l1-6 4 2M19 11l-1-6-4 2M3 13l2-2 7-1 7 1 2 2-2 6-7 2-7-2-2-6zM9 13h.01M15 13h.01M11 17h2"/>',
    bird: '<path d="M16 7a4 4 0 0 1-8 0M3 21c0-4 4-7 8-7M11 14l-3-5 8 2-1 5M14 9l5-2"/>',
    fish: '<path d="M2 12s4-6 10-6 8 6 8 6-2 6-8 6-10-6-10-6zM22 12l2-3v6l-2-3zM14 12h.01"/>',
    rabbit: '<path d="M9 4l1 5M15 4l-1 5M5 14a4 4 0 0 1 7-3 4 4 0 0 1 7 3c0 4-3 7-7 7s-7-3-7-7zM10 14h.01M14 14h.01"/>',
    leaf2: '<path d="M5 19c0-9 7-16 16-16 0 9-7 16-16 16zM5 19c4-4 8-8 12-12"/>',
    tree: '<path d="M12 22v-7M8 15a4 4 0 0 1-4-4 6 6 0 0 1 4-6 8 8 0 0 1 8 0 6 6 0 0 1 4 6 4 4 0 0 1-4 4z"/>',
    mountain2: '<path d="m3 20 6-10 4 6 2-3 6 7H3z"/>',
    flower: '<circle cx="12" cy="8" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="12" cy="16" r="2"/><circle cx="12" cy="12" r="2"/><path d="M12 14v8"/>',
    sprout: '<path d="M7 20h10M12 20v-8M12 12c0-3-2-5-5-5 0 3 2 5 5 5zM12 12c0-3 2-5 5-5 0 3-2 5-5 5z"/>',
    deciduous: '<path d="M12 2a5 5 0 0 0-5 5 4 4 0 0 0 1 8h8a4 4 0 0 0 1-8 5 5 0 0 0-5-5zM12 15v7"/>',

    // Education
    book2: '<path d="M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4V4zM20 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8V4z"/>',
    graduation: '<path d="M22 9 12 4 2 9l10 5 10-5zM6 11v6c0 1 3 3 6 3s6-2 6-3v-6M22 9v6"/>',
    school: '<path d="M2 9l10-5 10 5-10 5L2 9zM4 10v8c0 1 4 3 8 3s8-2 8-3v-8M22 9v6"/>',
    pencil: '<path d="M12 20h9M16.5 3.5a2 2 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>',
    ruler2: '<path d="M3 16l5 5L21 8l-5-5L3 16zM7 16l2 2M10 13l2 2M13 10l2 2M16 7l2 2"/>',
    scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.12 16M14.47 14.12L20 20M8.12 8L12 12"/>',
    highlighter: '<path d="M9 11l4 4M5 18l4-3 4 4 6-9-4-4-6 9-4 3v0zM3 22l4-1"/>',
    eraser: '<path d="M3 17l6 6h12l-7-7-11 1zM3 17l9-9 6 6-9 9M14 8l6 6"/>',

    // Music & arts
    music2: '<circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/><path d="M9 18V5l12-2v13"/>',
    note: '<circle cx="6" cy="18" r="3"/><path d="M9 18V4l12-2v14"/>',
    headphones2: '<path d="M3 18v-6a9 9 0 0 1 18 0v6M3 18a2 2 0 0 0 2 2h1v-6H5a2 2 0 0 0-2 2zM21 18a2 2 0 0 1-2 2h-1v-6h1a2 2 0 0 1 2 2z"/>',
    guitar: '<path d="M14 4l6 6M3 21c2-3 4-5 7-5M14 4l-3 3M9 9l3 3M3 21l3-3"/>',
    piano: '<rect x="3" y="5" width="18" height="14"/><path d="M8 5v8M12 5v8M16 5v8M8 13v6M12 13v6M16 13v6"/>',
    drum: '<path d="M3 18h18v-6H3zM6 18l-1 4M18 18l1 4M12 18v-12M9 6l-3-3M15 6l3-3"/>',
    mic: '<rect x="9" y="2" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    camera2: '<path d="M3 7h4l2-2h6l2 2h4v12H3z"/><circle cx="12" cy="13" r="4"/>',
    film: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4M3 12h18"/>',
    clapperboard: '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M7 6l3-3M11 6l3-3M15 6l3-3M3 6h18M7 9v0M11 9v0M15 9v0"/>',
    theater: '<path d="M3 12a4 4 0 0 1 4-4 4 4 0 0 1 4 4M9 8a4 4 0 0 1 4-4 4 4 0 0 1 4 4M13 8a4 4 0 0 1 4-4 4 4 0 0 1 4 4M5 12v8M19 12v8"/>',

    // Food & drink
    coffee: '<path d="M3 8h14v6a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5V8zM17 9h2a2 2 0 0 1 0 4h-2M6 2v3M10 2v3M14 2v3"/>',
    cup: '<path d="M3 8h14v6a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5V8zM17 9h2a2 2 0 0 1 0 4h-2"/>',
    water: '<path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z"/>',
    wine: '<path d="M8 22h8M12 17v5M5 3h14l-1 8a6 6 0 0 1-12 0L5 3z"/>',
    beer: '<path d="M8 4h8v6a4 4 0 0 1-8 0V4zM8 8h8M8 12v8h8v-8M8 16h8"/>',
    pizza: '<path d="M12 3a9 9 0 0 1 9 9 9 9 0 0 1-9 9M12 3a9 9 0 0 0-9 9 9 9 0 0 0 9 9M12 3v18M8 10h.01M16 10h.01M9 15h.01M15 15h.01"/>',
    burger: '<path d="M3 7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4M3 7h18M3 11h18M3 15h18a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3z"/>',
    cake: '<path d="M3 21V11a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v10M3 21h18M3 11l9-3 9 3M12 4v2"/>',
    apple: '<path d="M12 7c-3-2-8-1-8 4 0 6 4 11 8 9 4 2 8-3 8-9 0-5-5-6-8-4zM12 7V3"/>',
    carrot: '<path d="M3 21l9-9M12 12l3-3 6 6-3 3M12 4l3 3M9 4l3 3M7 6l3 3"/>',

    // Sports
    soccer: '<circle cx="12" cy="12" r="9"/><path d="M12 7l3 2-1 4-4 0-1-4 3-2zM12 3v4M5 9l3 2M19 9l-3 2M5 16l3-2M19 16l-3-2M9 21l3-3M15 21l-3-3"/>',
    basketball: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18M5 5a14 14 0 0 1 14 14M5 19a14 14 0 0 1 14-14"/>',
    football: '<path d="M3 12c0-5 4-9 9-9s9 4 9 9-4 9-9 9-9-4-9-9zM3 12h18M12 3v18M5 6l7 6 7-6M5 18l7-6 7 6"/>',
    tennis: '<circle cx="12" cy="12" r="9"/><path d="M5 5a14 14 0 0 0 14 14M19 5a14 14 0 0 1-14 14"/>',
    baseball: '<circle cx="12" cy="12" r="9"/><path d="M5 7c2 1 4 1 6 0s4-1 6 0M5 17c2-1 4-1 6 0s4 1 6 0"/>',
    swimming: '<path d="M3 12c2 0 2-2 4-2s2 2 4 2 2-2 4-2 2 2 4 2M3 17c2 0 2-2 4-2s2 2 4 2 2-2 4-2 2 2 4 2M16 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 9c3-3 5-3 8-1"/>',
    running: '<circle cx="17" cy="5" r="2"/><path d="M5 22l4-8 5 3 1 5M9 14l-3-3 4-5 4 3 3-2M14 11l2-4"/>',
    bike2: '<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M6 17l4-7h6l-2 7M10 10l-1-3h-2M14 10l2-3h2"/>',

    // Gaming
    gamepad: '<rect x="2" y="7" width="20" height="11" rx="3"/><path d="M7 12h2M8 11v2M15 11h.01M17 13h.01"/>',
    dice: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1" fill="currentColor"/><circle cx="16" cy="8" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="8" cy="16" r="1" fill="currentColor"/><circle cx="16" cy="16" r="1" fill="currentColor"/>',
    puzzle: '<path d="M19 9h-1V7a2 2 0 0 0-2-2h-2v1a2 2 0 0 1-4 0V5H8a2 2 0 0 0-2 2v2H5a2 2 0 0 0 0 4h1v2a2 2 0 0 0 2 2h2v-1a2 2 0 0 1 4 0v1h2a2 2 0 0 0 2-2v-2h1a2 2 0 0 0 0-4z"/>',
    joystick: '<rect x="4" y="13" width="16" height="8" rx="2"/><path d="M9 13V8a3 3 0 0 1 6 0v5M9 18h.01M15 18h.01M9 8h6"/>',
    chess: '<circle cx="12" cy="4" r="2"/><path d="M10 6h4l1 4-3 2-3-2 1-4zM8 12h8l1 4H7l1-4zM5 18h14l1 4H4l1-4z"/>',
    cards2: '<rect x="3" y="3" width="14" height="18" rx="2"/><path d="M7 3v14M21 7l-4 14"/>',

    // Maps & navigation
    mapPin: '<path d="M12 22s8-7 8-13a8 8 0 1 0-16 0c0 6 8 13 8 13z"/><circle cx="12" cy="9" r="3"/>',
    mapPin2: '<circle cx="12" cy="9" r="3"/><path d="M12 22s8-7 8-13a8 8 0 1 0-16 0c0 6 8 13 8 13z"/>',
    navigation: '<path d="M3 11l19-9-9 19-2-8-8-2z"/>',
    crosshair: '<circle cx="12" cy="12" r="9"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>',
    map2: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>',
    route: '<circle cx="6" cy="19" r="3"/><circle cx="18" cy="5" r="3"/><path d="M6 16v-4a4 4 0 0 1 4-4h4M18 8v3a4 4 0 0 1-4 4h-4"/>',
    compass3: '<circle cx="12" cy="12" r="9"/><path d="m15 9-2 6-4 0 2-6 4 0z" fill="currentColor"/>',

    // Time & date
    alarm: '<circle cx="12" cy="13" r="8"/><path d="M5 3L2 6M19 3l3 3M12 9v4l3 2"/>',
    stopWatch: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6M12 5V2"/>',
    hourglass: '<path d="M6 2h12M6 22h12M6 2v6l6 4-6 4v6M18 2v6l-6 4 6 4v6"/>',
    calendar2: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    calendarCheck: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M9 15l2 2 4-4"/>',
    calendarPlus: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M12 14v4M10 16h4"/>',
    clock3: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7M3 4v4h4M12 7v5l3 2"/>',

    // Security
    shield3: '<path d="M12 2 4 5v7c0 5 3 8 8 10 5-2 8-5 8-10V5l-8-3zM9 12l2 2 4-4"/>',
    lock2: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 1 1 8 0v4"/>',
    unlock2: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0"/>',
    key2: '<circle cx="8" cy="8" r="4"/><path d="M11 11l9 9M16 16l2-2M19 19l2-2"/>',
    fingerprint2: '<path d="M12 4a8 8 0 0 0-8 8M20 12a8 8 0 0 0-8-8M5 16a14 14 0 0 0 2 4M19 16a14 14 0 0 1-2 4M12 8a4 4 0 0 0-4 4v4a16 16 0 0 0 1 4M16 12v4a16 16 0 0 1-1 4M12 12v8"/>',
    firewall: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 8h18M3 13h18M3 18h18M9 3v5M15 8v5M7 13v5M17 13v5"/>',
    password: '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="8" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="16" cy="12" r="1" fill="currentColor"/>',

    // Communication
    phone2: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.5-1.1a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2z"/>',
    mail2: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    message2: '<path d="M21 11.5a8.4 8.4 0 0 1-9 8.4L3 21l1.1-9A8.4 8.4 0 1 1 21 11.5z"/>',
    chat2: '<path d="M21 11.5a8.4 8.4 0 0 1-9 8.4L3 21l1.1-9A8.4 8.4 0 1 1 21 11.5zM8 11h.01M12 11h.01M16 11h.01"/>',
    send2: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z"/>',
    inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    reply: '<path d="M9 17l-5-5 5-5M4 12h13a5 5 0 0 1 5 5v3"/>',
    forward: '<path d="M15 17l5-5-5-5M20 12H7a5 5 0 0 0-5 5v3"/>',
    at: '<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"/>',

    // Cloud & sync
    cloudUpload: '<path d="M12 13v8M8 17l4-4 4 4M16 18a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h3z"/>',
    cloudDownload: '<path d="M12 13v8M8 17l4 4 4-4M16 18a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7h3z"/>',
    cloudOff: '<path d="M9 9a4 4 0 0 0 0 8h6M3 3l18 18M16 18a4 4 0 0 1-1-7.9"/>',
    cloudSync: '<path d="M17 14a4 4 0 0 0 0-8 6 6 0 0 0-11 1 4 4 0 0 0 1 7M9 18l3-3 3 3M12 21v-6"/>',
    refresh2: '<path d="M21 12a9 9 0 1 1-3-6.7M21 4v4h-4"/>',
    sync: '<path d="M21 12a9 9 0 0 1-15 6.7M3 12a9 9 0 0 1 15-6.7M21 4v4h-4M3 20v-4h4"/>',
    wifi3: '<path d="M5 12a10 10 0 0 1 14 0M8 15a6 6 0 0 1 8 0M11 18a2 2 0 0 1 2 0M2 9a16 16 0 0 1 20 0"/>',
    radio2: '<circle cx="12" cy="12" r="2"/><path d="M7.8 7.8a6 6 0 0 1 8.4 0M16.2 16.2a6 6 0 0 1-8.4 0M4.9 4.9a10 10 0 0 1 14.1 0M19.1 19.1a10 10 0 0 1-14.1 0"/>',
    broadcast2: '<circle cx="12" cy="12" r="2"/><path d="M5 5a10 10 0 0 1 0 14M19 5a10 10 0 0 0 0 14M8 8a6 6 0 0 1 0 8M16 8a6 6 0 0 0 0 8"/>',

    // Mood
    smile: '<circle cx="12" cy="12" r="9"/><path d="M9 14c1 1 5 1 6 0M9 10h.01M15 10h.01"/>',
    frown: '<circle cx="12" cy="12" r="9"/><path d="M9 16c1-1 5-1 6 0M9 10h.01M15 10h.01"/>',
    meh: '<circle cx="12" cy="12" r="9"/><path d="M9 14h6M9 10h.01M15 10h.01"/>',
    thumbsUp: '<path d="M7 22V11l5-9c1 0 2 1 2 2v5h6a2 2 0 0 1 2 2l-2 9a2 2 0 0 1-2 1H7zM7 11H3v11h4"/>',
    thumbsDown: '<path d="M17 2v11l-5 9c-1 0-2-1-2-2v-5H4a2 2 0 0 1-2-2l2-9A2 2 0 0 1 6 2h11zM17 13h4V2h-4"/>',
    heart2: '<path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 11c0 5.5-7 10-7 10z"/>',
    star3: '<path d="M12 2l3 7h7l-6 4 2 8-6-5-6 5 2-8-6-4h7l3-7z"/>',

    // Specialized
    satellite3: '<path d="m5 11 4-4M11 5l4 4M15 9l-4 4M9 15l-4-4M14 14l4 4M5 19a8 8 0 0 1 8-8M19 5a8 8 0 0 0-8 8"/>',
    radar: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1" fill="currentColor"/><path d="M12 12l5-5"/>',
    antenna3: '<path d="M4 21l8-18 8 18M4 21h16M8 14h8"/>',
    cpu3: '<rect x="6" y="6" width="12" height="12" rx="1"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"/>',
    server3: '<rect x="3" y="4" width="18" height="6" rx="1"/><rect x="3" y="14" width="18" height="6" rx="1"/><path d="M7 7h.01M7 17h.01M11 7h6M11 17h6"/>',
    database2: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    terminal2: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M13 15h4"/>',
    code2: '<path d="m8 6-6 6 6 6M16 6l6 6-6 6M14 4l-4 16"/>',
    keyboard: '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M8 14h8"/>',

    // Building blocks for charts
    barChartUp: '<path d="M3 21V3M3 21h18M7 21v-6M12 21V9M17 21v-12M21 21V5"/>',
    barChartDown: '<path d="M3 21V3M3 21h18M7 21V9M12 21v-6M17 21v-3M21 21V15"/>',
    candleChart: '<path d="M3 21V3M3 21h18M7 5v3M7 14v5M7 8v6M17 4v3M17 14v5M17 7v7M12 7v2M12 15v4M12 9v6"/>',
    lineChart: '<path d="M3 3v18h18M7 14l3-3 3 2 5-6"/>',
    areaChart: '<path d="M3 3v18h18M3 17l5-5 4 3 4-6 5 4M3 17v4h18"/>',
    pieChart2: '<path d="M21 12A9 9 0 1 1 12 3v9h9z"/><path d="M12 3v9h9"/>',

    // Misc
    palette2: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="9" r="1" fill="currentColor"/><circle cx="16" cy="9" r="1" fill="currentColor"/><circle cx="9" cy="15" r="1" fill="currentColor"/><circle cx="15" cy="15" r="1" fill="currentColor"/>',
    paintBucket: '<path d="M19 11l-7-7-9 9 7 7 9-9zM5 13l4-4M22 18a2 2 0 1 1-4 0c0-1 2-3 2-3s2 2 2 3z"/>',
    magnet: '<path d="M6 4v8a6 6 0 0 0 12 0V4M6 4h4v8M14 4h4v8"/>',
    atom2: '<circle cx="12" cy="12" r="2"/><ellipse cx="12" cy="12" rx="10" ry="4"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(120 12 12)"/>',
    dna2: '<path d="M4 2c8 0 16 8 16 20M20 2c-8 0-16 8-16 20M4 2v20M20 2v20M4 8h16M4 16h16M7 4h10M7 20h10"/>',
    microscope2: '<path d="M6 18h8M3 22h18M9 18l-3-3 5-5 3 3-5 5zM14 8l3 3M9 3l4 4"/>',
    flask2: '<path d="M9 3h6v5l4 9a3 3 0 0 1-3 4H8a3 3 0 0 1-3-4l4-9V3zM9 3v6h6V3"/>',
    testTube2: '<path d="M14 2v18a3 3 0 0 1-6 0V2M8 2h8M8 10h8M8 14h6"/>',
    flame3: '<path d="M12 2s4 4 4 8a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 1 3 2 4 0-3 0-5 0-8z"/>',

    // Volume / settings
    volume: '<path d="M11 5L6 9H2v6h4l5 4V5zM15 9a3 3 0 0 1 0 6M18 7a7 7 0 0 1 0 10"/>',
    volumeOff: '<path d="M11 5L6 9H2v6h4l5 4V5zM23 9l-6 6M17 9l6 6"/>',
    volumeMute: '<path d="M11 5L6 9H2v6h4l5 4V5zM22 12h-4M22 9l-4 6M22 15l-4-6"/>',
    brightness: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    contrast: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18" fill="currentColor"/>',
    eyeOff: '<path d="M9 9a3 3 0 0 0 4 4M3 3l18 18M10.5 5.2A9 9 0 0 1 21 12c-1 2-2.5 3.5-4 4.5M6 6A9 9 0 0 0 3 12c1 2 4 5 9 5"/>',
    eye3: '<circle cx="12" cy="12" r="3"/><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/>',

    // Toggle / layout
    toggleLeft: '<rect x="2" y="6" width="20" height="12" rx="6"/><circle cx="8" cy="12" r="3" fill="currentColor"/>',
    toggleRight: '<rect x="2" y="6" width="20" height="12" rx="6"/><circle cx="16" cy="12" r="3" fill="currentColor"/>',
    columns: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18M15 3v18"/>',
    rows: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18"/>',
    layout: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 9v12"/>',
    sidebar: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18"/>',
    maximize: '<path d="M3 3h6M3 3v6M21 3h-6M21 3v6M3 21h6M3 21v-6M21 21h-6M21 21v-6"/>',
    minimize: '<path d="M9 3v6H3M15 3v6h6M9 21v-6H3M15 21v-6h6"/>',

    // Misc II
    bookmark2: '<path d="M6 3h12v18l-6-4-6 4V3z"/>',
    tag: '<path d="M3 3h10l8 8-10 10L3 13V3zM7 7h.01"/>',
    gift: '<rect x="3" y="8" width="18" height="13" rx="1"/><path d="M3 12h18M12 8v13M12 8S9 8 8 6 10 3 12 8zM12 8s3 0 4-2-2-5-4-2z"/>',
    crown: '<path d="M3 19h18l-2-9-5 4-4-7-4 7-5-4-2 9zM5 22h14"/>',
    diamond: '<path d="M6 2h12l4 6-10 14L2 8l4-6zM2 8h20M9 2l-3 6 6 14 6-14-3-6"/>',
    gem2: '<path d="M3 8l4-4h10l4 4-9 12L3 8zM7 8h10M9 4l3 16M15 4l-3 16"/>',
    trophy2: '<path d="M5 4h14v3a4 4 0 0 1-4 4h-6a4 4 0 0 1-4-4V4zM5 6H3a2 2 0 0 0 2 2M19 6h2a2 2 0 0 1-2 2M9 14v3a3 3 0 0 0 6 0v-3M8 21h8M10 21v-3M14 21v-3"/>',
    medal: '<circle cx="12" cy="15" r="6"/><path d="M12 11v4l2 2M8 9L5 2h4l3 5M16 9l3-7h-4l-3 5"/>',
    badge: '<path d="M12 2l3 3h4v4l3 3-3 3v4h-4l-3 3-3-3H5v-4l-3-3 3-3V5h4l3-3z"/>',
    certificate: '<rect x="3" y="3" width="18" height="14" rx="2"/><circle cx="12" cy="10" r="3"/><path d="M9 17l3 4 3-4"/>',

    // Files
    copy2: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
    duplicate: '<rect x="9" y="9" width="11" height="11" rx="2"/><rect x="4" y="4" width="11" height="11" rx="2"/>',
    paste: '<rect x="6" y="4" width="12" height="18" rx="2"/><path d="M9 4V2h6v2"/>',
    scissors2: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.12 16M14.47 14.12L20 20M8.12 8L12 12"/>',

    // Transport 2
    car2: '<path d="M3 13l2-6a2 2 0 0 1 2-1h10a2 2 0 0 1 2 1l2 6v5h-3v-2H6v2H3v-5zM6 16h.01M18 16h.01"/>',
    truck: '<path d="M3 6h11v9H3zM14 9h4l3 3v3h-7zM7 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM17 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/>',
    ship2: '<path d="M3 17h18l-2 4H5l-2-4zM5 17V9l7-3 7 3v8M12 9v8M9 6V3h6v3"/>',
    rocket3: '<path d="M12 2c3 4 5 8 5 12a5 5 0 0 1-10 0c0-4 2-8 5-12zM12 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM7 16l-3 3 4-1M17 16l3 3-4-1M9 19l-1 3M15 19l1 3"/>',
    ufo2: '<path d="M3 14a9 9 0 0 1 18 0H3zM12 14v4M9 18l-2 3M15 18l2 3M12 14a3 3 0 0 0-3-3M12 14a3 3 0 0 1 3-3"/>',

    // Health
    hospital: '<path d="M3 21V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v16M3 21h18M9 21v-5h6v5M9 8h2M10 7v2M14 8h2M15 7v2M3 12h18"/>',
    stethoscope: '<path d="M4 2v6a4 4 0 0 0 8 0V2M6 2v6a2 2 0 0 0 4 0V2M12 12a4 4 0 0 0 8 0v2M16 16v0"/>',
    bandage: '<rect x="2" y="9" width="20" height="6" rx="3" transform="rotate(45 12 12)"/><circle cx="9" cy="9" r="1" fill="currentColor"/><circle cx="15" cy="15" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
    thermometer3: '<path d="M14 14V4a2 2 0 1 0-4 0v10a4 4 0 1 0 4 0z"/>',
    pill2: '<rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(45 12 12)"/><path d="M9 9l6 6"/>',
    capsule: '<rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(45 12 12)"/>',

    // Misc III
    fire2: '<path d="M12 2s4 4 4 8a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 1 3 2 4 0-3 0-5 0-8z"/>',
    flame4: '<path d="M12 2s4 4 4 8a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 1 3 2 4 0-3 0-5 0-8z"/>',
    bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/>',
    spark: '<path d="M12 2v6M12 16v6M2 12h6M16 12h6M5 5l3 3M16 16l3 3M5 19l3-3M16 8l3-3"/>',
    zap2: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/>',
    power3: '<path d="M12 2v10M5 7a10 10 0 1 0 14 0"/>',
    battery3: '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4"/>',
    batteryCharging: '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4M9 12h2l-1 3 3-4h-2l1-3z" fill="currentColor"/>',
    plug2: '<path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0V8zM12 17v5"/>',

    // Map markers
    pin3: '<path d="M12 22s8-7 8-13a8 8 0 1 0-16 0c0 6 8 13 8 13z"/><circle cx="12" cy="9" r="3"/>',
    flag2: '<path d="M4 21V4l8 2 8-2v11l-8 2-8-2"/>',
    flag3: '<path d="M4 21V4l8 2 8-2v11l-8 2-8-2"/>',

    // Zodiac / astrology
    aries: '<path d="M4 8a4 4 0 0 1 4-4M20 8a4 4 0 0 0-4-4M4 8v12M20 8v12M4 14h16"/>',
    taurus: '<circle cx="12" cy="14" r="6"/><path d="M5 7l3 3M19 7l-3 3"/>',
    gemini: '<path d="M6 4v16M18 4v16M6 8h12M6 16h12"/>',
    cancer: '<path d="M5 9a4 4 0 0 1 7 0M19 9a4 4 0 0 0-7 0M5 15a4 4 0 0 0 7 0M19 15a4 4 0 0 1-7 0"/>',
    leo: '<circle cx="10" cy="14" r="4"/><path d="M14 10c2-2 4-2 6-4v8"/>',
    virgo: '<path d="M4 4v16M8 4v16M4 8h4M4 16h4M12 4v12l4-4v8M16 12l4-4v8"/>',
    libra: '<path d="M3 20h18M5 12a4 4 0 0 1 7-3M12 9a4 4 0 0 1 7 3"/>',
    scorpio: '<path d="M4 4v12a4 4 0 0 0 8 0V8M12 12v4a4 4 0 0 0 8 0V8M16 14l2 2 2-2"/>',
    sagittarius: '<path d="M3 21L21 3M21 3h-6M21 3v6M3 13l8-8"/>',
    capricorn: '<path d="M5 4v12l3-2V8M8 14l4 4V8M12 18l4-2v-8M16 12l3-2"/>',
    aquarius: '<path d="M3 8l3-2 3 2 3-2 3 2 3-2 3 2M3 13l3-2 3 2 3-2 3 2 3-2 3 2M3 18l3-2 3 2 3-2 3 2 3-2 3 2"/>',
    pisces: '<path d="M5 3c0 6 0 12 0 18M19 3c0 6 0 12 0 18M5 12h14"/>',

    // Special UI
    spinner: '<path d="M12 2a10 10 0 0 1 10 10M22 12a10 10 0 0 1-10 10M12 22A10 10 0 0 1 2 12M2 12A10 10 0 0 1 12 2"/>',
    loading: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 9 9"/>',
    battery4: '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4M6 12h6M9 9v6"/>',
    gauge2: '<path d="M3 12a9 9 0 0 1 18 0M12 12l4-3M3 12h2M19 12h2M12 3v2M5 5l1 1M19 5l-1 1"/>',
    speedometer2: '<path d="M3 12a9 9 0 0 1 18 0M12 12l4-3M3 12h2"/>',
    dial: '<circle cx="12" cy="12" r="9"/><path d="M12 12l5-3M12 6v1M18 12h-1M12 18v-1M6 12h1"/>',
    knob: '<circle cx="12" cy="12" r="9"/><path d="M12 12V5"/>',

    // Misc IV
    wifiOff: '<path d="M1 1l22 22M3 12a10 10 0 0 1 6-3M5 5a16 16 0 0 1 12-1M8 15a6 6 0 0 1 8 0M11 18a2 2 0 0 1 2 0"/>',
    radioOff: '<path d="M1 1l22 22"/>',
    settingsGear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    tuning: '<path d="M3 6h18M3 12h18M3 18h18M7 4v4M13 10v4M17 16v4"/>',
    adjust: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18" fill="currentColor"/>',

    // Logic / math
    and: '<path d="M7 4v8a5 5 0 0 0 10 0V4zM7 4H4M7 12H4"/>',
    or: '<path d="M17 4v8a5 5 0 0 1-10 0V4M17 4h3M17 12h3"/>',
    xor: '<path d="M3 4h4v8a5 5 0 0 0 10 0V4h4M7 12H4M17 12h3"/>',
    function: '<path d="M3 6h18M9 6v12M15 6v12M3 18h18"/>',
    integral: '<path d="M16 3c-2 0-3 1-3 4v10c0 3-1 4-3 4"/>',
    derivative: '<path d="M3 21c4 0 6-9 9-9s4 9 9 9M12 3v9"/>',

    // Voice & audio FX
    audioWave: '<path d="M2 12h2l2-6 3 14 3-12 3 8 2-4h3"/>',
    waveform2: '<path d="M2 12h2l2-6 3 14 3-12 3 8 2-4h3"/>',
    speaker: '<rect x="4" y="2" width="16" height="20" rx="2"/><circle cx="12" cy="9" r="2"/><circle cx="12" cy="15" r="3"/>',
    speakerOff: '<rect x="4" y="2" width="16" height="20" rx="2"/><circle cx="12" cy="9" r="2"/><path d="M2 2l20 20"/>',

    // Compass / direction
    arrowN: '<path d="M12 2v20M12 2l-5 7M12 2l5 7"/>',
    arrowS: '<path d="M12 2v20M12 22l-5-7M12 22l5-7"/>',
    arrowE: '<path d="M2 12h20M22 12l-7-5M22 12l-7 5"/>',
    arrowW: '<path d="M2 12h20M2 12l7-5M2 12l7 5"/>',

    // Tag / category
    hashtag: '<path d="M9 3L7 21M17 3l-2 18M3 8h18M3 16h18"/>',
    mention: '<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"/>',
    link2: '<path d="M10 13a4 4 0 0 0 6 0l3-3a4 4 0 1 0-6-6l-1 1M14 11a4 4 0 0 0-6 0l-3 3a4 4 0 1 0 6 6l1-1"/>',

    // Misc V
    bookmark3: '<path d="M6 3h12v18l-6-4-6 4V3z"/>',
    bookOpen: '<path d="M2 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H2V4zM22 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8V4z"/>',
    bookClosed: '<path d="M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4V4zM20 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8V4z"/>',
    library: '<path d="M3 4v16M7 4v16M11 4v16M15 4v16M19 4v16"/>',
    bookMarked: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3zM12 3v8l2-2 2 2V3"/>',

    // Math operators (literal)
    plusMinus: '<path d="M5 8h14M12 2v14M5 18h14"/>',
    multiplication: '<path d="M6 6l12 12M6 18L18 6"/>',
    division: '<circle cx="12" cy="6" r="1" fill="currentColor"/><circle cx="12" cy="18" r="1" fill="currentColor"/><path d="M3 12h18"/>',
    lessThan: '<path d="M18 6L6 12l12 6"/>',
    greaterThan: '<path d="M6 6l12 6-12 6"/>',
    equalTo: '<path d="M5 9h14M5 15h14"/>',
    approx: '<path d="M3 8c2-2 4 2 6 0s4 2 6 0 4 2 6 0M3 14c2-2 4 2 6 0s4 2 6 0 4 2 6 0"/>',
    sqrt: '<path d="M3 12l3 0 3 8 6-16 6 4"/>',

    // Misc VI
    clockCountdown: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2M9 3a4 4 0 0 1 6 0"/>',
    timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6M12 5V2"/>',
    stopwatch2: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6M12 5V2"/>',

    // Health & body
    heart3: '<path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 11c0 5.5-7 10-7 10z"/>',
    brain: '<path d="M9 3a3 3 0 0 0-3 3v2a3 3 0 0 0-2 5 3 3 0 0 0 2 5v2a3 3 0 0 0 6 0V3a3 3 0 0 0-3 0zM15 3a3 3 0 0 1 3 3v2a3 3 0 0 1 2 5 3 3 0 0 1-2 5v2a3 3 0 0 1-6 0"/>',
    lung: '<path d="M12 3v8M8 11c0 4-2 8-5 8s-2-4 0-8 5-2 5 0zM16 11c0 4 2 8 5 8s2-4 0-8-5-2-5 0z"/>',
    bone: '<path d="M17 7a3 3 0 0 0-4-3 3 3 0 0 0-2 5l-7 7a3 3 0 0 0 5 2l7-7a3 3 0 0 0 5-2 3 3 0 0 0-4-2z"/>',
    tooth: '<path d="M12 3c-3 0-5 1-7 3-2 2-1 5 0 8 1 2 1 6 3 7 1 .5 2-2 2-4 0-2 0-4 2-4s2 2 2 4c0 2 1 4.5 2 4 2-1 2-5 3-7 1-3 2-6 0-8-2-2-4-3-7-3z"/>',

    // Energy
    solarPanel: '<rect x="3" y="4" width="18" height="14" rx="1"/><path d="M3 9h18M3 14h18M9 4v14M15 4v14M12 18v4M8 22h8"/>',
    windTurbine: '<path d="M12 22V8M12 8L9 2M12 8l3-6M12 8l6 4M12 8L6 12M9 22h6"/>',
    hydroPower: '<path d="M3 12c2-3 4-3 6 0s4 3 6 0 4-3 6 0M3 18c2-3 4-3 6 0s4 3 6 0 4-3 6 0M5 8l4-4M15 8l4-4"/>',
    nuclearPower: '<circle cx="12" cy="12" r="2"/><path d="M12 10V4M14.5 13.5l5 4M9.5 13.5l-5 4"/>',
    batteryFull: '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4M6 10v4M10 10v4M14 10v4"/>',

    // Code & dev
    codeBracket: '<path d="M8 6l-6 6 6 6M16 6l6 6-6 6M14 4l-4 16"/>',
    codeDot: '<circle cx="6" cy="12" r="2" fill="currentColor"/><circle cx="12" cy="12" r="2" fill="currentColor"/><circle cx="18" cy="12" r="2" fill="currentColor"/>',
    codeArray: '<path d="M3 6h18M3 12h18M3 18h18M7 9l2 3-2 3M17 9l-2 3 2 3"/>',
    bug: '<rect x="8" y="6" width="8" height="14" rx="4"/><path d="M9 6V4a3 3 0 0 1 6 0v2M4 11h4M16 11h4M4 16h4M16 16h4M4 21l4-3M16 18l4 3M4 6l4 2M16 8l4-2"/>',
    gitBranch: '<circle cx="6" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="8" r="2"/><path d="M6 8v8M18 10v3a3 3 0 0 1-3 3h-7"/>',
    gitMerge: '<circle cx="6" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="12" r="2"/><path d="M6 8v8M6 12a6 6 0 0 0 6 6h2"/>',
    gitPull: '<circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M6 8v10h12M18 8V4M14 4l4 4-4 4"/>',
    gitCommit: '<circle cx="12" cy="12" r="3"/><path d="M3 12h6M15 12h6"/>',

    // Misc VII
    cube: '<path d="m12 2 9 5-9 5-9-5 9-5zM3 7v10l9 5 9-5V7M12 12v10"/>',
    box: '<path d="M3 6l9-4 9 4v12l-9 4-9-4V6zM3 6l9 4 9-4M12 10v12"/>',
    archive: '<rect x="3" y="4" width="18" height="4"/><path d="M5 8v12h14V8M10 12h4"/>',
    inbox2: '<path d="M22 12h-6l-2 3h-4l-2-3H2M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    package: '<path d="M3 6l9-4 9 4v12l-9 4-9-4V6zM3 6l9 4 9-4M12 10v12"/>',
    truck2: '<path d="M3 6h11v9H3zM14 9h4l3 3v3h-7zM7 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM17 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/>',

    // Map expanded
    map3: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>',
    globe2: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    globe3: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18M5 6c2 4 2 8 0 14M19 6c-2 4-2 8 0 14"/>',

    // Emoji-like abstract
    smiley: '<circle cx="12" cy="12" r="9"/><path d="M9 14c1 1 5 1 6 0M9 10h.01M15 10h.01"/>',
    sad: '<circle cx="12" cy="12" r="9"/><path d="M9 16c1-1 5-1 6 0M9 10h.01M15 10h.01"/>',
    neutral: '<circle cx="12" cy="12" r="9"/><path d="M9 14h6M9 10h.01M15 10h.01"/>',
    laughing: '<circle cx="12" cy="12" r="9"/><path d="M9 13c1 2 5 2 6 0M7 10c1-1 3-1 4 0M13 10c1-1 3-1 4 0"/>',

    // Type / typography
    bold: '<path d="M7 4h6a4 4 0 0 1 0 8H7zM7 12h7a4 4 0 0 1 0 8H7z"/>',
    italic: '<path d="M19 4h-6M11 20H5M15 4l-6 16"/>',
    underline2: '<path d="M6 4v6a6 6 0 0 0 12 0V4M4 21h16"/>',
    strikethrough: '<path d="M3 12h18M8 8a4 4 0 0 1 4-4c2 0 4 1 4 3M8 16c0 2 2 4 4 4s4-1 4-3"/>',
    heading: '<path d="M6 4v16M18 4v16M6 12h12"/>',
    list2: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    listOrdered: '<path d="M10 6h11M10 12h11M10 18h11M4 6V3l-1 1M4 4l1 1M4 9l1-1H3v3M3 13l2-1v4M3 18l2-1h-2v3"/>',
    indent: '<path d="M3 4h18M11 8h10M11 12h10M11 16h10M3 20h18M3 8l4 4-4 4"/>',
    outdent: '<path d="M3 4h18M11 8h10M11 12h10M11 16h10M3 20h18M7 8l-4 4 4 4"/>',

    // New UI
    command: '<path d="M9 6a3 3 0 1 0-3 3M9 6h6M9 18a3 3 0 1 1-3-3M9 18h6M15 6a3 3 0 1 1 3 3M15 6v12M15 18a3 3 0 1 0 3-3"/>',
    palette3: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="9" r="1" fill="currentColor"/><circle cx="16" cy="9" r="1" fill="currentColor"/><circle cx="9" cy="15" r="1" fill="currentColor"/><circle cx="15" cy="15" r="1" fill="currentColor"/>',
    palette4: '<path d="M12 2a10 10 0 1 0 0 20c1 0 2-1 2-2s-1-1-1-2 1-2 2-2h2a4 4 0 0 0 4-4 10 10 0 0 0-9-8z"/><circle cx="7" cy="11" r="1" fill="currentColor"/><circle cx="12" cy="7" r="1" fill="currentColor"/><circle cx="17" cy="11" r="1" fill="currentColor"/>',

    // End of icons
    flagCheck: '<path d="M4 21V4l8 2 8-2v11l-8 2-8-2M9 21v-3"/>',
    flagOff: '<path d="M4 21V4l8 2 8-2v11l-8 2-8-2M9 21v-3"/>',
    flagDone: '<path d="M4 21V4l8 2 8-2v11l-8 2-8-2M9 21v-3"/>'
  };

  // Merge with existing icons
  if (global.TP && global.TP.icons) {
    Object.assign(global.TP.icons.ICONS, MORE_ICONS);
  } else {
    console.warn('[icons-extra] TP.icons not found, cannot merge');
  }
})(window);
