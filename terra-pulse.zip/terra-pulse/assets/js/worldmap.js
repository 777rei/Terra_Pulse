/* ============================================================
   TERRA PULSE — TopoJSON + SVG world map renderer
   Renders accurate country boundaries from real TopoJSON data.
   No external libs — implements TopoJSON decode + projection.
   ============================================================ */
(function (global) {
  'use strict';

  // ---------- TopoJSON decoder (subset of topojson-spec) ----------
  // Decodes a TopoJSON topology into GeoJSON FeatureCollection.
  function decode(topology, objectName) {
    const obj = topology.objects[objectName];
    if (!obj) return { type: 'FeatureCollection', features: [] };

    // Build arc lookup with delta-decoding
    const arcs = topology.arcs.map((arc) => decodeArc(arc, topology.transform));
    const arcIndex = (i) => {
      const a = i < 0 ? ~i : i;
      const forward = i >= 0;
      const points = arcs[a];
      return forward ? points.slice() : points.slice().reverse();
    };

    function decodeArc(arc, transform) {
      const t = transform || { scale: [1, 1], translate: [0, 0] };
      const x0 = 0, y0 = 0;
      const pts = [];
      let x = 0, y = 0;
      for (let i = 0; i < arc.length; i++) {
        x += arc[i][0];
        y += arc[i][1];
        pts.push([x * t.scale[0] + t.translate[0], y * t.scale[1] + t.translate[1]]);
      }
      return pts;
    }

    function lineStrings(rings) {
      return rings.map((ring) => {
        const coords = [];
        ring.forEach((arcRef, i) => {
          const pts = arcIndex(arcRef);
          if (i === 0) coords.push(...pts);
          else coords.push(...pts.slice(1));
        });
        return coords;
      });
    }

    function feature(geom) {
      const f = { type: 'Feature', properties: geom.properties || {}, geometry: null };
      if (geom.type === 'Polygon') {
        f.geometry = { type: 'Polygon', coordinates: lineStrings(geom.arcs) };
      } else if (geom.type === 'MultiPolygon') {
        f.geometry = {
          type: 'MultiPolygon',
          coordinates: geom.arcs.map((poly) => lineStrings(poly))
        };
      } else if (geom.type === 'LineString') {
        f.geometry = { type: 'LineString', coordinates: arcIndex(geom.arcs) };
      } else if (geom.type === 'MultiLineString') {
        f.geometry = { type: 'MultiLineString', coordinates: geom.arcs.map((arcRef) => arcIndex(arcRef)) };
      } else if (geom.type === 'Point') {
        f.geometry = { type: 'Point', coordinates: geom.coordinates };
      }
      return f;
    }

    const features = (obj.type === 'GeometryCollection' ? obj.geometries : [obj]).map(feature);
    return { type: 'FeatureCollection', features };
  }

  // ---------- Equirectangular projection (lng/lat → x/y) ----------
  function project(lng, lat, width, height) {
    return {
      x: (lng + 180) / 360 * width,
      y: (90 - lat) / 180 * height
    };
  }

  // ---------- Build SVG path from GeoJSON feature ----------
  function featureToPath(feature, width, height) {
    const g = feature.geometry;
    if (!g) return '';
    const coords = g.type === 'Polygon' ? [g.coordinates] : g.coordinates;
    return coords.map((polygon) => {
      return polygon.map((ring) => {
        const pts = ring.map((c) => {
          const p = project(c[0], c[1], width, height);
          return `${p.x.toFixed(2)},${p.y.toFixed(2)}`;
        });
        return 'M' + pts.join(' L') + ' Z';
      }).join(' ');
    }).join(' ');
  }

  // ---------- Map renderer ----------
  class WorldMap {
    constructor(container, opts = {}) {
      this.container = container;
      this.opts = Object.assign({
        width: 1000,
        height: 500,
        showGrid: true,
        showCityLabels: false,
        showCountryLabels: false,
        interactive: true,
        topoUrl: 'data/world-110m.json',
        objectName: 'countries',
        initialEvents: []
      }, opts);
      this.topology = null;
      this.cachedFeatures = null;
      this.markers = [];
      this.svg = null;
      this.markerLayer = null;
      this.landLayer = null;
      this.tooltip = null;
      this._hoverMarker = false;
      this._loaded = false;
      this._pendingEvents = null;
      this.init();
    }

    async init() {
      this._render();
      await this._loadTopology();
    }

    _render() {
      const { width, height } = this.opts;
      const wrap = document.createElement('div');
      wrap.className = 'worldmap-wrap';
      wrap.style.position = 'relative';
      wrap.style.width = '100%';
      wrap.style.overflow = 'hidden';
      wrap.style.background = 'radial-gradient(ellipse at center, rgba(43,108,255,.08), transparent 70%)';
      wrap.style.borderRadius = 'var(--r-md)';
      wrap.style.border = '1px solid var(--glass-border-2)';

      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
      svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
      svg.classList.add('worldmap-svg');
      svg.style.display = 'block';
      svg.style.width = '100%';
      svg.style.height = 'auto';

      // Defs
      const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
      defs.innerHTML = `
        <filter id="wm-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="1.5" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <radialGradient id="wm-ocean" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stop-color="#0e1a4a" stop-opacity="0.5"/>
          <stop offset="100%" stop-color="#0a0e27" stop-opacity="0"/>
        </radialGradient>
        <linearGradient id="wm-land-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#5ee7ff" stop-opacity="0.22"/>
          <stop offset="100%" stop-color="#2b6cff" stop-opacity="0.15"/>
        </linearGradient>
      `;
      svg.appendChild(defs);

      // Ocean
      const ocean = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      ocean.setAttribute('x', 0); ocean.setAttribute('y', 0);
      ocean.setAttribute('width', width); ocean.setAttribute('height', height);
      ocean.setAttribute('fill', 'url(#wm-ocean)');
      svg.appendChild(ocean);

      // Grid
      if (this.opts.showGrid) {
        for (let lng = -180; lng <= 180; lng += 30) {
          const x = (lng + 180) / 360 * width;
          const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
          line.setAttribute('x1', x); line.setAttribute('y1', 0);
          line.setAttribute('x2', x); line.setAttribute('y2', height);
          line.setAttribute('class', 'grid-line');
          svg.appendChild(line);
        }
        for (let lat = -90; lat <= 90; lat += 30) {
          const y = (90 - lat) / 180 * height;
          const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
          line.setAttribute('x1', 0); line.setAttribute('y1', y);
          line.setAttribute('x2', width); line.setAttribute('y2', y);
          line.setAttribute('class', 'grid-line');
          svg.appendChild(line);
        }
        // Equator
        const eq = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        eq.setAttribute('x1', 0); eq.setAttribute('y1', height / 2);
        eq.setAttribute('x2', width); eq.setAttribute('y2', height / 2);
        eq.setAttribute('stroke', 'rgba(94,231,255,.22)');
        eq.setAttribute('stroke-width', '0.5');
        eq.setAttribute('stroke-dasharray', '4 4');
        svg.appendChild(eq);
      }

      // Land layer (filled later when topology loads)
      const landLayer = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      landLayer.setAttribute('class', 'land-layer');
      svg.appendChild(landLayer);

      // Marker layer
      const markerLayer = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      markerLayer.setAttribute('class', 'marker-layer');
      svg.appendChild(markerLayer);

      this.svg = svg;
      this.landLayer = landLayer;
      this.markerLayer = markerLayer;
      wrap.appendChild(svg);
      this.container.innerHTML = '';
      this.container.appendChild(wrap);

      // Tooltip
      this.tooltip = document.createElement('div');
      this.tooltip.className = 'map-tooltip';
      this.tooltip.style.display = 'none';
      wrap.appendChild(this.tooltip);

      // Hover coordinate readout
      if (this.opts.interactive) {
        svg.addEventListener('mousemove', (e) => {
          if (this._hoverMarker) return;
          const rect = svg.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * width;
          const y = ((e.clientY - rect.top) / rect.height) * height;
          const lng = x / width * 360 - 180;
          const lat = 90 - y / height * 180;
          this.tooltip.style.display = 'block';
          this.tooltip.style.left = (e.clientX - rect.left) + 'px';
          this.tooltip.style.top = (e.clientY - rect.top) + 'px';
          this.tooltip.innerHTML = `<strong>${lat.toFixed(2)}°, ${lng.toFixed(2)}°</strong>`;
        });
        svg.addEventListener('mouseleave', () => {
          if (!this._hoverMarker) this.tooltip.style.display = 'none';
        });
      }
    }

    async _loadTopology() {
      // Prefer embedded topology (works on file:// and offline)
      if (global.TP && global.TP.WORLD_TOPOLOGY) {
        this.topology = global.TP.WORLD_TOPOLOGY;
        this._renderLand();
        this._loaded = true;
        if (this._pendingEvents) {
          this.setEvents(this._pendingEvents);
          this._pendingEvents = null;
        }
        return;
      }
      // Fallback: fetch from data file
      try {
        const r = await fetch(this.opts.topoUrl);
        if (!r.ok) throw new Error('HTTP ' + r.status);
        this.topology = await r.json();
        this._renderLand();
        this._loaded = true;
        if (this._pendingEvents) {
          this.setEvents(this._pendingEvents);
          this._pendingEvents = null;
        }
      } catch (e) {
        console.error('[WorldMap] Failed to load topology', e);
        const landLayer = this.container.querySelector('.land-layer');
        if (landLayer) {
          landLayer.innerHTML = '<text x="500" y="250" text-anchor="middle" fill="#ff5e7a" font-size="14">Map data unavailable</text>';
        }
      }
    }

    _renderLand() {
      const { width, height } = this.opts;
      const fc = decode(this.topology, this.opts.objectName);
      this.cachedFeatures = fc;
      this.landLayer.innerHTML = '';

      // Single path for all countries (faster than 177 individual elements)
      let allPaths = '';
      for (const f of fc.features) {
        const d = featureToPath(f, width, height);
        if (d) allPaths += d + ' ';
      }
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', allPaths);
      path.setAttribute('class', 'land');
      path.setAttribute('fill', 'url(#wm-land-grad)');
      path.setAttribute('stroke', 'rgba(94,231,255,.5)');
      path.setAttribute('stroke-width', '0.4');
      path.setAttribute('stroke-linejoin', 'round');
      this.landLayer.appendChild(path);

      // City labels (optional)
      if (this.opts.showCityLabels && global.TP?.WorldMap?.CITIES) {
        const labelLayer = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        for (const c of global.TP.WorldMap.CITIES) {
          const p = project(c.lng, c.lat, width, height);
          const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          dot.setAttribute('cx', p.x); dot.setAttribute('cy', p.y);
          dot.setAttribute('r', 1);
          dot.setAttribute('fill', 'rgba(174, 184, 216, .7)');
          labelLayer.appendChild(dot);
          const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
          label.setAttribute('x', p.x + 3); label.setAttribute('y', p.y + 3);
          label.setAttribute('font-size', '6');
          label.setAttribute('fill', 'rgba(174, 184, 216, .8)');
          label.setAttribute('font-family', 'Inter, sans-serif');
          label.textContent = c.name;
          labelLayer.appendChild(label);
        }
        this.landLayer.appendChild(labelLayer);
      }
    }

    setEvents(events) {
      if (!this._loaded) {
        this._pendingEvents = events;
        return;
      }
      this.markers = events;
      this._renderMarkers();
    }

    addEvent(event) {
      this.markers.push(event);
      if (this.markers.length > 200) this.markers.shift();
      this._renderMarkers();
    }

    clear() {
      this.markers = [];
      this._renderMarkers();
    }

    _renderMarkers() {
      const svgNS = 'http://www.w3.org/2000/svg';
      this.markerLayer.innerHTML = '';
      const { width, height } = this.opts;

      // Use document fragment for batch insert (performance)
      const frag = document.createDocumentFragment();

      for (const evt of this.markers) {
        if (evt.lat == null || evt.lng == null) continue;
        const p = project(evt.lng, evt.lat, width, height);
        const color = evt.color || '#5ee7ff';
        const size = Math.max(2, evt.size || 4);

        const g = document.createElementNS(svgNS, 'g');
        g.setAttribute('class', 'worldmap-marker');
        g.setAttribute('transform', `translate(${p.x},${p.y})`);

        // Pulse ring (SMIL animation)
        if (evt.pulse !== false) {
          const pulse = document.createElementNS(svgNS, 'circle');
          pulse.setAttribute('cx', 0); pulse.setAttribute('cy', 0);
          pulse.setAttribute('r', size);
          pulse.setAttribute('fill', color);
          pulse.setAttribute('fill-opacity', 0.25);
          pulse.setAttribute('stroke', 'none');
          const animR = document.createElementNS(svgNS, 'animate');
          animR.setAttribute('attributeName', 'r');
          animR.setAttribute('values', `${size};${size * 4}`);
          animR.setAttribute('dur', '2.4s');
          animR.setAttribute('repeatCount', 'indefinite');
          const animO = document.createElementNS(svgNS, 'animate');
          animO.setAttribute('attributeName', 'fill-opacity');
          animO.setAttribute('values', '0.5;0');
          animO.setAttribute('dur', '2.4s');
          animO.setAttribute('repeatCount', 'indefinite');
          pulse.appendChild(animR); pulse.appendChild(animO);
          g.appendChild(pulse);
        }

        // Solid dot
        const dot = document.createElementNS(svgNS, 'circle');
        dot.setAttribute('cx', 0); dot.setAttribute('cy', 0);
        dot.setAttribute('r', size * 0.7);
        dot.setAttribute('fill', color);
        dot.setAttribute('stroke', '#fff');
        dot.setAttribute('stroke-width', 0.4);
        dot.setAttribute('filter', 'url(#wm-glow)');
        g.appendChild(dot);

        if (evt.title || evt.text) {
          g.style.cursor = 'pointer';
          g.addEventListener('mouseenter', (e) => {
            this._hoverMarker = true;
            const rect = this.svg.getBoundingClientRect();
            this.tooltip.style.display = 'block';
            this.tooltip.style.left = (e.clientX - rect.left) + 'px';
            this.tooltip.style.top = (e.clientY - rect.top) + 'px';
            const mag = evt.magnitude ? `<strong style="color:${color}">M${evt.magnitude}</strong> · ` : '';
            this.tooltip.innerHTML = `<div>${mag}${escapeHtml(evt.title || '')}</div>` +
              (evt.text ? `<div class="text-xs text-dim" style="margin-top:2px">${escapeHtml(evt.text)}</div>` : '') +
              (evt.time ? `<div class="text-xs text-dim" style="margin-top:2px">${relativeTime(evt.time)}</div>` : '');
          });
          g.addEventListener('mouseleave', () => {
            this._hoverMarker = false;
            this.tooltip.style.display = 'none';
          });
          g.addEventListener('click', () => {
            if (evt.onClick) evt.onClick(evt);
          });
        }

        frag.appendChild(g);
      }
      this.markerLayer.appendChild(frag);
    }
  }

  // Helpers (small, internal)
  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function relativeTime(date) {
    const d = date instanceof Date ? date : new Date(date);
    if (isNaN(d.getTime())) return '—';
    const diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 5) return 'just now';
    if (diff < 60) return Math.floor(diff) + 's ago';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    if (diff < 86400 * 7) return Math.floor(diff / 86400) + 'd ago';
    return d.toLocaleDateString('en-US');
  }

  // Reference cities
  WorldMap.CITIES = [
    { name: 'New York', lat: 40.7, lng: -74.0 },
    { name: 'London', lat: 51.5, lng: -0.1 },
    { name: 'Paris', lat: 48.9, lng: 2.4 },
    { name: 'Tokyo', lat: 35.7, lng: 139.7 },
    { name: 'Beijing', lat: 39.9, lng: 116.4 },
    { name: 'Sydney', lat: -33.9, lng: 151.2 },
    { name: 'Moscow', lat: 55.8, lng: 37.6 },
    { name: 'Dubai', lat: 25.3, lng: 55.3 },
    { name: 'Mumbai', lat: 19.1, lng: 72.9 },
    { name: 'Singapore', lat: 1.3, lng: 103.8 },
    { name: 'São Paulo', lat: -23.5, lng: -46.6 },
    { name: 'Cairo', lat: 30.0, lng: 31.2 },
    { name: 'Lagos', lat: 6.5, lng: 3.4 },
    { name: 'Los Angeles', lat: 34.1, lng: -118.2 },
    { name: 'Mexico City', lat: 19.4, lng: -99.1 },
    { name: 'Buenos Aires', lat: -34.6, lng: -58.4 },
    { name: 'Johannesburg', lat: -26.2, lng: 28.0 },
    { name: 'Istanbul', lat: 41.0, lng: 28.9 }
  ];

  global.TP = global.TP || {};
  global.TP.WorldMap = WorldMap;
  global.TP.topojson = { decode, project, featureToPath };
})(window);
