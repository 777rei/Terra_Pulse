/* ============================================================
   TERRA PULSE — utils.js
   Pure helpers, no side effects. Available as window.TP.utils.
   ============================================================ */
(function (global) {
  'use strict';

  const utils = {};

  /* ---------- DOM helpers ---------- */
  utils.qs = (sel, root = document) => root.querySelector(sel);
  utils.qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  utils.id = (id) => document.getElementById(id);
  utils.el = (tag, attrs = {}, children = []) => {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') node.className = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'dataset') Object.assign(node.dataset, v);
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
      else if (v === true) node.setAttribute(k, '');
      else if (v === false || v == null) { /* skip */ }
      else node.setAttribute(k, v);
    }
    const kids = Array.isArray(children) ? children : [children];
    for (const c of kids) {
      if (c == null) continue;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return node;
  };
  utils.clear = (node) => { while (node && node.firstChild) node.removeChild(node.firstChild); return node; };

  /* ---------- Number / currency formatting ---------- */
  utils.fmt = {
    int(n) { return (n || 0).toLocaleString('en-US'); },
    decimals(n, d = 2) { return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }); },
    compact(n) {
      n = Number(n || 0);
      const abs = Math.abs(n);
      if (abs >= 1e12) return (n / 1e12).toFixed(2) + 'T';
      if (abs >= 1e9) return (n / 1e9).toFixed(2) + 'B';
      if (abs >= 1e6) return (n / 1e6).toFixed(2) + 'M';
      if (abs >= 1e3) return (n / 1e3).toFixed(2) + 'K';
      return String(Math.round(n));
    },
    currency(n, sym = '$', d = 2) {
      if (n == null || isNaN(n)) return '—';
      return sym + Number(n).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
    },
    percent(n, d = 2) {
      if (n == null || isNaN(n)) return '—';
      const sign = n > 0 ? '+' : '';
      return sign + Number(n).toFixed(d) + '%';
    },
    time(date) {
      const d = date instanceof Date ? date : new Date(date);
      if (isNaN(d.getTime())) return '—';
      return d.toLocaleTimeString('en-US', { hour12: false });
    },
    date(date) {
      const d = date instanceof Date ? date : new Date(date);
      if (isNaN(d.getTime())) return '—';
      return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    },
    datetime(date) {
      const d = date instanceof Date ? date : new Date(date);
      if (isNaN(d.getTime())) return '—';
      return d.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false });
    },
    relative(date) {
      const d = date instanceof Date ? date : new Date(date);
      if (isNaN(d.getTime())) return '—';
      const diff = (Date.now() - d.getTime()) / 1000;
      if (diff < 5) return 'just now';
      if (diff < 60) return Math.floor(diff) + 's ago';
      if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
      if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
      if (diff < 86400 * 7) return Math.floor(diff / 86400) + 'd ago';
      return utils.fmt.date(d);
    },
    duration(iso) {
      if (!iso) return '—';
      const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
      if (!m) return '—';
      const h = +m[1] || 0, mi = +m[2] || 0, s = +m[3] || 0;
      if (h) return `${h}:${String(mi).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
      return `${mi}:${String(s).padStart(2, '0')}`;
    }
  };

  /* ---------- Geo helpers ---------- */
  utils.geo = {
    project(lng, lat, width = 1000, height = 500) {
      const x = (lng + 180) / 360 * width;
      const y = (90 - lat) / 180 * height;
      return { x, y };
    },
    unproject(x, y, width = 1000, height = 500) {
      const lng = x / width * 360 - 180;
      const lat = 90 - y / height * 180;
      return { lng, lat };
    },
    haversine(lat1, lng1, lat2, lng2) {
      const R = 6371;
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLng = (lng2 - lng1) * Math.PI / 180;
      const a = Math.sin(dLat / 2) ** 2 +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLng / 2) ** 2;
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    },
    bearing(lat1, lng1, lat2, lng2) {
      const dLng = (lng2 - lng1) * Math.PI / 180;
      const y = Math.sin(dLng) * Math.cos(lat2 * Math.PI / 180);
      const x = Math.cos(lat1 * Math.PI / 180) * Math.sin(lat2 * Math.PI / 180) -
                Math.sin(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.cos(dLng);
      return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
    }
  };

  /* ---------- Color helpers ---------- */
  utils.color = {
    temp(c) {
      if (c == null || isNaN(c)) return '#888';
      if (c < -10) return '#5ec3ff';
      if (c < 0) return '#7fb6ff';
      if (c < 10) return '#9fd6ff';
      if (c < 18) return '#3ee68a';
      if (c < 25) return '#ffcf5e';
      if (c < 32) return '#ff9c5e';
      return '#ff5e7a';
    },
    aqi(v) {
      if (v == null || isNaN(v)) return ['#888', '—'];
      if (v <= 50) return ['#3ee68a', 'Good'];
      if (v <= 100) return ['#ffcf5e', 'Moderate'];
      if (v <= 150) return ['#ff9c5e', 'Unhealthy (Sensitive)'];
      if (v <= 200) return ['#ff5e7a', 'Unhealthy'];
      if (v <= 300) return ['#b07bff', 'Very Unhealthy'];
      return ['#7a1f3d', 'Hazardous'];
    },
    mag(m) {
      if (m == null || isNaN(m)) return 'mag-low';
      if (m < 3) return 'mag-low';
      if (m < 5) return 'mag-mid';
      return 'mag-high';
    },
    changeColor(n) {
      if (n == null || isNaN(n)) return '';
      return n >= 0 ? 'up' : 'down';
    },
    // Heatmap color based on % change (-5..+5 range)
    heatColor(pct) {
      if (pct == null || isNaN(pct)) return '#2a3358';
      const clamped = Math.max(-8, Math.min(8, pct));
      const intensity = Math.abs(clamped) / 8;
      if (clamped >= 0) {
        const r = Math.round(62 + (255 - 62) * intensity * 0.6);
        const g = Math.round(230 - (230 - 94) * intensity * 0.4);
        const b = Math.round(138 - (138 - 122) * intensity * 0.5);
        return `rgb(${r}, ${g}, ${b})`;
      } else {
        const r = Math.round(255 - (255 - 255) * intensity * 0.2);
        const g = Math.round(94 + (94 - 30) * intensity * 0.5);
        const b = Math.round(122 - (122 - 60) * intensity * 0.4);
        return `rgb(${r}, ${g}, ${b})`;
      }
    },
    heatOpacity(pct) {
      if (pct == null || isNaN(pct)) return 0.4;
      return 0.3 + Math.min(0.65, Math.abs(pct) / 8 * 0.65);
    }
  };

  /* ---------- Misc helpers ---------- */
  utils.debounce = (fn, wait = 200) => {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  };
  utils.throttle = (fn, wait = 200) => {
    let last = 0, t;
    return function (...args) {
      const now = Date.now();
      const remain = wait - (now - last);
      if (remain <= 0) {
        last = now;
        fn.apply(this, args);
      } else {
        clearTimeout(t);
        t = setTimeout(() => {
          last = Date.now();
          fn.apply(this, args);
        }, remain);
      }
    };
  };
  utils.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  utils.random = (min, max) => Math.random() * (max - min) + min;
  utils.randomInt = (min, max) => Math.floor(utils.random(min, max + 1));
  utils.pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  utils.uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
  utils.escapeHtml = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
  utils.truncate = (s, n = 100) => {
    s = String(s || '');
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  };
  utils.clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  utils.hash = (s) => {
    let h = 0;
    for (let i = 0; i < s.length; i++) {
      h = ((h << 5) - h) + s.charCodeAt(i);
      h |= 0;
    }
    return Math.abs(h);
  };

  /* ---------- Async helpers ---------- */
  utils.timeout = (ms, promise) => Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), ms))
  ]);
  utils.retry = async (fn, retries = 3, delay = 500) => {
    let lastErr;
    for (let i = 0; i < retries; i++) {
      try { return await fn(); }
      catch (e) { lastErr = e; await utils.sleep(delay * (i + 1)); }
    }
    throw lastErr;
  };

  /* ---------- Event bus ---------- */
  utils.EventBus = class EventBus {
    constructor() { this.listeners = new Map(); }
    on(event, fn) {
      if (!this.listeners.has(event)) this.listeners.set(event, new Set());
      this.listeners.get(event).add(fn);
      return () => this.off(event, fn);
    }
    off(event, fn) {
      const set = this.listeners.get(event);
      if (set) set.delete(fn);
    }
    emit(event, payload) {
      const set = this.listeners.get(event);
      if (set) set.forEach((fn) => { try { fn(payload); } catch (e) { console.error(e); } });
    }
  };

  /* ---------- Number abbreviate ---------- */
  utils.abbreviate = (n) => utils.fmt.compact(n);

  /* ---------- Sparkline ---------- */
  utils.sparkline = (values, width = 100, height = 24) => {
    if (!values || values.length < 2) return '';
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min || 1;
    const step = width / (values.length - 1);
    return values.map((v, i) => {
      const x = i * step;
      const y = height - ((v - min) / range) * (height - 2) - 1;
      return `${i === 0 ? '' : ' '}${x.toFixed(1)},${y.toFixed(1)}`;
    }).join('');
  };

  /* ---------- Animated number counter ---------- */
  utils.animateNumber = (el, from, to, dur = 600, fmt = (n) => Math.round(n).toLocaleString()) => {
    const start = performance.now();
    const diff = to - from;
    const step = (now) => {
      const t = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = fmt(from + diff * eased);
      if (t < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  utils.exists = async (url) => {
    try {
      const r = await fetch(url, { method: 'HEAD' });
      return r.ok;
    } catch { return false; }
  };

  global.TP = global.TP || {};
  global.TP.utils = utils;
})(window);
