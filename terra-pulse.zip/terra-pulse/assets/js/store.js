/* ============================================================
   TERRA PULSE — store.js
   Central reactive store + persistence + event bus.
   ============================================================ */
(function (global) {
  'use strict';

  const { EventBus, debounce } = global.TP.utils;
  const bus = new EventBus();

  const LS_KEY = 'terra-pulse:state:v1';

  const defaults = {
    theme: 'dark',
    sidebarCollapsed: false,
    units: 'metric',
    temperatureUnit: 'C',
    refreshInterval: 30,
    autoRefresh: true,
    soundEnabled: false,
    notificationsEnabled: true,
    homeLocation: null,
    favoriteCities: ['London', 'New York', 'Tokyo', 'Sydney', 'Dubai'],
    favoriteCoins: ['bitcoin', 'ethereum', 'solana', 'ripple', 'cardano'],
    favoriteForex: ['USD', 'EUR', 'GBP', 'JPY', 'CNY', 'INR'],
    newsCategories: ['world', 'business', 'technology', 'science'],
    language: 'en',
    dashboardWidgets: ['population', 'temp', 'crypto', 'quakes', 'iss', 'internet'],
    seenAlerts: [],
    onboarded: false
  };

  let state = loadState();

  function loadState() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) return { ...defaults, ...JSON.parse(raw) };
    } catch (e) {}
    return { ...defaults };
  }

  const persist = debounce(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(state));
    } catch (e) {}
  }, 200);

  const store = {
    get(key) { return key == null ? state : state[key]; },
    set(key, value) {
      const prev = state[key];
      state[key] = value;
      persist();
      bus.emit('change:' + key, value, prev);
      bus.emit('change', { key, value, prev });
      return value;
    },
    patch(patch) {
      const prev = { ...state };
      state = { ...state, ...patch };
      persist();
      Object.keys(patch).forEach((k) => bus.emit('change:' + k, state[k], prev[k]));
      bus.emit('change', { patch, prev });
    },
    reset() {
      state = { ...defaults };
      persist();
      bus.emit('reset');
      bus.emit('change', { patch: state, prev: {} });
    },
    on(event, fn) { return bus.on(event, fn); },
    off(event, fn) { bus.off(event, fn); },
    emit(event, payload) { bus.emit(event, payload); },

    cache: {
      _mem: new Map(),
      async get(key, maxAge = 60_000) {
        const now = Date.now();
        if (this._mem.has(key)) {
          const { ts, data } = this._mem.get(key);
          if (now - ts < maxAge) return data;
        }
        try {
          const raw = localStorage.getItem('tp:cache:' + key);
          if (raw) {
            const { ts, data } = JSON.parse(raw);
            if (now - ts < maxAge) {
              this._mem.set(key, { ts, data });
              return data;
            }
          }
        } catch {}
        return null;
      },
      set(key, data) {
        const ts = Date.now();
        this._mem.set(key, { ts, data });
        try {
          localStorage.setItem('tp:cache:' + key, JSON.stringify({ ts, data }));
        } catch (e) {
          this._prune();
        }
      },
      _prune() {
        const keys = Object.keys(localStorage).filter((k) => k.startsWith('tp:cache:'));
        keys.slice(0, Math.ceil(keys.length / 2)).forEach((k) => localStorage.removeItem(k));
      },
      clear() {
        this._mem.clear();
        Object.keys(localStorage).filter((k) => k.startsWith('tp:cache:')).forEach((k) => localStorage.removeItem(k));
      }
    },

    notifications: [],
    addNotification(n) {
      const note = {
        id: global.TP.utils.uuid(),
        ts: Date.now(),
        type: n.type || 'info',
        title: n.title || '',
        message: n.message || '',
        ...n
      };
      this.notifications.unshift(note);
      if (this.notifications.length > 50) this.notifications.pop();
      bus.emit('notification', note);
      return note;
    },
    clearNotifications() {
      this.notifications = [];
      bus.emit('notifications:clear');
    }
  };

  global.TP = global.TP || {};
  global.TP.store = store;
})(window);
