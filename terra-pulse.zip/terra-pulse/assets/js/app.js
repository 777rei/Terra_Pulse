/* ============================================================
   TERRA PULSE — app.js v2.0
   Main orchestrator: routing, theming (8 themes), search,
   notifications, toasts, sidebar, topbar, PWA registration,
   icon hydration, command palette, keyboard shortcuts.
   ============================================================ */
(function (global) {
  'use strict';

  const { utils, store, icons } = global.TP;
  const app = {
    deferredPrompt: null,
    currentView: 'overview',
    initializedViews: new Set(),
    notifPanelOpen: false,
    themeSelectorOpen: false,
    cmdPaletteOpen: false,
    kbdOverlayOpen: false
  };

  const THEMES = [
    { id: 'dark', name: 'Dark', icon: 'moon', colors: ['#0a0e27', '#5ee7ff', '#b07bff'] },
    { id: 'light', name: 'Light', icon: 'sun', colors: ['#ffffff', '#2b6cff', '#5ee7ff'] },
    { id: 'amoled', name: 'AMOLED', icon: 'contrast', colors: ['#000000', '#00ffe5', '#b06bff'] },
    { id: 'sunset', name: 'Sunset', icon: 'sun', colors: ['#1a0a14', '#ff8a5e', '#ffd75e'] },
    { id: 'ocean', name: 'Ocean', icon: 'wave', colors: ['#001a1f', '#4dd0e1', '#80deea'] },
    { id: 'forest', name: 'Forest', icon: 'tree', colors: ['#0a1a0e', '#66dd88', '#a5d6a7'] },
    { id: 'midnight', name: 'Midnight', icon: 'moon', colors: ['#0a0820', '#c084fc', '#d8b4fe'] },
    { id: 'neon', name: 'Neon', icon: 'sparkles', colors: ['#050010', '#ff00ff', '#00ffff'] }
  ];

  function init() {
    injectLogos();
    applyStoredSettings();
    hydrateIcons();
    registerServiceWorker();
    wireTopbar();
    wireSidebar();
    wireSearch();
    wireNotifs();
    wireKeyboard();
    wireOnlineStatus();
    wireInstallPrompt();
    wireCommandPalette();
    wireKbdOverlay();
    startClock();
    route();
    window.addEventListener('hashchange', route);
    setTimeout(hideSplash, 700);
  }

  function injectLogos() {
    const brandLogo = utils.id('brandLogo');
    if (brandLogo) brandLogo.innerHTML = icons.LOGO_SVG;
    const splashLogo = utils.id('splashLogo');
    if (splashLogo) splashLogo.innerHTML = icons.LOGO_SVG;
  }

  function hydrateIcons(root = document) {
    icons.hydrate(root);
  }

  function applyStoredSettings() {
    const s = store.get();
    const theme = s.theme || 'dark';
    document.body.className = 'theme-' + theme;
    if (s.sidebarCollapsed) document.body.classList.add('sidebar-collapsed');
    updateThemeIcon(theme);
  }

  function updateThemeIcon(theme) {
    const themeData = THEMES.find((t) => t.id === theme) || THEMES[0];
    const ic = utils.id('themeIcon');
    if (ic) ic.setAttribute('data-icon', themeData.icon);
    // Re-hydrate just that icon
    if (ic) icons.hydrate(ic.parentElement);
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch((e) => {
        console.warn('[SW] Registration failed', e);
      });
    }
  }

  function wireTopbar() {
    utils.id('refreshBtn').addEventListener('click', () => {
      const v = global.TP.views[app.currentView];
      if (v && typeof v.refresh === 'function') {
        v.refresh();
        toast('Refreshing ' + app.currentView + '…', 'info');
      } else {
        toast('Nothing to refresh', 'info');
      }
    });

    // Theme button — cycle through themes
    utils.id('themeBtn').addEventListener('click', (e) => {
      e.stopPropagation();
      toggleThemeSelector();
    });

    utils.id('cmdBtn').addEventListener('click', () => openCmdPalette());

    utils.id('fullscreenBtn').addEventListener('click', () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.();
      } else {
        document.exitFullscreen?.();
      }
    });
  }

  function toggleThemeSelector() {
    app.themeSelectorOpen = !app.themeSelectorOpen;
    if (app.themeSelectorOpen) {
      showThemeSelector();
    } else {
      hideThemeSelector();
    }
  }

  function showThemeSelector() {
    let panel = utils.id('themeSelector');
    if (panel) panel.remove();
    panel = utils.el('div', { id: 'themeSelector', class: 'theme-selector' });
    const cur = store.get('theme') || 'dark';
    panel.innerHTML = THEMES.map((t) => `
      <div class="theme-option ${t.id === cur ? 'active' : ''}" data-theme="${t.id}">
        <div class="theme-swatch">
          ${t.colors.map((c) => `<span style="background:${c}"></span>`).join('')}
        </div>
        <span class="theme-name">${t.name}</span>
        ${t.id === cur ? '<span class="badge-count" style="background:var(--accent); color:var(--bg-0)">✓</span>' : ''}
      </div>
    `).join('');
    document.body.appendChild(panel);
    panel.querySelectorAll('.theme-option').forEach((opt) => {
      opt.addEventListener('click', () => {
        setTheme(opt.dataset.theme);
        hideThemeSelector();
      });
    });
    hydrateIcons(panel);
    // Close on outside click
    setTimeout(() => {
      document.addEventListener('click', closeThemeSelectorOutside);
    }, 0);
  }

  function hideThemeSelector() {
    const panel = utils.id('themeSelector');
    if (panel) panel.remove();
    app.themeSelectorOpen = false;
    document.removeEventListener('click', closeThemeSelectorOutside);
  }

  function closeThemeSelectorOutside(e) {
    const panel = utils.id('themeSelector');
    const btn = utils.id('themeBtn');
    if (panel && !panel.contains(e.target) && !btn.contains(e.target)) {
      hideThemeSelector();
    }
  }

  function setTheme(theme) {
    store.set('theme', theme);
    document.body.className = 'theme-' + theme + (store.get('sidebarCollapsed') ? ' sidebar-collapsed' : '');
    updateThemeIcon(theme);
    app.toast('Theme: ' + (THEMES.find((t) => t.id === theme)?.name || theme), 'success');
    // Update theme-color meta
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      const themeData = THEMES.find((t) => t.id === theme);
      if (themeData) meta.setAttribute('content', themeData.colors[0]);
    }
  }

  function cycleTheme() {
    const cur = store.get('theme') || 'dark';
    const idx = THEMES.findIndex((t) => t.id === cur);
    const next = THEMES[(idx + 1) % THEMES.length];
    setTheme(next.id);
  }

  function wireSidebar() {
    utils.id('sidebarToggle').addEventListener('click', () => {
      const collapsed = !document.body.classList.contains('sidebar-collapsed');
      document.body.classList.toggle('sidebar-collapsed', collapsed);
      store.set('sidebarCollapsed', collapsed);
    });

    utils.id('menuBtn').addEventListener('click', () => {
      document.body.classList.toggle('sidebar-open');
    });

    document.addEventListener('click', (e) => {
      if (window.innerWidth > 768) return;
      const sidebar = utils.id('sidebar');
      const menuBtn = utils.id('menuBtn');
      if (document.body.classList.contains('sidebar-open') &&
          !sidebar.contains(e.target) &&
          !menuBtn.contains(e.target)) {
        document.body.classList.remove('sidebar-open');
      }
    });
  }

  function route() {
    const hash = (location.hash || '#overview').slice(1);
    const viewName = hash || 'overview';

    // Handle special pseudo-views
    if (viewName === 'command') {
      openCmdPalette();
      location.hash = app.currentView || 'overview';
      return;
    }
    if (viewName === 'shortcuts') {
      openKbdOverlay();
      location.hash = app.currentView || 'overview';
      return;
    }

    if (!global.TP.views[viewName]) {
      console.warn('Unknown view:', viewName);
      return;
    }

    const cur = utils.qs('.view.active');
    if (cur) cur.classList.remove('active');
    const curNav = utils.qs('.nav-item.active');
    if (curNav) curNav.classList.remove('active');

    const viewEl = utils.id('view-' + viewName);
    if (viewEl) viewEl.classList.add('active');
    const navEl = utils.qs(`.nav-item[data-view="${viewName}"]`);
    if (navEl) navEl.classList.add('active');

    document.body.dataset.view = viewName;
    app.currentView = viewName;
    document.body.classList.remove('sidebar-open');

    // Update footView label
    const footView = utils.id('footView');
    if (footView) {
      const navText = navEl?.querySelector('.nav-txt')?.textContent || viewName;
      footView.textContent = navText;
    }

    if (!app.initializedViews.has(viewName)) {
      const v = global.TP.views[viewName];
      if (v && typeof v.init === 'function') {
        try {
          v.init();
          app.initializedViews.add(viewName);
          setTimeout(() => hydrateIcons(viewEl), 50);
        } catch (e) {
          console.error('[View init]', viewName, e);
        }
      }
    }

    utils.id('views')?.scrollTo?.(0, 0);
    window.scrollTo(0, 0);
  }

  function wireSearch() {
    const input = utils.id('globalSearch');
    const results = utils.id('searchResults');
    if (!input) return;

    let activeIdx = -1;
    let currentItems = [];

    input.addEventListener('focus', () => {
      if (input.value.trim().length > 0) results.hidden = false;
    });

    input.addEventListener('input', utils.debounce(async () => {
      const q = input.value.trim();
      if (q.length < 1) { results.hidden = true; return; }
      currentItems = [];
      activeIdx = -1;
      const items = [];

      const navMatches = utils.qsa('.nav-item').filter((n) => {
        const txt = n.querySelector('.nav-txt')?.textContent.toLowerCase() || '';
        return txt.includes(q.toLowerCase());
      }).slice(0, 5);
      navMatches.forEach((n) => {
        items.push({
          type: 'view',
          icon: 'compass',
          title: n.querySelector('.nav-txt')?.textContent || '',
          sub: 'View',
          onClick: () => { location.hash = n.dataset.view; results.hidden = true; input.value = ''; }
        });
      });

      if (q.length >= 2) {
        try {
          const geo = await global.TP.api.geocode.search(q);
          (geo?.results || []).slice(0, 5).forEach((r) => {
            items.push({
              type: 'city',
              icon: 'location',
              title: r.name,
              sub: [r.admin1, r.country].filter(Boolean).join(', '),
              onClick: () => {
                location.hash = 'weather';
                results.hidden = true;
                input.value = '';
                setTimeout(() => {
                  if (global.TP.views.weather?.showLocationDetail) {
                    global.TP.views.weather.showLocationDetail(r);
                  }
                }, 400);
              }
            });
          });
        } catch {}
      }

      if (q.length >= 2) {
        try {
          const markets = await global.TP.api.crypto.markets(50);
          const coinMatches = markets.filter((c) =>
            c.name?.toLowerCase().includes(q.toLowerCase()) ||
            c.symbol?.toLowerCase().includes(q.toLowerCase())
          ).slice(0, 5);
          coinMatches.forEach((c) => {
            items.push({
              type: 'coin',
              icon: 'bitcoin',
              title: c.name + ' (' + (c.symbol || '').toUpperCase() + ')',
              sub: '$' + utils.fmt.decimals(c.current_price, c.current_price < 1 ? 6 : 2),
              onClick: () => {
                location.hash = 'crypto';
                results.hidden = true;
                input.value = '';
                toast('Loaded ' + c.name, 'info');
              }
            });
          });
        } catch {}
      }

      currentItems = items;
      renderSearchResults(items);
    }, 250));

    function renderSearchResults(items) {
      if (!items.length) {
        results.innerHTML = '<div class="sr-group"><div class="sr-label">No results</div></div>';
        results.hidden = false;
        return;
      }
      const groups = {};
      for (const it of items) {
        if (!groups[it.type]) groups[it.type] = [];
        groups[it.type].push(it);
      }
      const labels = { view: 'Views', city: 'Cities', coin: 'Crypto' };
      results.innerHTML = Object.entries(groups).map(([type, arr]) => `
        <div class="sr-group">
          <div class="sr-label">${labels[type] || type}</div>
          ${arr.map((it) => {
            const idx = items.indexOf(it);
            return `<div class="sr-item" data-idx="${idx}"><span class="sr-ico">${icons.makeIcon(it.icon, 16)}</span><span class="sr-title">${utils.escapeHtml(it.title)}</span><span class="sr-sub">${utils.escapeHtml(it.sub || '')}</span></div>`;
          }).join('')}
        </div>
      `).join('');
      results.hidden = false;
      hydrateIcons(results);
      results.querySelectorAll('.sr-item').forEach((el) => {
        el.addEventListener('click', () => {
          const idx = parseInt(el.dataset.idx, 10);
          if (currentItems[idx]?.onClick) currentItems[idx].onClick();
        });
        el.addEventListener('mouseenter', () => {
          activeIdx = parseInt(el.dataset.idx, 10);
          updateActive();
        });
      });
    }

    function updateActive() {
      results.querySelectorAll('.sr-item').forEach((el) => {
        el.classList.toggle('active', parseInt(el.dataset.idx, 10) === activeIdx);
      });
    }

    input.addEventListener('keydown', (e) => {
      if (results.hidden) return;
      if (e.key === 'ArrowDown') {
        activeIdx = Math.min(activeIdx + 1, currentItems.length - 1);
        updateActive();
        e.preventDefault();
      } else if (e.key === 'ArrowUp') {
        activeIdx = Math.max(activeIdx - 1, 0);
        updateActive();
        e.preventDefault();
      } else if (e.key === 'Enter' && activeIdx >= 0) {
        currentItems[activeIdx]?.onClick();
        results.hidden = true;
        input.value = '';
      } else if (e.key === 'Escape') {
        results.hidden = true;
        input.blur();
      }
    });

    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !results.contains(e.target)) {
        results.hidden = true;
      }
    });
  }

  function wireNotifs() {
    const btn = utils.id('notifBtn');
    const panel = utils.id('notifPanel');
    const list = utils.id('notifList');
    const badge = utils.id('notifBadge');
    const clearBtn = utils.id('clearNotif');

    btn.addEventListener('click', () => {
      app.notifPanelOpen = !app.notifPanelOpen;
      panel.hidden = !app.notifPanelOpen;
      if (app.notifPanelOpen) renderNotifList();
    });

    clearBtn.addEventListener('click', () => {
      store.clearNotifications();
      renderNotifList();
      updateBadge();
    });

    document.addEventListener('click', (e) => {
      if (app.notifPanelOpen && !btn.contains(e.target) && !panel.contains(e.target)) {
        app.notifPanelOpen = false;
        panel.hidden = true;
      }
    });

    function renderNotifList() {
      const notifs = store.notifications;
      if (!notifs.length) {
        list.innerHTML = '<li class="empty-state text-sm">No notifications</li>';
        return;
      }
      list.innerHTML = notifs.map((n) => `
        <li class="notif-item" style="border-left:3px solid ${n.type === 'error' ? '#ff5e7a' : n.type === 'success' ? '#3ee68a' : n.type === 'warn' ? '#ffcf5e' : '#5ec3ff'}">
          <div style="font-weight:600; font-size:12.5px">${utils.escapeHtml(n.title)}</div>
          ${n.message ? `<div class="text-xs text-dim" style="margin-top:2px">${utils.escapeHtml(n.message)}</div>` : ''}
          <div class="notif-time">${utils.fmt.relative(n.ts)}</div>
        </li>
      `).join('');
    }

    function updateBadge() {
      const n = store.notifications.length;
      if (n > 0) {
        badge.hidden = false;
        badge.textContent = n > 99 ? '99+' : n;
      } else {
        badge.hidden = true;
      }
    }

    store.on('notification', () => {
      updateBadge();
      if (app.notifPanelOpen) renderNotifList();
    });
    store.on('notifications:clear', () => {
      updateBadge();
      if (app.notifPanelOpen) renderNotifList();
    });

    updateBadge();
  }

  function wireKeyboard() {
    document.addEventListener('keydown', (e) => {
      // "/" to focus search
      if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
        e.preventDefault();
        utils.id('globalSearch').focus();
      }
      // Ctrl+K opens command palette
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        openCmdPalette();
      }
      // Ctrl+/ opens keyboard shortcuts
      if ((e.ctrlKey || e.metaKey) && e.key === '/') {
        e.preventDefault();
        openKbdOverlay();
      }
      // Ctrl+; cycles theme
      if ((e.ctrlKey || e.metaKey) && e.key === ';') {
        e.preventDefault();
        cycleTheme();
      }
      // Esc closes overlays
      if (e.key === 'Escape') {
        utils.id('searchResults').hidden = true;
        if (app.themeSelectorOpen) hideThemeSelector();
        if (app.cmdPaletteOpen) closeCmdPalette();
        if (app.kbdOverlayOpen) closeKbdOverlay();
      }
      // g + letter = quick nav
      if (e.key === 'g' && document.activeElement.tagName !== 'INPUT') {
        const handler = (ev) => {
          document.removeEventListener('keydown', handler);
          const map = { o: 'overview', m: 'worldmap', c: 'crypto', f: 'forex', s: 'stocks', n: 'news', w: 'weather', e: 'earthquakes', p: 'space' };
          if (map[ev.key]) location.hash = map[ev.key];
        };
        document.addEventListener('keydown', handler);
        setTimeout(() => document.removeEventListener('keydown', handler), 1000);
      }
    });
  }

  function wireOnlineStatus() {
    const pill = utils.id('netStatus');
    const updateStatus = () => {
      const text = pill.querySelector('.status-text');
      const dot = pill.querySelector('.dot');
      if (navigator.onLine) {
        text.textContent = 'Online';
        dot.className = 'dot dot-ok';
      } else {
        text.textContent = 'Offline';
        dot.className = 'dot dot-bad';
      }
    };
    window.addEventListener('online', () => {
      updateStatus();
      toast('Back online', 'success');
    });
    window.addEventListener('offline', () => {
      updateStatus();
      toast('You are offline. Showing cached data.', 'warn');
    });
    updateStatus();
  }

  function wireInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      app.deferredPrompt = e;
    });
    window.addEventListener('appinstalled', () => {
      app.deferredPrompt = null;
      toast('Installed! Open from your home screen.', 'success');
    });
  }

  function startClock() {
    const update = () => {
      const el = utils.id('clockMini');
      if (el) el.textContent = new Date().toLocaleTimeString('en-US', { hour12: false });
      const updEl = utils.id('updateStatus');
      if (updEl) updEl.textContent = new Date().toLocaleTimeString('en-US', { hour12: false });
      const foot = utils.id('footStats');
      if (foot) {
        const pop = global.TP.api?.population?.snapshot?.();
        if (pop) foot.textContent = 'Pop ' + utils.fmt.compact(pop.total);
      }
      const lat = utils.id('footLatency');
      if (lat) lat.textContent = app.initializedViews.size + ' views active';
    };
    update();
    setInterval(update, 1000);
  }

  /* ---------- Command palette ---------- */
  function wireCommandPalette() {
    utils.id('openCmdNav').addEventListener('click', (e) => {
      e.preventDefault();
      openCmdPalette();
    });
  }

  function openCmdPalette() {
    if (app.cmdPaletteOpen) return;
    app.cmdPaletteOpen = true;

    const overlay = utils.el('div', { id: 'cmdOverlay', class: 'cmd-palette' });
    overlay.innerHTML = `
      <input type="text" class="cmd-input" id="cmdInput" placeholder="Type a command or search views…" autocomplete="off" />
      <div class="cmd-list" id="cmdList"></div>
    `;
    document.body.appendChild(overlay);
    hydrateIcons(overlay);

    const input = utils.id('cmdInput');
    const list = utils.id('cmdList');
    const commands = buildCommands();
    let activeIdx = 0;

    function render(filter) {
      const f = (filter || '').toLowerCase();
      const filtered = commands.filter((c) =>
        c.title.toLowerCase().includes(f) || c.category.toLowerCase().includes(f)
      ).slice(0, 12);
      activeIdx = 0;
      list.innerHTML = filtered.map((c, i) => `
        <div class="cmd-item ${i === 0 ? 'active' : ''}" data-idx="${i}">
          <span class="cmd-ico">${icons.makeIcon(c.icon, 18)}</span>
          <span class="cmd-title">${utils.escapeHtml(c.title)}</span>
          <span class="cmd-cat">${utils.escapeHtml(c.category)}</span>
        </div>
      `).join('') || '<div class="empty-state text-sm">No commands</div>';
      hydrateIcons(list);
      list.querySelectorAll('.cmd-item').forEach((el, i) => {
        el.addEventListener('click', () => {
          filtered[i]?.action();
          closeCmdPalette();
        });
        el.addEventListener('mouseenter', () => {
          activeIdx = i;
          updateActive();
        });
      });
      // Save filtered for keyboard nav
      list.dataset.filtered = JSON.stringify(filtered.map((c) => c.id));
    }

    function updateActive() {
      list.querySelectorAll('.cmd-item').forEach((el, i) => {
        el.classList.toggle('active', i === activeIdx);
      });
    }

    input.addEventListener('input', () => render(input.value));
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') {
        activeIdx = Math.min(activeIdx + 1, list.querySelectorAll('.cmd-item').length - 1);
        updateActive();
        e.preventDefault();
      } else if (e.key === 'ArrowUp') {
        activeIdx = Math.max(activeIdx - 1, 0);
        updateActive();
        e.preventDefault();
      } else if (e.key === 'Enter') {
        const items = list.querySelectorAll('.cmd-item');
        if (items[activeIdx]) items[activeIdx].click();
      } else if (e.key === 'Escape') {
        closeCmdPalette();
      }
    });

    render('');
    setTimeout(() => input.focus(), 50);

    // Close on outside click
    setTimeout(() => {
      document.addEventListener('click', closeCmdOutside);
    }, 0);
  }

  function closeCmdOutside(e) {
    const overlay = utils.id('cmdOverlay');
    if (overlay && !overlay.contains(e.target)) {
      closeCmdPalette();
    }
  }

  function closeCmdPalette() {
    const overlay = utils.id('cmdOverlay');
    if (overlay) overlay.remove();
    app.cmdPaletteOpen = false;
    document.removeEventListener('click', closeCmdOutside);
  }

  function buildCommands() {
    const cmds = [
      { id: 'overview', title: 'Overview', icon: 'overview', category: 'View', action: () => location.hash = 'overview' },
      { id: 'worldmap', title: 'World Map', icon: 'globe', category: 'View', action: () => location.hash = 'worldmap' },
      { id: 'clocks', title: 'World Clocks', icon: 'clock', category: 'View', action: () => location.hash = 'clocks' },
      { id: 'weather', title: 'Weather', icon: 'sunCloud', category: 'View', action: () => location.hash = 'weather' },
      { id: 'airquality', title: 'Air Quality', icon: 'air', category: 'View', action: () => location.hash = 'airquality' },
      { id: 'earthquakes', title: 'Earthquakes', icon: 'earthquake', category: 'View', action: () => location.hash = 'earthquakes' },
      { id: 'climate', title: 'Climate', icon: 'thermometer', category: 'View', action: () => location.hash = 'climate' },
      { id: 'marine', title: 'Marine', icon: 'wave', category: 'View', action: () => location.hash = 'marine' },
      { id: 'crypto', title: 'Crypto Markets', icon: 'bitcoin', category: 'View', action: () => location.hash = 'crypto' },
      { id: 'stocks', title: 'Stock Market', icon: 'chartUp', category: 'View', action: () => location.hash = 'stocks' },
      { id: 'forex', title: 'Forex', icon: 'exchange', category: 'View', action: () => location.hash = 'forex' },
      { id: 'commodities', title: 'Commodities', icon: 'oil', category: 'View', action: () => location.hash = 'commodities' },
      { id: 'calculators', title: 'Calculators', icon: 'calculator', category: 'View', action: () => location.hash = 'calculators' },
      { id: 'news', title: 'World News', icon: 'news', category: 'View', action: () => location.hash = 'news' },
      { id: 'trends', title: 'Trends', icon: 'trending', category: 'View', action: () => location.hash = 'trends' },
      { id: 'wikipedia', title: 'Wikipedia Pulse', icon: 'book', category: 'View', action: () => location.hash = 'wikipedia' },
      { id: 'space', title: 'Space & ISS', icon: 'rocket', category: 'View', action: () => location.hash = 'space' },
      { id: 'astronomy', title: 'Astronomy', icon: 'moon', category: 'View', action: () => location.hash = 'astronomy' },
      { id: 'planets', title: 'Solar System', icon: 'planet', category: 'View', action: () => location.hash = 'planets' },
      { id: 'launches', title: 'Launches', icon: 'satellite', category: 'View', action: () => location.hash = 'launches' },
      { id: 'network', title: 'Internet Stats', icon: 'network', category: 'View', action: () => location.hash = 'network' },
      { id: 'github', title: 'GitHub Trending', icon: 'github', category: 'View', action: () => location.hash = 'github' },
      { id: 'hackernews', title: 'Hacker News', icon: 'news', category: 'View', action: () => location.hash = 'hackernews' },
      { id: 'population', title: 'Population', icon: 'users', category: 'View', action: () => location.hash = 'population' },
      { id: 'holidays', title: 'Holidays', icon: 'calendar', category: 'View', action: () => location.hash = 'holidays' },
      { id: 'health', title: 'World Health', icon: 'medical', category: 'View', action: () => location.hash = 'health' },
      { id: 'countries', title: 'Countries', icon: 'flag', category: 'View', action: () => location.hash = 'countries' },
      { id: 'alerts', title: 'Alerts', icon: 'alert', category: 'View', action: () => location.hash = 'alerts' },
      { id: 'settings', title: 'Settings', icon: 'settings', category: 'View', action: () => location.hash = 'settings' },
      { id: 'about', title: 'About', icon: 'info', category: 'View', action: () => location.hash = 'about' },
      { id: 'shortcuts', title: 'Keyboard Shortcuts', icon: 'keyboard', category: 'Help', action: () => openKbdOverlay() },
      { id: 'theme-dark', title: 'Dark Theme', icon: 'moon', category: 'Theme', action: () => setTheme('dark') },
      { id: 'theme-light', title: 'Light Theme', icon: 'sun', category: 'Theme', action: () => setTheme('light') },
      { id: 'theme-amoled', title: 'AMOLED Theme', icon: 'contrast', category: 'Theme', action: () => setTheme('amoled') },
      { id: 'theme-sunset', title: 'Sunset Theme', icon: 'sun', category: 'Theme', action: () => setTheme('sunset') },
      { id: 'theme-ocean', title: 'Ocean Theme', icon: 'wave', category: 'Theme', action: () => setTheme('ocean') },
      { id: 'theme-forest', title: 'Forest Theme', icon: 'tree', category: 'Theme', action: () => setTheme('forest') },
      { id: 'theme-midnight', title: 'Midnight Theme', icon: 'moon', category: 'Theme', action: () => setTheme('midnight') },
      { id: 'theme-neon', title: 'Neon Theme', icon: 'sparkles', category: 'Theme', action: () => setTheme('neon') },
      { id: 'refresh', title: 'Refresh Current View', icon: 'refresh', category: 'Action', action: () => {
        const v = global.TP.views[app.currentView];
        if (v?.refresh) v.refresh();
        toast('Refreshed', 'success');
      }},
      { id: 'fullscreen', title: 'Toggle Fullscreen', icon: 'fullscreen', category: 'Action', action: () => {
        if (!document.fullscreenElement) document.documentElement.requestFullscreen?.();
        else document.exitFullscreen?.();
      }},
      { id: 'install', title: 'Install as App', icon: 'download', category: 'Action', action: () => {
        if (app.deferredPrompt) app.deferredPrompt.prompt();
        else toast('Use browser menu → Install', 'info');
      }},
      { id: 'clear-cache', title: 'Clear Cache', icon: 'trash', category: 'Action', action: () => {
        store.cache.clear();
        if (navigator.serviceWorker?.controller) navigator.serviceWorker.controller.postMessage('CLEAR_CACHE');
        toast('Cache cleared', 'success');
      }}
    ];
    return cmds;
  }

  /* ---------- Keyboard shortcuts overlay ---------- */
  function wireKbdOverlay() {
    utils.id('openKbdNav').addEventListener('click', (e) => {
      e.preventDefault();
      openKbdOverlay();
    });
  }

  function openKbdOverlay() {
    if (app.kbdOverlayOpen) return;
    app.kbdOverlayOpen = true;

    const overlay = utils.el('div', { id: 'kbdOverlay', class: 'kbd-overlay' });
    overlay.innerHTML = `
      <div class="kbd-modal">
        <h2>Keyboard Shortcuts</h2>
        <div class="kbd-grid">
          <div>
            <div class="kbd-row"><span>Focus search</span><div class="kbd-keys"><kbd class="kbd-key">/</kbd></div></div>
            <div class="kbd-row"><span>Command palette</span><div class="kbd-keys"><kbd class="kbd-key">Ctrl</kbd><kbd class="kbd-key">K</kbd></div></div>
            <div class="kbd-row"><span>This help</span><div class="kbd-keys"><kbd class="kbd-key">Ctrl</kbd><kbd class="kbd-key">/</kbd></div></div>
            <div class="kbd-row"><span>Cycle theme</span><div class="kbd-keys"><kbd class="kbd-key">Ctrl</kbd><kbd class="kbd-key">;</kbd></div></div>
            <div class="kbd-row"><span>Toggle fullscreen</span><div class="kbd-keys"><kbd class="kbd-key">F11</kbd></div></div>
            <div class="kbd-row"><span>Close overlay</span><div class="kbd-keys"><kbd class="kbd-key">Esc</kbd></div></div>
          </div>
          <div>
            <div class="kbd-row"><span>Overview</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">o</kbd></div></div>
            <div class="kbd-row"><span>World map</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">m</kbd></div></div>
            <div class="kbd-row"><span>Crypto</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">c</kbd></div></div>
            <div class="kbd-row"><span>Forex</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">f</kbd></div></div>
            <div class="kbd-row"><span>Stocks</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">s</kbd></div></div>
            <div class="kbd-row"><span>News</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">n</kbd></div></div>
            <div class="kbd-row"><span>Weather</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">w</kbd></div></div>
            <div class="kbd-row"><span>Earthquakes</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">e</kbd></div></div>
            <div class="kbd-row"><span>Space & ISS</span><div class="kbd-keys"><kbd class="kbd-key">g</kbd><kbd class="kbd-key">p</kbd></div></div>
          </div>
        </div>
        <div style="margin-top:24px; text-align:center">
          <button class="btn btn-primary" id="kbdClose">Got it</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    utils.id('kbdClose').addEventListener('click', closeKbdOverlay);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeKbdOverlay();
    });
  }

  function closeKbdOverlay() {
    const overlay = utils.id('kbdOverlay');
    if (overlay) overlay.remove();
    app.kbdOverlayOpen = false;
  }

  app.toast = function (msg, type = 'info', title = '') {
    const container = utils.id('toasts');
    if (!container) return;
    const iconMap = { info: 'info', success: 'check', warn: 'warn', error: 'error' };
    const toast = utils.el('div', { class: 'toast toast-' + type }, [
      utils.el('span', { class: 'toast-ico', html: icons.makeIcon(iconMap[type] || 'info', 18) }),
      utils.el('div', { class: 'toast-body' }, [
        utils.el('div', { class: 'toast-title', text: title || msg }),
        title ? utils.el('div', { class: 'toast-msg', text: msg }) : null
      ].filter(Boolean))
    ]);
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('out');
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  };

  function hideSplash() {
    const splash = utils.id('splash');
    if (splash) {
      splash.classList.add('hidden');
      setTimeout(() => splash.remove(), 500);
    }
  }

  // Public API
  app.THEMES = THEMES;
  app.setTheme = setTheme;
  app.cycleTheme = cycleTheme;
  app.openCmdPalette = openCmdPalette;
  app.openKbdOverlay = openKbdOverlay;

  if (document.readyState !== 'loading') init();
  else document.addEventListener('DOMContentLoaded', init);

  global.TP.app = app;
})(window);
