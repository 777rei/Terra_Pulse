/* ============================================================
   TERRA PULSE — starfield.js
   Animated star canvas background with shooting stars.
   ============================================================ */
(function (global) {
  'use strict';

  function init() {
    const canvas = document.getElementById('starfield');
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let stars = [];
    let shooting = [];
    let w = 0, h = 0;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);
    let running = true;

    function resize() {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(180, Math.floor(w * h / 12000));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.4 + 0.3,
        a: Math.random() * 0.6 + 0.2,
        twinkle: Math.random() * 0.02 + 0.005,
        dir: Math.random() > 0.5 ? 1 : -1,
        vx: (Math.random() - 0.5) * 0.05,
        vy: (Math.random() - 0.5) * 0.05
      }));
    }

    function spawnShootingStar() {
      if (shooting.length > 2) return;
      shooting.push({
        x: Math.random() * w,
        y: Math.random() * h * 0.5,
        vx: (Math.random() * 4 + 4) * (Math.random() > 0.5 ? 1 : -1),
        vy: Math.random() * 2 + 1,
        life: 1,
        len: Math.random() * 80 + 40
      });
    }

    function frame() {
      if (!running) return;
      ctx.clearRect(0, 0, w, h);

      for (const s of stars) {
        s.a += s.twinkle * s.dir;
        if (s.a > 0.9) { s.a = 0.9; s.dir = -1; }
        if (s.a < 0.15) { s.a = 0.15; s.dir = 1; }
        s.x += s.vx; s.y += s.vy;
        if (s.x < 0) s.x = w; if (s.x > w) s.x = 0;
        if (s.y < 0) s.y = h; if (s.y > h) s.y = 0;
        ctx.globalAlpha = s.a;
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
        if (s.r > 1) {
          ctx.globalAlpha = s.a * 0.3;
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.r * 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      for (let i = shooting.length - 1; i >= 0; i--) {
        const s = shooting[i];
        s.x += s.vx; s.y += s.vy;
        s.life -= 0.012;
        if (s.life <= 0 || s.x < -100 || s.x > w + 100 || s.y > h + 100) {
          shooting.splice(i, 1);
          continue;
        }
        ctx.globalAlpha = s.life;
        const grad = ctx.createLinearGradient(s.x, s.y, s.x - s.vx * 6, s.y - s.vy * 6);
        grad.addColorStop(0, 'rgba(255,255,255,0.9)');
        grad.addColorStop(1, 'rgba(94,231,255,0)');
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(s.x - s.vx * 6, s.y - s.vy * 6);
        ctx.stroke();
      }

      ctx.globalAlpha = 1;
      if (Math.random() < 0.003) spawnShootingStar();
      requestAnimationFrame(frame);
    }

    resize();
    window.addEventListener('resize', () => {
      clearTimeout(window.__sfResize);
      window.__sfResize = setTimeout(resize, 200);
    });
    frame();

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { running = false; }
      else if (!running) { running = true; frame(); }
    });

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      running = false;
      ctx.clearRect(0, 0, w, h);
    }
  }

  if (document.readyState !== 'loading') init();
  else document.addEventListener('DOMContentLoaded', init);
})(window);
