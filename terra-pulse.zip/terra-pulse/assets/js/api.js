/* ============================================================
   TERRA PULSE — api.js
   All free / no-key public APIs, wrapped in a single module.
   ============================================================ */
(function (global) {
  'use strict';

  const cache = global.TP.store.cache;

  async function fetchJSON(url, opts = {}) {
    const cacheKey = opts.cacheKey || url;
    const maxAge = opts.maxAge ?? 30_000;
    const cached = await cache.get(cacheKey, maxAge);
    if (cached) return cached;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeout ?? 12000);
    try {
      const r = await fetch(url, {
        signal: controller.signal,
        headers: opts.headers || {}
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const data = await r.json();
      cache.set(cacheKey, data);
      return data;
    } catch (e) {
      if (opts.proxyFallback !== false && !url.includes('corsproxy') && !url.includes('allorigins')) {
        try {
          const proxied = 'https://corsproxy.io/?url=' + encodeURIComponent(url);
          const r2 = await fetch(proxied, { signal: AbortSignal.timeout(8000) });
          if (r2.ok) {
            const data2 = await r2.json();
            cache.set(cacheKey, data2);
            return data2;
          }
        } catch {}
      }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  async function fetchText(url, opts = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeout ?? 12000);
    try {
      const r = await fetch(url, { signal: controller.signal });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.text();
    } finally {
      clearTimeout(timer);
    }
  }

  const weather = {
    async current(lat, lng) {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}` +
        `&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,uv_index` +
        `&hourly=temperature_2m,precipitation_probability,weather_code&forecast_days=1&timezone=auto`;
      return fetchJSON(url, { cacheKey: `weather:${lat},${lng}`, maxAge: 5 * 60_000 });
    },
    async currentBatch(coords) {
      const results = await Promise.allSettled(coords.map((c) => this.current(c.lat, c.lng)));
      return results.map((r, i) => ({
        ...coords[i],
        data: r.status === 'fulfilled' ? r.value : null,
        error: r.status === 'rejected' ? r.reason : null
      }));
    },
    async airQuality(lat, lng) {
      const url = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lng}` +
        `&current=european_aqi,us_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone,ammonia&timezone=auto`;
      return fetchJSON(url, { cacheKey: `aq:${lat},${lng}`, maxAge: 10 * 60_000 });
    },
    async marine(lat, lng) {
      const url = `https://marine-api.open-meteo.com/v1/marine?latitude=${lat}&longitude=${lng}&current=wave_height,wave_direction,wave_period,sea_surface_temperature&timezone=auto`;
      return fetchJSON(url, { cacheKey: `marine:${lat},${lng}`, maxAge: 30 * 60_000 });
    },
    async history(lat, lng, days = 30) {
      const end = new Date();
      const start = new Date(end.getTime() - days * 86400000);
      const fmt = (d) => d.toISOString().slice(0, 10);
      const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lat}&longitude=${lng}&start_date=${fmt(start)}&end_date=${fmt(end)}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto`;
      return fetchJSON(url, { cacheKey: `hist:${lat},${lng}:${days}`, maxAge: 6 * 3600_000 });
    }
  };

  const geocode = {
    async search(q) {
      const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=8&language=en&format=json`;
      return fetchJSON(url, { cacheKey: `geo:${q}`, maxAge: 24 * 3600_000 });
    },
    async reverse(lat, lng) {
      const url = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=en`;
      try { return await fetchJSON(url, { cacheKey: `rev:${lat},${lng}`, maxAge: 24 * 3600_000, proxyFallback: false }); }
      catch { return null; }
    }
  };

  const earthquakes = {
    async summary(timeframe = 'day') {
      const url = `https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_${timeframe}.geojson`;
      return fetchJSON(url, { cacheKey: `quakes:${timeframe}`, maxAge: 60_000 });
    },
    async significant() {
      const url = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_week.geojson';
      return fetchJSON(url, { cacheKey: 'quakes:sig', maxAge: 5 * 60_000 });
    }
  };

  const crypto = {
    async markets(perPage = 50, page = 1, vs = 'usd') {
      const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=${vs}&order=market_cap_desc&per_page=${perPage}&page=${page}&sparkline=true&price_change_percentage=1h,24h,7d`;
      return fetchJSON(url, { cacheKey: `cg:markets:${vs}:${perPage}:${page}`, maxAge: 60_000 });
    },
    async global() {
      const url = 'https://api.coingecko.com/api/v3/global';
      return fetchJSON(url, { cacheKey: 'cg:global', maxAge: 60_000 });
    },
    async trending() {
      const url = 'https://api.coingecko.com/api/v3/search/trending';
      return fetchJSON(url, { cacheKey: 'cg:trending', maxAge: 5 * 60_000 });
    },
    async coin(id) {
      const url = `https://api.coingecko.com/api/v3/coins/${id}?localization=false&tickers=false&market_data=true&community_data=true&developer_data=false&sparkline=true`;
      return fetchJSON(url, { cacheKey: `cg:coin:${id}`, maxAge: 60_000 });
    },
    async priceSimple(ids, vs = 'usd') {
      const url = `https://api.coingecko.com/api/v3/simple/price?ids=${ids.join(',')}&vs_currencies=${vs}&include_24hr_change=true&include_last_updated_at=true`;
      return fetchJSON(url, { cacheKey: `cg:price:${ids.join(',')}`, maxAge: 60_000 });
    }
  };

  const forex = {
    async latest(base = 'USD') {
      const url = `https://open.er-api.com/v6/latest/${base}`;
      return fetchJSON(url, { cacheKey: `fx:${base}`, maxAge: 5 * 60_000 });
    },
    async timeseries(base = 'USD', target = 'EUR', days = 30) {
      const end = new Date();
      const start = new Date(end.getTime() - days * 86400000);
      const fmt = (d) => d.toISOString().slice(0, 10);
      const url = `https://api.frankfurter.app/${fmt(start)}..?from=${base}&to=${target}`;
      return fetchJSON(url, { cacheKey: `fx:ts:${base}:${target}:${days}`, maxAge: 6 * 3600_000 });
    }
  };

  const stocks = {
    async quote(symbols = ['AAPL', 'MSFT', 'GOOG', 'AMZN', 'TSLA']) {
      const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbols.join(',')}`;
      try {
        return await fetchJSON(url, { cacheKey: `stock:${symbols.join(',')}`, maxAge: 60_000, proxyFallback: true });
      } catch {
        return this._stooqFallback(symbols);
      }
    },
    async _stooqFallback(symbols) {
      const results = await Promise.allSettled(symbols.map(async (sym) => {
        const url = `https://stooq.com/q/l/?s=${sym.toLowerCase()}.us&f=sd2t2ohlcv&h&e=csv`;
        const text = await fetchText(url);
        const lines = text.trim().split('\n');
        if (lines.length < 2) return null;
        const cols = lines[1].split(',');
        return { symbol: sym, price: parseFloat(cols[6]) || 0, open: parseFloat(cols[3]), high: parseFloat(cols[4]), low: parseFloat(cols[5]), close: parseFloat(cols[6]), date: cols[1] };
      }));
      return { quoteResponse: { result: results.map((r) => r.value).filter(Boolean) } };
    },
    async gainers() {
      const url = 'https://query1.finance.yahoo.com/v1/finance/trending/US?count=20';
      try { return await fetchJSON(url, { cacheKey: 'stock:trending', maxAge: 5 * 60_000, proxyFallback: true }); }
      catch { return null; }
    }
  };

  const commodities = {
    _symbols: {
      'Crude Oil (WTI)': 'cl.f',
      'Brent Oil': 'cb.f',
      'Gold': 'gc.f',
      'Silver': 'si.f',
      'Copper': 'hg.f',
      'Natural Gas': 'ng.f',
      'Wheat': 'zw.f',
      'Corn': 'zc.f',
      'Coffee': 'kc.f',
      'Sugar': 'sb.f'
    },
    async all() {
      const entries = Object.entries(this._symbols);
      const results = await Promise.allSettled(entries.map(async ([name, sym]) => {
        const url = `https://stooq.com/q/l/?s=${sym}&f=sd2t2ohlcv&h&e=csv`;
        try {
          const text = await fetchText(url);
          const lines = text.trim().split('\n');
          if (lines.length < 2) return { name, symbol: sym };
          const cols = lines[1].split(',');
          return {
            name, symbol: sym,
            price: parseFloat(cols[6]) || 0,
            open: parseFloat(cols[3]) || 0,
            high: parseFloat(cols[4]) || 0,
            low: parseFloat(cols[5]) || 0,
            close: parseFloat(cols[6]) || 0,
            date: cols[1]
          };
        } catch { return { name, symbol: sym }; }
      }));
      return results.map((r) => r.value).filter(Boolean);
    }
  };

  const news = {
    async spaceflight(count = 15) {
      const url = `https://api.spaceflightnewsapi.net/v4/articles/?limit=${count}&ordering=-published_at`;
      return fetchJSON(url, { cacheKey: 'news:space', maxAge: 5 * 60_000 });
    },
    async hackernews(query = '', tags = 'story') {
      const url = `https://hn.algolia.com/api/v1/search?tags=${tags}&hitsPerPage=20` + (query ? `&query=${encodeURIComponent(query)}` : '');
      return fetchJSON(url, { cacheKey: `news:hn:${query}`, maxAge: 5 * 60_000 });
    },
    async cryptoCompare() {
      const url = 'https://min-api.cryptocompare.com/data/v2/news/?lang=EN&categories=BTC,ETH,Business,Technology,Regulation';
      return fetchJSON(url, { cacheKey: 'news:cc', maxAge: 5 * 60_000, proxyFallback: true });
    },
    async rss(feedUrl) {
      const url = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feedUrl)}`;
      return fetchJSON(url, { cacheKey: `rss:${feedUrl}`, maxAge: 5 * 60_000, proxyFallback: true });
    },
    async world() {
      const feeds = [
        'https://feeds.bbci.co.uk/news/world/rss.xml',
        'https://rss.nytimes.com/services/xml/rss/nyt/World.xml',
        'https://www.aljazeera.com/xml/rss/all.xml'
      ];
      const results = await Promise.allSettled(feeds.map((f) => this.rss(f)));
      const items = [];
      results.forEach((r) => {
        if (r.status === 'fulfilled' && r.value && r.value.items) {
          r.value.items.slice(0, 6).forEach((it) => items.push(it));
        }
      });
      items.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));
      return items.slice(0, 20);
    },
    async technology() { return this.rss('https://feeds.arstechnica.com/arstechnica/index.xml'); },
    async business() { return this.rss('https://feeds.bloomberg.com/markets/news.rss'); }
  };

  const space = {
    async iss() {
      const url = 'http://api.open-notify.org/iss-now.json';
      return fetchJSON(url, { cacheKey: 'iss:now', maxAge: 5_000, proxyFallback: true });
    },
    async people() {
      const url = 'http://api.open-notify.org/astros.json';
      return fetchJSON(url, { cacheKey: 'iss:people', maxAge: 5 * 60_000, proxyFallback: true });
    },
    async tle(satId = 25544) {
      const url = `https://api.wheretheiss.at/v1/satellites/${satId}/tles`;
      return fetchJSON(url, { cacheKey: `tle:${satId}`, maxAge: 6 * 3600_000, proxyFallback: true });
    },
    async positions(satId = 25544) {
      const url = `https://api.wheretheiss.at/v1/satellites/${satId}/positions?timestamps=${Math.floor(Date.now()/1000)},${Math.floor(Date.now()/1000)+60},${Math.floor(Date.now()/1000)+300}`;
      return fetchJSON(url, { cacheKey: `sat:${satId}`, maxAge: 30_000, proxyFallback: true });
    },
    async apod() {
      const url = 'https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY';
      return fetchJSON(url, { cacheKey: 'apod', maxAge: 6 * 3600_000 });
    },
    async mars() {
      try {
        const url = 'https://api.maas2.apollorion.com/';
        return await fetchJSON(url, { cacheKey: 'mars', maxAge: 6 * 3600_000, proxyFallback: true });
      } catch { return null; }
    },
    async launches(count = 20) {
      const url = `https://ll.thespacedevs.com/2.2.0/launch/upcoming/?limit=${count}&ordering=net`;
      return fetchJSON(url, { cacheKey: 'launches', maxAge: 30 * 60_000 });
    },
    async spaceWeather() {
      const url = 'https://services.swpc.noaa.gov/products/alerts.json';
      return fetchJSON(url, { cacheKey: 'spacewx', maxAge: 5 * 60_000 });
    }
  };

  const github = {
    async events() {
      const url = 'https://api.github.com/events?per_page=30';
      return fetchJSON(url, { cacheKey: 'gh:events', maxAge: 60_000 });
    },
    async trendingSince(daily = 'daily', language = '') {
      const since = daily === 'weekly' ? 7 : daily === 'monthly' ? 30 : 1;
      const date = new Date(Date.now() - since * 86400000).toISOString().slice(0, 10);
      const url = `https://api.github.com/search/repositories?q=created:>${date}${language ? `+language:${language}` : ''}&sort=stars&order=desc&per_page=30`;
      return fetchJSON(url, { cacheKey: `gh:trending:${daily}:${language}`, maxAge: 30 * 60_000 });
    }
  };

  const wikipedia = {
    async search(q) {
      const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&origin=*&srlimit=8`;
      return fetchJSON(url, { cacheKey: `wiki:s:${q}`, maxAge: 24 * 3600_000 });
    },
    async recentChanges() {
      const url = 'https://en.wikipedia.org/w/api.php?action=query&list=recentchanges&rclimit=20&rcprop=title|timestamp|user|comment|sizes&rctype=edit|new&format=json&origin=*';
      return fetchJSON(url, { cacheKey: 'wiki:rc', maxAge: 60_000 });
    },
    async news() {
      const d = new Date();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const url = `https://api.wikimedia.org/feed/v1/wikipedia/en/onthisday/all/${mm}/${dd}`;
      try { return await fetchJSON(url, { cacheKey: `wiki:otd:${mm}${dd}`, maxAge: 6 * 3600_000 }); }
      catch {
        return await global.TP.api.news.rss('https://en.wikipedia.org/rss/featuredfeed/en/features.xml');
      }
    },
    async summary(title) {
      const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
      return fetchJSON(url, { cacheKey: `wiki:sum:${title}`, maxAge: 24 * 3600_000 });
    }
  };

  const holidays = {
    async year(year = new Date().getFullYear(), country = 'US') {
      const url = `https://date.nager.at/api/v3/publicholidays/${year}/${country}`;
      return fetchJSON(url, { cacheKey: `hol:${year}:${country}`, maxAge: 24 * 3600_000 });
    },
    async countries() {
      const url = 'https://date.nager.at/api/v3/AvailableCountries';
      return fetchJSON(url, { cacheKey: 'hol:countries', maxAge: 30 * 24 * 3600_000 });
    }
  };

  const health = {
    async global() {
      const url = 'https://disease.sh/v3/covid-19/all';
      return fetchJSON(url, { cacheKey: 'covid:all', maxAge: 30 * 60_000 });
    },
    async countries() {
      const url = 'https://disease.sh/v3/covid-19/countries?sort=cases';
      return fetchJSON(url, { cacheKey: 'covid:countries', maxAge: 30 * 60_000 });
    },
    async history(country = 'all', days = 30) {
      const url = `https://disease.sh/v3/covid-19/historical/${country}?lastdays=${days}`;
      return fetchJSON(url, { cacheKey: `covid:hist:${country}:${days}`, maxAge: 60 * 60_000 });
    }
  };

  const population = {
    snapshot() {
      const ref = new Date('2024-01-01T00:00:00Z').getTime();
      const now = Date.now();
      const seconds = (now - ref) / 1000;
      const base = 8_100_000_000;
      const rate = 2.25;
      return {
        total: Math.floor(base + seconds * rate),
        birthsToday: Math.floor(seconds / 86400 * 385000),
        deathsToday: Math.floor(seconds / 86400 * 165000),
        growthToday: Math.floor(seconds / 86400 * 220000),
        ref
      };
    },
    async byCountry() {
      const url = 'https://restcountries.com/v3.1/all?fields=name,population,region,subregion,capital,flags,latlng,cca2';
      try {
        return await fetchJSON(url, { cacheKey: 'restcountries', maxAge: 24 * 3600_000 });
      } catch { return null; }
    }
  };

  const network = {
    async trace() {
      const url = 'https://www.cloudflare.com/cdn-cgi/trace';
      try {
        const text = await fetchText(url);
        const obj = {};
        text.split('\n').forEach((line) => {
          const [k, v] = line.split('=');
          if (k) obj[k] = v;
        });
        return obj;
      } catch { return null; }
    },
    async ipinfo() {
      const url = 'https://ipapi.co/json/';
      try { return await fetchJSON(url, { cacheKey: 'ipinfo', maxAge: 60 * 60_000, proxyFallback: true }); }
      catch { return null; }
    },
    internetStats() {
      const ref = new Date('2024-01-01T00:00:00Z').getTime();
      const sec = (Date.now() - ref) / 1000;
      const base = 5_400_000_000;
      const ratePerSec = (5_400_000_000 * 0.03) / (365 * 86400);
      const users = Math.floor(base + sec * ratePerSec);
      const emailsToday = Math.floor((Date.now() - new Date().setHours(0, 0, 0, 0)) / 86400000 * 340_000_000_000);
      const searchesToday = Math.floor((Date.now() - new Date().setHours(0, 0, 0, 0)) / 86400000 * 8_500_000_000);
      const tweetsToday = Math.floor((Date.now() - new Date().setHours(0, 0, 0, 0)) / 86400000 * 500_000_000);
      const dataTodayTB = Math.floor((Date.now() - new Date().setHours(0, 0, 0, 0)) / 86400000 * 328_000_000);
      return { users, emailsToday, searchesToday, tweetsToday, dataTodayTB };
    }
  };

  const time = {
    now() { return new Date(); },
    async fromServer() {
      try {
        const r = await fetch('https://www.cloudflare.com/cdn-cgi/trace', { method: 'GET' });
        const date = r.headers.get('date');
        if (date) return new Date(date);
      } catch {}
      return new Date();
    }
  };

  const api = {
    fetchJSON, fetchText,
    weather, geocode, earthquakes, crypto, forex, stocks, commodities,
    news, space, github, wikipedia, holidays, health, population, network, time
  };

  global.TP = global.TP || {};
  global.TP.api = api;
})(window);
